import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Navbar } from './components/common/Navbar';
import { MobileBottomNav } from './components/common/MobileBottomNav';
import { AuthModal } from './components/common/AuthModal';
import { JoinTournamentModal } from './components/tournament/JoinTournamentModal';
import { Home } from './pages/Home';
import { TournamentsList } from './pages/TournamentsList';
import { TournamentDetails } from './pages/TournamentDetails';
import { PlayerDashboard } from './pages/PlayerDashboard';
import { MyMatches } from './pages/MyMatches';
import { TeamManagement } from './pages/TeamManagement';
import { WalletPage } from './pages/WalletPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { ProfilePage } from './pages/ProfilePage';
import { SupportCenter } from './pages/SupportCenter';
import { RulesPage } from './pages/RulesPage';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { checkAndSeedInitialData } from './services/seedService';
import { Tournament } from './types';

function MainApp() {
  const { currentUser, userProfile, isAdmin } = useAuth();
  const { language } = useLanguage();

  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedTournamentId, setSelectedTournamentId] = useState<string | null>(null);
  const [walletTab, setWalletTab] = useState<'overview' | 'deposit' | 'withdraw'>('overview');

  // Join Tournament Modal state
  const [activeJoinTournament, setActiveJoinTournament] = useState<Tournament | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  useEffect(() => {
    // Check and seed initial tournament presets if empty
    checkAndSeedInitialData();
  }, []);

  const handleNavigate = (page: string, params?: any) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (page === 'tournamentDetails' && params?.id) {
      setSelectedTournamentId(params.id);
    }
    if (page === 'wallet' && params?.tab) {
      setWalletTab(params.tab);
    }
    setCurrentPage(page);
  };

  const handleJoinClick = (tournament: Tournament) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    setActiveJoinTournament(tournament);
  };

  const handleJoinSuccess = (regId: string) => {
    setActiveJoinTournament(null);
    handleNavigate('myMatches');
  };

  const handleDepositRedirect = () => {
    setActiveJoinTournament(null);
    handleNavigate('wallet', { tab: 'deposit' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070B18] text-[#F8FAFC]">
      {/* Top Navigation */}
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />

      {/* Main Page Content */}
      <main className="flex-1 pb-20 md:pb-8">
        {currentPage === 'home' && (
          <Home onNavigate={handleNavigate} onJoinClick={handleJoinClick} />
        )}

        {currentPage === 'tournaments' && (
          <TournamentsList
            onSelectTournament={(tour) =>
              handleNavigate('tournamentDetails', { id: tour.id })
            }
            onJoinTournament={handleJoinClick}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'tournamentDetails' && selectedTournamentId && (
          <TournamentDetails
            tournamentId={selectedTournamentId}
            onBack={() => handleNavigate('tournaments')}
            onJoinClick={handleJoinClick}
          />
        )}

        {currentPage === 'dashboard' && (
          <PlayerDashboard onNavigate={handleNavigate} />
        )}

        {currentPage === 'myMatches' && (
          <MyMatches onNavigate={handleNavigate} />
        )}

        {currentPage === 'myTeam' && <TeamManagement />}

        {currentPage === 'wallet' && <WalletPage initialTab={walletTab} />}

        {currentPage === 'leaderboard' && <LeaderboardPage />}

        {currentPage === 'profile' && <ProfilePage />}

        {currentPage === 'support' && <SupportCenter />}

        {currentPage === 'rules' && <RulesPage />}

        {currentPage === 'admin' && <AdminDashboard />}
      </main>

      {/* Mobile Sticky Bottom Navigation */}
      <MobileBottomNav currentPage={currentPage} onNavigate={handleNavigate} />

      {/* Global Modals */}
      <JoinTournamentModal
        tournament={activeJoinTournament}
        isOpen={!!activeJoinTournament}
        onClose={() => setActiveJoinTournament(null)}
        onSuccess={handleJoinSuccess}
        onDepositRedirect={handleDepositRedirect}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode="login"
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MainApp />
      </AuthProvider>
    </LanguageProvider>
  );
}
