import React from 'react';

interface TXLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const TXLogo: React.FC<TXLogoProps> = ({ size = 'md', showSubtitle = true }) => {
  const sizeClasses = {
    sm: 'h-8',
    md: 'h-10',
    lg: 'h-14',
  };

  const textClasses = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl',
  };

  return (
    <div className="flex items-center gap-2.5 select-none cursor-pointer group">
      {/* Hexagonal Shield Logo with Electric Neon Glow */}
      <div className={`relative ${sizeClasses[size]} aspect-square flex items-center justify-center`}>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-sky-500 to-indigo-700 rounded-lg transform -rotate-3 group-hover:rotate-0 transition-transform duration-300 blur-[2px] opacity-75"></div>
        <div className="relative w-full h-full bg-[#0D1428] border border-sky-400/50 rounded-lg flex items-center justify-center overflow-hidden shadow-lg shadow-sky-500/20">
          {/* Angular TX Esports Symbol */}
          <svg
            viewBox="0 0 100 100"
            className="w-4/5 h-4/5 text-sky-400 filter drop-shadow-[0_0_8px_rgba(56,189,248,0.8)]"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* T letter styling */}
            <path
              d="M15 22H52V34H39V78H27V34H15V22Z"
              fill="url(#tx-gradient-t)"
            />
            {/* X letter styling */}
            <path
              d="M48 22H62L74 46L86 22H98L81 50L99 78H85L74 54L61 78H48L67 50L48 22Z"
              fill="url(#tx-gradient-x)"
            />
            {/* Speed Slash */}
            <path
              d="M10 82L90 18"
              stroke="#38BDF8"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeDasharray="4 6"
              opacity="0.6"
            />
            <defs>
              <linearGradient id="tx-gradient-t" x1="15" y1="22" x2="52" y2="78" gradientUnits="userSpaceOnUse">
                <stop stopColor="#60A5FA" />
                <stop offset="1" stopColor="#2563EB" />
              </linearGradient>
              <linearGradient id="tx-gradient-x" x1="48" y1="22" x2="99" y2="78" gradientUnits="userSpaceOnUse">
                <stop stopColor="#38BDF8" />
                <stop offset="1" stopColor="#0284C7" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span className={`font-black font-gaming tracking-wider text-white ${textClasses[size]}`}>
            TX <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">TOUR</span>
          </span>
          <span className="px-1.5 py-0.5 text-[10px] font-bold font-gaming rounded bg-gradient-to-r from-red-600 to-red-500 text-white tracking-widest shadow-sm">
            BD
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[10px] tracking-widest text-sky-300/80 font-medium font-gaming uppercase mt-0.5">
            Free Fire Esports
          </span>
        )}
      </div>
    </div>
  );
};
