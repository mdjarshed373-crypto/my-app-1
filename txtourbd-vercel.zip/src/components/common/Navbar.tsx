import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { TXLogo } from './TXLogo';
import { AuthModal } from './AuthModal';
import {
  Wallet,
  Bell,
  Menu,
  X,
  User,
  Shield,
  Trophy,
  Swords,
  Users,
  LogOut,
  ChevronDown,
  Plus,
  ExternalLink,
  Check,
} from 'lucide-react';
import { AppNotification } from '../../types';
import { fetchUserNotifications, markNotificationAsRead } from '../../services/notificationService';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string, params?: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const { currentUser, userProfile, isAdmin, logout } = useAuth();
  const { language, toggleLanguage, t, formatBDT } = useLanguage();

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (currentUser) {
      loadNotifications();
    }
  }, [currentUser]);

  const loadNotifications = async () => {
    if (!currentUser) return;
    try {
      const list = await fetchUserNotifications(currentUser.uid);
      setNotifications(list);
    } catch {
      // ignore
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAsRead = async (id: string) => {
    await markNotificationAsRead(id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setUserDropdownOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navLinks = [
    { id: 'home', label: t('nav.home') },
    { id: 'tournaments', label: t('nav.tournaments') },
    { id: 'leaderboard', label: t('nav.leaderboard') },
    { id: 'rules', label: t('nav.rules') },
    { id: 'support', label: t('nav.support') },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-[#070B18]/90 backdrop-blur-md border-b border-sky-500/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          {/* Logo */}
          <div onClick={() => onNavigate('home')}>
            <TXLogo size="md" />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                  currentPage === link.id
                    ? 'text-sky-400 bg-sky-950/40 border border-sky-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Right Action Icons & Auth Controls */}
          <div className="flex items-center gap-2.5 sm:gap-4">
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              title="Toggle Language (বাংলা / English)"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#111D35] hover:bg-slate-800 border border-slate-700 text-xs font-bold text-sky-400 transition-colors cursor-pointer"
            >
              <span>{language === 'bn' ? 'বাং' : 'EN'}</span>
            </button>

            {/* Direct Admin Panel shortcut for admins */}
            {isAdmin && (
              <button
                onClick={() => onNavigate('admin')}
                title="Admin Control Panel"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-amber-600/20 hover:from-amber-500/30 hover:to-amber-600/30 border border-amber-500/40 text-amber-300 text-xs font-bold font-gaming transition-all cursor-pointer shadow-sm shadow-amber-500/10"
              >
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">{language === 'bn' ? 'এডমিন প্যানেল' : 'Admin'}</span>
              </button>
            )}

            {currentUser && userProfile ? (
              <>
                {/* Wallet Balance Chip */}
                <div
                  onClick={() => onNavigate('wallet')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-950/80 to-[#111D35] border border-sky-500/30 hover:border-sky-400 text-white cursor-pointer transition-all shadow-sm group"
                >
                  <Wallet className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
                  <div className="flex flex-col text-left">
                    <span className="text-[10px] text-slate-400 font-medium leading-none">
                      {t('wallet.available')}
                    </span>
                    <span className="text-xs font-bold font-gaming text-sky-300">
                      {formatBDT(userProfile.walletBalance || 0)}
                    </span>
                  </div>
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate('wallet', { tab: 'deposit' });
                    }}
                    title="Add Funds"
                    className="p-1 rounded-md bg-sky-500/20 hover:bg-sky-500 text-sky-300 hover:text-black transition-colors ml-1"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                  </div>
                </div>

                {/* Notifications Bell */}
                <div className="relative" ref={notifRef}>
                  <button
                    onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                    className="relative p-2 rounded-xl bg-[#111D35] hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    <Bell className="w-4 h-4" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-[10px] font-bold text-white animate-pulse">
                        {unreadCount}
                      </span>
                    )}
                  </button>

                  {/* Notifications Popover */}
                  {notifDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-80 bg-[#0D1428] border border-sky-500/30 rounded-xl shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2">
                      <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-800">
                        <span className="text-xs font-bold font-gaming tracking-wider text-sky-400 uppercase">
                          {language === 'bn' ? 'নোটিফিকেশন' : 'Notifications'}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {unreadCount} {language === 'bn' ? 'টি নতুন' : 'unread'}
                        </span>
                      </div>

                      <div className="max-h-72 overflow-y-auto space-y-2">
                        {notifications.length === 0 ? (
                          <p className="text-xs text-slate-400 text-center py-4">
                            {language === 'bn' ? 'কোনো নোটিফিকেশন নেই' : 'No notifications'}
                          </p>
                        ) : (
                          notifications.slice(0, 8).map((n) => (
                            <div
                              key={n.id}
                              onClick={() => handleMarkAsRead(n.id)}
                              className={`p-2.5 rounded-lg text-xs transition-colors cursor-pointer ${
                                n.read ? 'bg-[#111D35]/50 text-slate-300' : 'bg-sky-950/40 border border-sky-500/30 text-white'
                              }`}
                            >
                              <div className="flex justify-between items-start gap-1">
                                <span className="font-semibold text-sky-300">
                                  {language === 'bn' ? n.titleBn || n.title : n.title}
                                </span>
                                {!n.read && (
                                  <span className="w-2 h-2 rounded-full bg-sky-400 shrink-0 mt-1"></span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-400 mt-1">
                                {language === 'bn' ? n.messageBn || n.message : n.message}
                              </p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Dropdown */}
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-[#111D35] hover:bg-slate-800 border border-slate-700 transition-colors cursor-pointer"
                  >
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-600 to-sky-400 flex items-center justify-center font-bold text-xs text-white uppercase overflow-hidden">
                      {userProfile.avatarUrl ? (
                        <img src={userProfile.avatarUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        userProfile.displayName?.substring(0, 2) || 'TX'
                      )}
                    </div>
                    <div className="hidden sm:flex flex-col text-left">
                      <span className="text-xs font-bold text-white max-w-[100px] truncate">
                        {userProfile.inGameName || userProfile.displayName}
                      </span>
                      <span className="text-[10px] text-sky-400 font-semibold font-gaming uppercase">
                        {userProfile.role}
                      </span>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-52 bg-[#0D1428] border border-sky-500/30 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
                      <div className="px-4 py-2 border-b border-slate-800">
                        <p className="text-xs font-bold text-white truncate">
                          {userProfile.displayName}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">{userProfile.email}</p>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={() => {
                            onNavigate('dashboard');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                        >
                          <Trophy className="w-3.5 h-3.5 text-sky-400" />
                          {t('nav.dashboard')}
                        </button>
                        <button
                          onClick={() => {
                            onNavigate('myMatches');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                        >
                          <Swords className="w-3.5 h-3.5 text-sky-400" />
                          {t('nav.myMatches')}
                        </button>
                        <button
                          onClick={() => {
                            onNavigate('myTeam');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                        >
                          <Users className="w-3.5 h-3.5 text-sky-400" />
                          {t('nav.myTeam')}
                        </button>
                        <button
                          onClick={() => {
                            onNavigate('wallet');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                        >
                          <Wallet className="w-3.5 h-3.5 text-sky-400" />
                          {t('nav.wallet')}
                        </button>
                        <button
                          onClick={() => {
                            onNavigate('profile');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                        >
                          <User className="w-3.5 h-3.5 text-sky-400" />
                          {t('nav.profile')}
                        </button>

                        {isAdmin && (
                          <div className="border-t border-slate-800 my-1 pt-1">
                            <button
                              onClick={() => {
                                onNavigate('admin');
                                setUserDropdownOpen(false);
                              }}
                              className="w-full flex items-center gap-2 px-4 py-2 text-xs font-bold text-amber-400 hover:bg-amber-950/40 cursor-pointer"
                            >
                              <Shield className="w-3.5 h-3.5 text-amber-400" />
                              {t('nav.adminPanel')}
                            </button>
                          </div>
                        )}

                        <div className="border-t border-slate-800 my-1 pt-1">
                          <button
                            onClick={async () => {
                              setUserDropdownOpen(false);
                              await logout();
                              onNavigate('home');
                            }}
                            className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-red-400 hover:bg-red-950/30 cursor-pointer"
                          >
                            <LogOut className="w-3.5 h-3.5 text-red-400" />
                            {t('nav.logout')}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* Logged Out Buttons */
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setAuthModalMode('login');
                    setAuthModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-[#111D35] hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
                >
                  {t('nav.login')}
                </button>
                <button
                  onClick={() => {
                    setAuthModalMode('register');
                    setAuthModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-xs font-bold text-white shadow-md shadow-sky-500/20 font-gaming tracking-wide transition-all cursor-pointer"
                >
                  {t('nav.register')}
                </button>
              </div>
            )}

            {/* Mobile Hamburger Menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg bg-[#111D35] border border-slate-700 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#0D1428] border-b border-sky-500/20 px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                  currentPage === link.id
                    ? 'text-sky-400 bg-sky-950/40'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {link.label}
              </button>
            ))}
            {isAdmin && (
              <button
                onClick={() => {
                  onNavigate('admin');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold text-amber-400 hover:bg-amber-950/30 flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                {t('nav.adminPanel')}
              </button>
            )}
          </div>
        )}
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
      />
    </>
  );
};
