import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { X, Lock, Mail, User, Phone, Gamepad2, AlertCircle, CheckCircle, ArrowRight } from 'lucide-react';
import { TXLogo } from './TXLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
}) => {
  const { loginWithEmail, registerWithEmail, loginWithGoogle, resetPassword } = useAuth();
  const { language, t } = useLanguage();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [freeFireUid, setFreeFireUid] = useState('');
  const [inGameName, setInGameName] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);

  if (!isOpen) return null;

  const resetForm = () => {
    setError(null);
    setSuccess(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await loginWithEmail(email, password);
      onClose();
    } catch (err: unknown) {
      if (err instanceof Error) {
        if (err.message.includes('user-not-found') || err.message.includes('wrong-password') || err.message.includes('invalid-credential')) {
          setError(language === 'bn' ? 'ভুল ইমেইল অথবা পাসওয়ার্ড!' : 'Invalid email or password!');
        } else {
          setError(err.message);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError(language === 'bn' ? 'পাসওয়ার্ড দুটি মিলেনি!' : 'Passwords do not match!');
      return;
    }
    if (password.length < 6) {
      setError(language === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে!' : 'Password must be at least 6 characters!');
      return;
    }
    if (!agreeTerms) {
      setError(language === 'bn' ? 'অনুগ্রহ করে শর্তাবলীতে সম্মতি জানান!' : 'Please accept the terms and conditions!');
      return;
    }

    setLoading(true);
    try {
      await registerWithEmail(
        email,
        password,
        displayName,
        username,
        phone,
        freeFireUid,
        inGameName
      );
      onClose();
    } catch (err: unknown) {
      if (err instanceof Error) {
        if (err.message.includes('email-already-in-use')) {
          setError(language === 'bn' ? 'এই ইমেইল দিয়ে ইতিমধ্যে একাউন্ট আছে!' : 'Email already in use!');
        } else {
          setError(err.message);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      await loginWithGoogle();
      onClose();
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError(language === 'bn' ? 'ইমেইল এড্রেস লিখুন!' : 'Please enter your email address!');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await resetPassword(email);
      setSuccess(
        language === 'bn'
          ? 'আপনার ইমেইলে পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে!'
          : 'Password reset link sent to your email!'
      );
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0D1428] border border-sky-500/30 rounded-2xl shadow-2xl shadow-sky-500/20 overflow-hidden">
        {/* Top glowing ambient accent */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-600 via-sky-400 to-indigo-600"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="p-6 pb-2 text-center">
          <div className="flex justify-center mb-3">
            <TXLogo size="md" showSubtitle={false} />
          </div>
          <h2 className="text-xl font-bold font-gaming tracking-wide text-white">
            {mode === 'login' && (language === 'bn' ? 'প্লেয়ার লগইন' : 'Player Login')}
            {mode === 'register' && (language === 'bn' ? 'নতুন একাউন্ট খুলুন' : 'Create Free Account')}
            {mode === 'forgot' && (language === 'bn' ? 'পাসওয়ার্ড রিসেট' : 'Reset Password')}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'bn'
              ? 'বাংলাদেশের প্রিমিয়ার ফ্রি ফায়ার টুর্নামেন্ট কমিউনিটি'
              : "Bangladesh's Premier Free Fire Esports Platform"}
          </p>
        </div>

        {/* Tabs for Login / Register */}
        {mode !== 'forgot' && (
          <div className="flex border-b border-slate-800 px-6 gap-4">
            <button
              onClick={() => {
                setMode('login');
                resetForm();
              }}
              className={`flex-1 py-2.5 font-semibold text-sm transition-all border-b-2 ${
                mode === 'login'
                  ? 'border-sky-400 text-sky-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? 'লগইন' : 'Login'}
            </button>
            <button
              onClick={() => {
                setMode('register');
                resetForm();
              }}
              className={`flex-1 py-2.5 font-semibold text-sm transition-all border-b-2 ${
                mode === 'register'
                  ? 'border-sky-400 text-sky-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? 'রেজিস্ট্রেশন' : 'Register'}
            </button>
          </div>
        )}

        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-500/50 flex items-start gap-2 text-red-200 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 rounded-lg bg-green-950/60 border border-green-500/50 flex items-start gap-2 text-green-200 text-xs">
              <CheckCircle className="w-4 h-4 shrink-0 text-green-400 mt-0.5" />
              <span>{success}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'bn' ? 'ইমেইল এড্রেস' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="player@example.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-medium text-slate-300">
                    {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      resetForm();
                    }}
                    className="text-xs text-sky-400 hover:underline"
                  >
                    {language === 'bn' ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot password?'}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white font-bold rounded-lg shadow-lg shadow-sky-500/20 transition-all font-gaming tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? t('common.loading') : language === 'bn' ? 'লগইন করুন' : 'Sign In'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* REGISTER FORM */}
          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'bn' ? 'পুরো নাম' : 'Full Name'} *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Md. Rahim"
                    className="w-full pl-9 pr-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {language === 'bn' ? 'ইউজারনেম' : 'Username'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="rahim_tx"
                    className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {language === 'bn' ? 'ফোন নম্বর' : 'Phone'} *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="018XXXXXXXX"
                      className="w-full pl-8 pr-2 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'bn' ? 'ইমেইল এড্রেস' : 'Email Address'} *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="player@example.com"
                    className="w-full pl-9 pr-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 p-2.5 bg-[#090E1F] rounded-lg border border-sky-500/20">
                <div>
                  <label className="block text-[11px] font-semibold text-sky-400 mb-1 flex items-center gap-1">
                    <Gamepad2 className="w-3 h-3" /> Free Fire UID
                  </label>
                  <input
                    type="text"
                    value={freeFireUid}
                    onChange={(e) => setFreeFireUid(e.target.value)}
                    placeholder="e.g. 1234567890"
                    className="w-full px-2.5 py-1.5 bg-[#111D35] border border-slate-700 rounded text-white text-xs focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-sky-400 mb-1 flex items-center gap-1">
                    <Gamepad2 className="w-3 h-3" /> In-Game Name (IGN)
                  </label>
                  <input
                    type="text"
                    value={inGameName}
                    onChange={(e) => setInGameName(e.target.value)}
                    placeholder="e.g. ᵀˣ_ᴷᴵᴸᴸᴱᴿ"
                    className="w-full px-2.5 py-1.5 bg-[#111D35] border border-slate-700 rounded text-white text-xs focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'} *
                  </label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {language === 'bn' ? 'নিশ্চিত পাসওয়ার্ড' : 'Confirm'} *
                  </label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="terms"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="rounded border-slate-700 text-sky-500 focus:ring-sky-500"
                />
                <label htmlFor="terms" className="text-xs text-slate-300 cursor-pointer">
                  {language === 'bn' ? (
                    <span>আমি <span className="text-sky-400">শর্তাবলী ও নিয়মাবলী</span> মেনে নিচ্ছি</span>
                  ) : (
                    <span>I accept the <span className="text-sky-400">Terms & Rules</span></span>
                  )}
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white font-bold rounded-lg shadow-lg shadow-sky-500/20 transition-all font-gaming tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? t('common.loading') : language === 'bn' ? 'একাউন্ট তৈরি করুন' : 'Create Account'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* FORGOT PASSWORD */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <p className="text-xs text-slate-300">
                {language === 'bn'
                  ? 'আপনার একাউন্টের ইমেইল ঠিকানা প্রদান করুন। আমরা পাসওয়ার্ড পুনরায় নির্ধারণের লিংক পাঠাব।'
                  : 'Enter your account email. We will send a secure link to reset your password.'}
              </p>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'bn' ? 'ইমেইল এড্রেস' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="player@example.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white font-bold rounded-lg transition-all font-gaming tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? t('common.loading') : language === 'bn' ? 'রিসেট লিংক পাঠান' : 'Send Reset Link'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  resetForm();
                }}
                className="w-full text-center text-xs text-slate-400 hover:text-white pt-2"
              >
                {language === 'bn' ? 'লগইনে ফিরে যান' : 'Back to Login'}
              </button>
            </form>
          )}

          {/* Social Google Login Divider */}
          {mode !== 'forgot' && (
            <div className="mt-5">
              <div className="relative flex items-center justify-center mb-4">
                <div className="border-t border-slate-800 w-full"></div>
                <span className="bg-[#0D1428] px-3 text-[11px] text-slate-400 uppercase tracking-widest">
                  {language === 'bn' ? 'অথবা' : 'or continue with'}
                </span>
                <div className="border-t border-slate-800 w-full"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full py-2.5 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-white rounded-lg flex items-center justify-center gap-3 text-sm font-medium transition-colors cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 10.8 0 12s.7 2.3 1.9 4.7l3.7-2.9z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2-6.4-4.8L1.9 16.4C3.7 20.1 7.5 23 12 23z"
                  />
                </svg>
                Google {language === 'bn' ? 'সাইন ইন' : 'Sign In'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
