import React from 'react';
import { Home, Trophy, Swords, Wallet, User } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface MobileBottomNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentPage,
  onNavigate,
}) => {
  const { t } = useLanguage();

  const items = [
    { id: 'home', label: t('nav.home'), icon: Home },
    { id: 'tournaments', label: t('nav.tournaments'), icon: Trophy },
    { id: 'myMatches', label: t('nav.myMatches'), icon: Swords },
    { id: 'wallet', label: t('nav.wallet'), icon: Wallet },
    { id: 'profile', label: t('nav.profile'), icon: User },
  ];

  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-[#070B18]/95 backdrop-blur-lg border-t border-sky-500/20 px-2 py-1.5 flex justify-around items-center">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg transition-all ${
              isActive
                ? 'text-sky-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className={`p-1 rounded-md ${isActive ? 'bg-sky-500/15' : ''}`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight font-medium">
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};
