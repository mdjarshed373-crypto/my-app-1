import React from 'react';
import { Tournament } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { Calendar, Clock, Trophy, Users, ShieldAlert, Award, Crosshair, MapPin } from 'lucide-react';

interface TournamentCardProps {
  tournament: Tournament;
  onSelect: (tournament: Tournament) => void;
  onJoin: (tournament: Tournament) => void;
  isRegistered?: boolean;
}

export const TournamentCard: React.FC<TournamentCardProps> = ({
  tournament,
  onSelect,
  onJoin,
  isRegistered = false,
}) => {
  const { language, t, formatBDT } = useLanguage();

  const title = language === 'bn' && tournament.titleBn ? tournament.titleBn : tournament.title;
  const isFull = tournament.registeredCount >= tournament.maxSlots;
  const isAvailable =
    tournament.status === 'REGISTRATION_OPEN' && !isFull && !isRegistered;
  const progressPercent = Math.min(
    100,
    Math.round((tournament.registeredCount / tournament.maxSlots) * 100)
  );

  const getStatusBadge = () => {
    if (isRegistered) {
      return (
        <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
          {language === 'bn' ? 'নিবন্ধিত (Joined)' : 'Joined'}
        </span>
      );
    }
    switch (tournament.status) {
      case 'REGISTRATION_OPEN':
        return isFull ? (
          <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-red-500/20 text-red-400 border border-red-500/40">
            {t('tournaments.full')}
          </span>
        ) : (
          <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/40 animate-pulse">
            {t('tournaments.filter.open')}
          </span>
        );
      case 'ONGOING':
        return (
          <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40">
            {t('tournaments.filter.ongoing')}
          </span>
        );
      case 'COMPLETED':
        return (
          <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-slate-500/20 text-slate-400 border border-slate-500/40">
            {t('tournaments.completed')}
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40">
            {tournament.status}
          </span>
        );
    }
  };

  return (
    <div className="group relative bg-[#0D1428] border border-sky-500/20 hover:border-sky-400/60 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-sky-500/10 flex flex-col justify-between">
      {/* Top Banner Image */}
      <div className="relative h-44 w-full overflow-hidden bg-slate-900">
        <img
          src={
            tournament.bannerUrl ||
            'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80'
          }
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D1428] via-[#0D1428]/40 to-transparent"></div>

        {/* Top Floating Badges */}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className="px-2.5 py-0.5 text-xs font-black font-gaming rounded-md bg-blue-600/90 text-white tracking-wider backdrop-blur-md">
            {tournament.type}
          </span>
          <span className="px-2.5 py-0.5 text-xs font-semibold rounded-md bg-slate-900/80 text-sky-300 border border-sky-400/30 backdrop-blur-md">
            {tournament.gameMode === 'BATTLE_ROYALE' ? 'BR' : 'CS'}
          </span>
        </div>

        <div className="absolute top-3 right-3">{getStatusBadge()}</div>

        {/* Map Name */}
        {tournament.map && (
          <div className="absolute bottom-2 left-3 flex items-center gap-1 text-xs text-slate-300 font-medium bg-black/60 px-2 py-0.5 rounded backdrop-blur-sm">
            <MapPin className="w-3 h-3 text-sky-400" />
            <span>{tournament.map}</span>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3
            onClick={() => onSelect(tournament)}
            className="text-base font-bold font-gaming tracking-wide text-white group-hover:text-sky-300 transition-colors line-clamp-1 cursor-pointer"
          >
            {title}
          </h3>

          {/* Schedule Info */}
          <div className="flex items-center gap-4 text-xs text-slate-400 mt-2">
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-sky-400" />
              <span>{tournament.matchDate}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              <span>{tournament.matchTime}</span>
            </div>
          </div>

          {/* Prize & Entry Fee Grid */}
          <div className="grid grid-cols-2 gap-2 my-3 p-2.5 rounded-xl bg-[#111D35]/80 border border-slate-800">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                {t('tournaments.prizePool')}
              </span>
              <span className="text-sm font-extrabold font-gaming text-sky-400 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-400 inline" />
                {formatBDT(tournament.prizePool)}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                {t('tournaments.entryFee')}
              </span>
              <span className="text-sm font-extrabold font-gaming text-emerald-400">
                {tournament.entryFee > 0
                  ? formatBDT(tournament.entryFee)
                  : t('tournaments.free')}
              </span>
            </div>
          </div>

          {/* Slot Progress */}
          <div className="space-y-1 mb-4">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-slate-400 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-sky-400" />
                {t('tournaments.slots')}
              </span>
              <span className="text-white font-gaming">
                {tournament.registeredCount} / {tournament.maxSlots}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  progressPercent >= 100
                    ? 'bg-red-500'
                    : progressPercent > 70
                    ? 'bg-amber-400'
                    : 'bg-gradient-to-r from-blue-500 to-sky-400'
                }`}
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-1 border-t border-slate-800/80">
          <button
            onClick={() => onSelect(tournament)}
            className="flex-1 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
          >
            {t('tournaments.details')}
          </button>

          {isAvailable && (
            <button
              onClick={() => onJoin(tournament)}
              className="flex-1 py-2 text-xs font-bold font-gaming tracking-wider rounded-lg bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white shadow-md shadow-sky-500/20 transition-all cursor-pointer"
            >
              {t('tournaments.joinNow')}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
