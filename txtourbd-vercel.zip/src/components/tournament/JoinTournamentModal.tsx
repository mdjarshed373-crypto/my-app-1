import React, { useState, useEffect } from 'react';
import { Tournament, PlayerSlotInfo } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { joinTournament } from '../../services/tournamentService';
import { X, Trophy, Wallet, AlertCircle, CheckCircle, ShieldCheck, Gamepad2, ArrowRight } from 'lucide-react';

interface JoinTournamentModalProps {
  tournament: Tournament | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (regId: string) => void;
  onDepositRedirect: () => void;
}

export const JoinTournamentModal: React.FC<JoinTournamentModalProps> = ({
  tournament,
  isOpen,
  onClose,
  onSuccess,
  onDepositRedirect,
}) => {
  const { currentUser, userProfile, refreshProfile } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form states
  const [teamName, setTeamName] = useState('');
  const [players, setPlayers] = useState<PlayerSlotInfo[]>([]);

  useEffect(() => {
    if (!tournament || !currentUser || !userProfile) return;

    setError(null);
    const count = tournament.type === 'SOLO' ? 1 : tournament.type === 'DUO' ? 2 : 4;
    const initialPlayers: PlayerSlotInfo[] = [];

    // Leader / Slot 1
    initialPlayers.push({
      uid: currentUser.uid,
      name: userProfile.displayName || '',
      freeFireUid: userProfile.freeFireUid || '',
      inGameName: userProfile.inGameName || userProfile.displayName || '',
      phone: userProfile.phoneNumber || '',
    });

    // Slots 2, 3, 4
    for (let i = 1; i < count; i++) {
      initialPlayers.push({
        name: `Player ${i + 1}`,
        freeFireUid: '',
        inGameName: '',
      });
    }

    setPlayers(initialPlayers);
    setTeamName(userProfile.teamName || `${userProfile.displayName}'s Team`);
  }, [tournament, currentUser, userProfile]);

  if (!isOpen || !tournament || !userProfile) return null;

  const userBalance = Number(userProfile.walletBalance || 0);
  const isBalanceSufficient = userBalance >= tournament.entryFee;

  const handlePlayerChange = (index: number, field: keyof PlayerSlotInfo, value: string) => {
    setPlayers((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validate inputs
    for (let i = 0; i < players.length; i++) {
      if (!players[i].freeFireUid.trim()) {
        setError(
          language === 'bn'
            ? `প্লেয়ার ${i + 1}-এর Free Fire UID প্রয়োজন!`
            : `Player ${i + 1} Free Fire UID is required!`
        );
        return;
      }
      if (!players[i].inGameName.trim()) {
        setError(
          language === 'bn'
            ? `প্লেয়ার ${i + 1}-এর In-Game Name প্রয়োজন!`
            : `Player ${i + 1} In-Game Name is required!`
        );
        return;
      }
    }

    if (tournament.type === 'SQUAD' && !teamName.trim()) {
      setError(language === 'bn' ? 'টিমের নাম লিখুন!' : 'Team name is required!');
      return;
    }

    setLoading(true);
    const result = await joinTournament(
      tournament,
      userProfile.uid,
      userProfile.displayName,
      players,
      teamName,
      userProfile.teamId
    );

    setLoading(false);
    if (result.success && result.registrationId) {
      await refreshProfile();
      onSuccess(result.registrationId);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0D1428] border border-sky-500/30 rounded-2xl shadow-2xl shadow-sky-500/20 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 pb-3 border-b border-slate-800 flex justify-between items-center bg-[#111D35]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold font-gaming bg-blue-600 text-white">
                {tournament.type}
              </span>
              <h2 className="text-base font-bold font-gaming tracking-wide text-white">
                {language === 'bn' ? 'টুর্নামেন্টে স্লট বুকিং' : 'Tournament Slot Registration'}
              </h2>
            </div>
            <p className="text-xs text-sky-400 font-medium mt-0.5">{tournament.title}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Balance & Fee Header */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-[#070B18] border border-slate-800">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                {t('tournaments.entryFee')}
              </span>
              <span className="text-sm font-extrabold font-gaming text-sky-400">
                {tournament.entryFee > 0 ? formatBDT(tournament.entryFee) : t('tournaments.free')}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                {t('wallet.available')}
              </span>
              <span
                className={`text-sm font-extrabold font-gaming ${
                  isBalanceSufficient ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {formatBDT(userBalance)}
              </span>
            </div>
          </div>

          {/* Insufficient Balance Notice */}
          {!isBalanceSufficient && (
            <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 flex items-start justify-between gap-3 text-xs text-red-200">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>
                  {language === 'bn'
                    ? `পর্যাপ্ত ব্যালেন্স নেই! আপনার ওয়ালেটে আরও ${formatBDT(
                        tournament.entryFee - userBalance
                      )} প্রয়োজন।`
                    : `Insufficient balance! You need ${formatBDT(
                        tournament.entryFee - userBalance
                      )} more to join.`}
                </span>
              </div>
              <button
                type="button"
                onClick={onDepositRedirect}
                className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg text-xs shrink-0 cursor-pointer"
              >
                {t('wallet.deposit')}
              </button>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/50 flex items-start gap-2 text-red-200 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Team Name for Squad / Duo */}
            {tournament.type !== 'SOLO' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {language === 'bn' ? 'টিম / স্কোয়াডের নাম' : 'Team / Squad Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="e.g. TX ESPORTS"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                />
              </div>
            )}

            {/* Players Free Fire IDs List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-sky-400 font-gaming uppercase tracking-wider flex items-center gap-1.5">
                <Gamepad2 className="w-4 h-4" />
                {tournament.type === 'SOLO'
                  ? language === 'bn' ? 'প্লেয়ার তথ্য' : 'Player Information'
                  : language === 'bn' ? 'প্লেয়ারদের Free Fire তথ্য' : 'Roster Free Fire Details'}
              </h4>

              {players.map((player, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-[#111D35]/70 border border-slate-800 space-y-2"
                >
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-200">
                      {idx === 0 ? '👑 Leader / Player 1' : `Player ${idx + 1}`}
                    </span>
                    {idx === 0 && (
                      <span className="text-[10px] text-sky-400 bg-sky-950/50 px-2 py-0.5 rounded border border-sky-500/20">
                        {userProfile.displayName}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-0.5">
                        Free Fire UID *
                      </label>
                      <input
                        type="text"
                        required
                        value={player.freeFireUid}
                        onChange={(e) => handlePlayerChange(idx, 'freeFireUid', e.target.value)}
                        placeholder="e.g. 238491029"
                        className="w-full px-2.5 py-1.5 bg-[#090E1F] border border-slate-700 rounded text-xs text-white focus:outline-none focus:border-sky-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-0.5">
                        In-Game Name (IGN) *
                      </label>
                      <input
                        type="text"
                        required
                        value={player.inGameName}
                        onChange={(e) => handlePlayerChange(idx, 'inGameName', e.target.value)}
                        placeholder="e.g. ᵀˣ_ᴷᴵᴸᴸᴱᴿ"
                        className="w-full px-2.5 py-1.5 bg-[#090E1F] border border-slate-700 rounded text-xs text-white focus:outline-none focus:border-sky-400"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Fair Play Notice */}
            <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/20 text-[11px] text-slate-300 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? 'ম্যাচ শুরুর ১০-১৫ মিনিট আগে "আমার ম্যাচ (My Matches)" সেকশনে রুম আইডি ও পাসওয়ার্ড প্রকাশ করা হবে।'
                  : 'Room ID & Password will be released in "My Matches" section 10-15 minutes prior to match schedule.'}
              </span>
            </div>

            {/* Submit Action */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
              >
                {t('common.cancel')}
              </button>
              <button
                type="submit"
                disabled={loading || !isBalanceSufficient}
                className="flex-1 py-2.5 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 disabled:opacity-50 text-white font-bold font-gaming tracking-wider rounded-lg text-xs shadow-lg shadow-sky-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {loading ? t('common.loading') : language === 'bn' ? 'স্লট নিশ্চিত করুন' : 'Confirm Slot'}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
