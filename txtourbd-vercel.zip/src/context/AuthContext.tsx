import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, onSnapshot } from 'firebase/firestore';
import { auth, db, googleProvider } from '../services/firebase';
import { UserProfile, Role } from '../types';
import { handleFirestoreError, OperationType } from '../services/firestoreError';

const BOOTSTRAP_ADMIN_EMAIL = 'mdjarshed373@gmail.com';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (
    email: string,
    pass: string,
    displayName: string,
    username: string,
    phoneNumber?: string,
    freeFireUid?: string,
    inGameName?: string
  ) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  updatePlayerProfile: (data: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync Auth State & Firestore profile
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        
        // Listen to changes in the user profile in real-time
        const unsubProfile = onSnapshot(
          userDocRef,
          async (snapshot) => {
            if (snapshot.exists()) {
              const data = snapshot.data() as UserProfile;
              // If this is the bootstrapped admin, ensure role is SUPER_ADMIN
              if (user.email === BOOTSTRAP_ADMIN_EMAIL && data.role !== 'SUPER_ADMIN') {
                try {
                  await updateDoc(userDocRef, { role: 'SUPER_ADMIN' });
                  data.role = 'SUPER_ADMIN';
                } catch {
                  // ignore
                }
              }
              setUserProfile(data);
            } else {
              // Create default profile if not yet created (e.g. from Google Sign-In)
              const isSuper = user.email === BOOTSTRAP_ADMIN_EMAIL;
              const newProfile: UserProfile = {
                uid: user.uid,
                email: user.email || '',
                displayName: user.displayName || 'Gamer ' + user.uid.substring(0, 5),
                username: (user.email?.split('@')[0] || 'player_' + user.uid.substring(0, 5)).toLowerCase(),
                phoneNumber: user.phoneNumber || '',
                freeFireUid: '',
                inGameName: user.displayName || '',
                role: isSuper ? 'SUPER_ADMIN' : 'PLAYER',
                walletBalance: 0,
                pendingBalance: 0,
                totalDeposited: 0,
                totalWithdrawn: 0,
                totalEarnings: 0,
                totalKills: 0,
                totalWins: 0,
                totalMatches: 0,
                totalTournaments: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              };

              try {
                await setDoc(userDocRef, newProfile);
                if (isSuper) {
                  await setDoc(doc(db, 'admins', user.uid), {
                    uid: user.uid,
                    email: user.email,
                    role: 'SUPER_ADMIN',
                    createdAt: new Date().toISOString(),
                  });
                }
                setUserProfile(newProfile);
              } catch (err) {
                console.error('Error creating profile document', err);
              }
            }
            setLoading(false);
          },
          (error) => {
            handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
          }
        );

        return () => unsubProfile();
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const loginWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    displayName: string,
    username: string,
    phoneNumber?: string,
    freeFireUid?: string,
    inGameName?: string
  ) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    const user = cred.user;
    const isSuper = email === BOOTSTRAP_ADMIN_EMAIL;

    const newProfile: UserProfile = {
      uid: user.uid,
      email: email.toLowerCase(),
      displayName,
      username: username.toLowerCase().trim(),
      phoneNumber: phoneNumber || '',
      freeFireUid: freeFireUid || '',
      inGameName: inGameName || displayName,
      role: isSuper ? 'SUPER_ADMIN' : 'PLAYER',
      walletBalance: 0,
      pendingBalance: 0,
      totalDeposited: 0,
      totalWithdrawn: 0,
      totalEarnings: 0,
      totalKills: 0,
      totalWins: 0,
      totalMatches: 0,
      totalTournaments: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const userDocRef = doc(db, 'users', user.uid);
    try {
      await setDoc(userDocRef, newProfile);
      if (isSuper) {
        await setDoc(doc(db, 'admins', user.uid), {
          uid: user.uid,
          email,
          role: 'SUPER_ADMIN',
          createdAt: new Date().toISOString(),
        });
      }
      setUserProfile(newProfile);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const loginWithGoogle = async () => {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    const userDocRef = doc(db, 'users', user.uid);
    const snap = await getDoc(userDocRef);

    if (!snap.exists()) {
      const isSuper = user.email === BOOTSTRAP_ADMIN_EMAIL;
      const newProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'Gamer',
        username: (user.email?.split('@')[0] || 'player_' + user.uid.substring(0, 5)).toLowerCase(),
        phoneNumber: user.phoneNumber || '',
        freeFireUid: '',
        inGameName: user.displayName || '',
        role: isSuper ? 'SUPER_ADMIN' : 'PLAYER',
        walletBalance: 0,
        pendingBalance: 0,
        totalDeposited: 0,
        totalWithdrawn: 0,
        totalEarnings: 0,
        totalKills: 0,
        totalWins: 0,
        totalMatches: 0,
        totalTournaments: 0,
        avatarUrl: user.photoURL || undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await setDoc(userDocRef, newProfile);
      if (isSuper) {
        await setDoc(doc(db, 'admins', user.uid), {
          uid: user.uid,
          email: user.email,
          role: 'SUPER_ADMIN',
          createdAt: new Date().toISOString(),
        });
      }
      setUserProfile(newProfile);
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const logout = async () => {
    await signOut(auth);
  };

  const updatePlayerProfile = async (data: Partial<UserProfile>) => {
    if (!currentUser || !userProfile) return;
    const userDocRef = doc(db, 'users', currentUser.uid);
    // Disallow role or wallet changes via client call
    const safeData = {
      ...data,
      role: userProfile.role,
      walletBalance: userProfile.walletBalance,
      pendingBalance: userProfile.pendingBalance,
      updatedAt: new Date().toISOString(),
    };
    try {
      await updateDoc(userDocRef, safeData);
      setUserProfile((prev) => (prev ? { ...prev, ...safeData } : null));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const refreshProfile = async () => {
    if (!currentUser) return;
    const snap = await getDoc(doc(db, 'users', currentUser.uid));
    if (snap.exists()) {
      setUserProfile(snap.data() as UserProfile);
    }
  };

  const isSuperAdmin =
    userProfile?.role === 'SUPER_ADMIN' || currentUser?.email === BOOTSTRAP_ADMIN_EMAIL;

  const isAdmin =
    isSuperAdmin ||
    userProfile?.role === 'ADMIN' ||
    userProfile?.role === 'MODERATOR';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isAdmin,
        isSuperAdmin,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        resetPassword,
        logout,
        updatePlayerProfile,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
