import React, { useState, useEffect } from 'react';
import { Tournament, TournamentType, GameMode, TournamentStatus } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { TournamentCard } from '../components/tournament/TournamentCard';
import { fetchTournaments } from '../services/tournamentService';
import { Search, Filter, Trophy, ArrowUpDown, Plus } from 'lucide-react';

interface TournamentsListProps {
  onSelectTournament: (tournament: Tournament) => void;
  onJoinTournament: (tournament: Tournament) => void;
  onNavigate?: (page: string, params?: any) => void;
}

export const TournamentsList: React.FC<TournamentsListProps> = ({
  onSelectTournament,
  onJoinTournament,
  onNavigate,
}) => {
  const { language, t } = useLanguage();
  const { isAdmin } = useAuth();

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedMode, setSelectedMode] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'date' | 'prize' | 'fee'>('date');

  useEffect(() => {
    loadTournaments();
  }, []);

  const loadTournaments = async () => {
    try {
      const data = await fetchTournaments();
      setTournaments(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredTournaments = tournaments
    .filter((t) => {
      // Search
      const query = search.toLowerCase();
      const matchSearch =
        t.title.toLowerCase().includes(query) ||
        (t.titleBn && t.titleBn.toLowerCase().includes(query)) ||
        (t.map && t.map.toLowerCase().includes(query)) ||
        t.id.toLowerCase().includes(query);
      if (!matchSearch) return false;

      // Type
      if (selectedType !== 'ALL' && t.type !== selectedType) return false;

      // Mode
      if (selectedMode !== 'ALL' && t.gameMode !== selectedMode) return false;

      // Status
      if (selectedStatus !== 'ALL' && t.status !== selectedStatus) return false;

      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'prize') return b.prizePool - a.prizePool;
      if (sortBy === 'fee') return a.entryFee - b.entryFee;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
          <Trophy className="w-4 h-4" />
          <span>{language === 'bn' ? 'ফ্রি ফায়ার টুর্নামেন্ট লবি' : 'Free Fire Match Lobby'}</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black font-gaming tracking-wide text-white mt-1">
          {t('tournaments.title')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">{t('tournaments.subtitle')}</p>
      </div>

      {/* Search and Filters Bar */}
      <div className="p-4 rounded-2xl bg-[#0D1428] border border-sky-500/20 mb-8 space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={language === 'bn' ? 'টুর্নামেন্টের নাম বা ম্যাপ খুঁজুন...' : 'Search tournament or map...'}
              className="w-full pl-10 pr-4 py-2.5 bg-[#111D35] border border-slate-700 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:border-sky-400 placeholder-slate-500"
            />
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-sky-400 shrink-0" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2.5 bg-[#111D35] border border-slate-700 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:border-sky-400"
            >
              <option value="date">{language === 'bn' ? 'সর্বশেষ ম্যাচ' : 'Latest Matches'}</option>
              <option value="prize">{language === 'bn' ? 'সর্বোচ্চ প্রাইজপুল' : 'Highest Prize'}</option>
              <option value="fee">{language === 'bn' ? 'কম এন্ট্রি ফি' : 'Lowest Entry Fee'}</option>
            </select>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800 text-xs">
          <span className="text-slate-400 font-semibold flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-sky-400" />
            {language === 'bn' ? 'টাইপ:' : 'Type:'}
          </span>
          {['ALL', 'SOLO', 'DUO', 'SQUAD'].map((tType) => (
            <button
              key={tType}
              onClick={() => setSelectedType(tType)}
              className={`px-3 py-1 rounded-lg font-bold font-gaming transition-all cursor-pointer ${
                selectedType === tType
                  ? 'bg-sky-500 text-white shadow-sm shadow-sky-500/30'
                  : 'bg-[#111D35] text-slate-400 hover:text-white'
              }`}
            >
              {tType === 'ALL' ? t('tournaments.filter.all') : tType}
            </button>
          ))}

          <span className="text-slate-400 font-semibold ml-2">
            {language === 'bn' ? 'স্ট্যাটাস:' : 'Status:'}
          </span>
          {['ALL', 'REGISTRATION_OPEN', 'ONGOING', 'COMPLETED'].map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-3 py-1 rounded-lg font-bold font-gaming transition-all cursor-pointer ${
                selectedStatus === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#111D35] text-slate-400 hover:text-white'
              }`}
            >
              {st === 'ALL'
                ? t('tournaments.filter.statusAll')
                : st === 'REGISTRATION_OPEN'
                ? t('tournaments.filter.open')
                : st === 'ONGOING'
                ? t('tournaments.filter.ongoing')
                : t('tournaments.completed')}
            </button>
          ))}
        </div>
      </div>

      {/* Tournaments Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="h-96 rounded-2xl bg-[#0D1428] animate-pulse border border-slate-800"
            ></div>
          ))}
        </div>
      ) : tournaments.length === 0 ? (
        <div className="text-center py-20 px-4 bg-[#0D1428] rounded-3xl border border-sky-500/20 shadow-2xl max-w-xl mx-auto space-y-4 my-8">
          <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-sky-400 mx-auto shadow-inner">
            <Trophy className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-black font-gaming tracking-wide text-white">
            No tournaments yet
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
            {language === 'bn'
              ? 'বর্তমানে কোনো টুর্নামেন্ট নেই। এডমিন নতুন টুর্নামেন্ট তৈরি করলে এখানে দেখতে পাবেন।'
              : 'There are currently no tournaments available. New matches will be listed here once created.'}
          </p>
          {isAdmin && onNavigate && (
            <button
              onClick={() => onNavigate('admin')}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming text-xs shadow-lg shadow-sky-500/25 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{language === 'bn' ? 'এডমিন প্যানেলে টুর্নামেন্ট যোগ করুন' : 'Create Tournament in Admin Panel'}</span>
            </button>
          )}
        </div>
      ) : filteredTournaments.length === 0 ? (
        <div className="text-center py-16 bg-[#0D1428] rounded-2xl border border-slate-800">
          <Trophy className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white font-gaming">
            {language === 'bn' ? 'কোনো টুর্নামেন্ট পাওয়া যায়নি' : 'No tournaments match your filter'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'bn'
              ? 'অন্য কোনো ফিল্টার বা সার্চ কিওয়ার্ড দিয়ে চেষ্টা করুন।'
              : 'Try clearing some filters or searching for something else.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTournaments.map((tournament) => (
            <TournamentCard
              key={tournament.id}
              tournament={tournament}
              onSelect={onSelectTournament}
              onJoin={onJoinTournament}
            />
          ))}
        </div>
      )}
    </div>
  );
};
