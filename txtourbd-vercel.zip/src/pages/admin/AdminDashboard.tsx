import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  Tournament,
  DepositRequest,
  WithdrawalRequest,
  TournamentRegistration,
  RoomCredential,
  TeamPlacementResult,
  AppSettings,
  SupportTicket,
  UserProfile,
} from '../../types';
import {
  fetchTournaments,
  createTournament,
  updateTournament,
  deleteTournament,
  fetchRegistrationsForTournament,
  fetchRoomCredentials,
  saveRoomCredentials,
} from '../../services/tournamentService';
import {
  fetchDepositRequests,
  fetchWithdrawalRequests,
  adminApproveDeposit,
  adminRejectDeposit,
  adminApproveWithdrawal,
  adminRejectWithdrawal,
} from '../../services/walletService';
import {
  saveMatchResult,
  publishResultAndDistributePrizes,
  calculatePoints,
  DEFAULT_PLACEMENT_POINTS,
  fetchMatchResult,
} from '../../services/matchResultService';
import { fetchAllTickets, replyToTicket } from '../../services/supportService';
import { doc, getDoc, setDoc, collection, getDocs } from 'firebase/firestore';
import { db } from '../../services/firebase';
import {
  Shield,
  Trophy,
  Wallet,
  Users,
  KeyRound,
  CheckCircle,
  XCircle,
  Plus,
  Trash2,
  Edit,
  Save,
  MessageSquare,
  Settings,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  Flame,
  MapPin,
  Clock,
  Calendar,
  Lock,
  RefreshCw,
  Eye,
  EyeOff,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { userProfile, isAdmin } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'tournaments' | 'rooms' | 'deposits' | 'withdrawals' | 'results' | 'tickets' | 'settings' | 'users'
  >('overview');

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // New Tournament Form
  const [showCreateTourModal, setShowCreateTourModal] = useState(false);
  const [newTour, setNewTour] = useState<Partial<Tournament>>({
    title: '',
    titleBn: '',
    type: 'SQUAD',
    gameMode: 'BATTLE_ROYALE',
    map: 'Bermuda',
    entryFee: 100,
    prizePool: 2400,
    firstPrize: 1200,
    secondPrize: 600,
    thirdPrize: 300,
    perKillPrize: 10,
    maxSlots: 24,
    status: 'REGISTRATION_OPEN',
    matchDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    matchTime: '08:00 PM',
    registrationDeadline: new Date(Date.now() + 80000000).toISOString(),
    rules: 'No emulator. Mobile only. No hack/scripts.',
    rulesBn: 'শুধুমাত্র মোবাইল প্লেয়ার। কোনো প্রকার হ্যাক বা এমুলেটর নিষিদ্ধ।',
    bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
  });
  const [newTourRoom, setNewTourRoom] = useState<{ roomId: string; roomPassword: string; isPublished: boolean }>({
    roomId: '',
    roomPassword: '',
    isPublished: false,
  });

  // Edit Tournament Modal State
  const [showEditTourModal, setShowEditTourModal] = useState(false);
  const [editingTour, setEditingTour] = useState<Tournament | null>(null);
  const [editingTourRoom, setEditingTourRoom] = useState<RoomCredential | null>(null);

  // Quick Room Modal State
  const [showQuickRoomModal, setShowQuickRoomModal] = useState(false);
  const [quickRoomTour, setQuickRoomTour] = useState<Tournament | null>(null);
  const [quickRoomData, setQuickRoomData] = useState<RoomCredential>({
    id: '',
    tournamentId: '',
    roomId: '',
    roomPassword: '',
    releaseTime: '',
    isPublished: false,
  });

  // Map of rooms for all tournaments
  const [roomsMap, setRoomsMap] = useState<Record<string, RoomCredential>>({});

  // Room Credentials Tab State
  const [selectedTourForRoom, setSelectedTourForRoom] = useState<string>('');
  const [roomData, setRoomData] = useState<RoomCredential>({
    id: '',
    tournamentId: '',
    roomId: '',
    roomPassword: '',
    releaseTime: '',
    isPublished: false,
  });

  // Match Scoring Tab State
  const [selectedTourForScoring, setSelectedTourForScoring] = useState<string>('');
  const [scoringRegistrations, setScoringRegistrations] = useState<TournamentRegistration[]>([]);
  const [standingsInput, setStandingsInput] = useState<Record<string, { placement: number; kills: number }>>({});
  const [scoringStatusMessage, setScoringStatusMessage] = useState<string | null>(null);

  // Settings tab state
  const [bkashNum, setBkashNum] = useState('');
  const [nagadNum, setNagadNum] = useState('');
  const [rocketNum, setRocketNum] = useState('');

  // Ticket reply state
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  useEffect(() => {
    loadAllAdminData();
  }, []);

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [tList, deps, withs, tkts, settDoc, userSnap] = await Promise.all([
        fetchTournaments(),
        fetchDepositRequests(),
        fetchWithdrawalRequests(),
        fetchAllTickets(),
        getDoc(doc(db, 'settings', 'global')),
        getDocs(collection(db, 'users')),
      ]);

      setTournaments(tList);
      setDepositRequests(deps);
      setWithdrawalRequests(withs);
      setTickets(tkts);

      if (settDoc.exists()) {
        const s = settDoc.data() as AppSettings;
        setSettings(s);
        setBkashNum(s.bkashNumber || '');
        setNagadNum(s.nagadNumber || '');
        setRocketNum(s.rocketNumber || '');
      }

      const uList: UserProfile[] = [];
      userSnap.forEach((d) => uList.push(d.data() as UserProfile));
      setUsersList(uList);

      // Fetch room credentials for each tournament
      const rMap: Record<string, RoomCredential> = {};
      await Promise.all(
        tList.map(async (t) => {
          try {
            const r = await fetchRoomCredentials(t.id);
            if (r) rMap[t.id] = r;
          } catch {
            // ignore
          }
        })
      );
      setRoomsMap(rMap);

      if (tList.length > 0) {
        setSelectedTourForRoom(tList[0].id);
        setSelectedTourForScoring(tList[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Load Room Data when tournament selection changes in rooms tab
  useEffect(() => {
    if (selectedTourForRoom) {
      fetchRoomCredentials(selectedTourForRoom).then((r) => {
        if (r) {
          setRoomData(r);
        } else {
          setRoomData({
            id: selectedTourForRoom,
            tournamentId: selectedTourForRoom,
            roomId: '',
            roomPassword: '',
            releaseTime: new Date().toISOString(),
            isPublished: false,
          });
        }
      });
    }
  }, [selectedTourForRoom]);

  // Load Registrations when tournament for scoring changes
  useEffect(() => {
    if (selectedTourForScoring) {
      fetchRegistrationsForTournament(selectedTourForScoring).then((regs) => {
        setScoringRegistrations(regs);
        const map: Record<string, { placement: number; kills: number }> = {};
        regs.forEach((r, idx) => {
          map[r.id] = { placement: idx + 1, kills: 0 };
        });
        setStandingsInput(map);
      });
    }
  }, [selectedTourForScoring]);

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#070B18] p-8 text-center text-white">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-2" />
        <h2 className="text-xl font-bold font-gaming">Access Denied</h2>
        <p className="text-xs text-slate-400 mt-1">
          You do not have administrative permissions to view this control room.
        </p>
      </div>
    );
  }

  // Handle Create Tournament
  const handleCreateTournament = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createTournament(
        {
          ...newTour,
          map: newTour.map || 'Bermuda',
          createdBy: userProfile?.uid || 'admin',
        } as any,
        {
          roomId: newTourRoom.roomId,
          roomPassword: newTourRoom.roomPassword,
          isPublished: newTourRoom.isPublished,
        }
      );
      setShowCreateTourModal(false);
      // Reset form
      setNewTour({
        title: '',
        titleBn: '',
        type: 'SQUAD',
        gameMode: 'BATTLE_ROYALE',
        map: 'Bermuda',
        entryFee: 100,
        prizePool: 2400,
        firstPrize: 1200,
        secondPrize: 600,
        thirdPrize: 300,
        perKillPrize: 10,
        maxSlots: 24,
        status: 'REGISTRATION_OPEN',
        matchDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
        matchTime: '08:00 PM',
        registrationDeadline: new Date(Date.now() + 80000000).toISOString(),
        rules: 'No emulator. Mobile only. No hack/scripts.',
        rulesBn: 'শুধুমাত্র মোবাইল প্লেয়ার। কোনো প্রকার হ্যাক বা এমুলেটর নিষিদ্ধ।',
        bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      });
      setNewTourRoom({ roomId: '', roomPassword: '', isPublished: false });
      await loadAllAdminData();
      alert('নতুন টুর্নামেন্ট সফলভাবে তৈরি হয়েছে! (Tournament created successfully!)');
    } catch (err: unknown) {
      if (err instanceof Error) alert(err.message);
    }
  };

  // Open Edit Tournament Modal
  const handleOpenEditTour = async (t: Tournament) => {
    setEditingTour({ ...t });
    const r = await fetchRoomCredentials(t.id);
    if (r) {
      setEditingTourRoom(r);
    } else {
      setEditingTourRoom({
        id: t.id,
        tournamentId: t.id,
        roomId: '',
        roomPassword: '',
        releaseTime: t.matchDate || new Date().toISOString(),
        isPublished: false,
      });
    }
    setShowEditTourModal(true);
  };

  // Update Tournament Submission
  const handleUpdateTournament = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTour) return;
    try {
      await updateTournament(editingTour.id, {
        title: editingTour.title,
        titleBn: editingTour.titleBn,
        type: editingTour.type,
        gameMode: editingTour.gameMode,
        map: editingTour.map || 'Bermuda',
        entryFee: Number(editingTour.entryFee),
        prizePool: Number(editingTour.prizePool),
        firstPrize: Number(editingTour.firstPrize),
        secondPrize: Number(editingTour.secondPrize),
        thirdPrize: Number(editingTour.thirdPrize),
        perKillPrize: Number(editingTour.perKillPrize),
        maxSlots: Number(editingTour.maxSlots),
        status: editingTour.status,
        matchDate: editingTour.matchDate,
        matchTime: editingTour.matchTime,
        bannerUrl: editingTour.bannerUrl,
        rules: editingTour.rules,
        rulesBn: editingTour.rulesBn,
      });

      if (editingTourRoom) {
        await saveRoomCredentials(editingTourRoom);
      }

      setShowEditTourModal(false);
      await loadAllAdminData();
      alert('টুর্নামেন্ট সফলভাবে আপডেট করা হয়েছে! (Tournament updated successfully!)');
    } catch (err: unknown) {
      if (err instanceof Error) alert(err.message);
    }
  };

  // Open Quick Room Modal
  const handleOpenQuickRoom = async (t: Tournament) => {
    setQuickRoomTour(t);
    const r = await fetchRoomCredentials(t.id);
    if (r) {
      setQuickRoomData(r);
    } else {
      setQuickRoomData({
        id: t.id,
        tournamentId: t.id,
        roomId: '',
        roomPassword: '',
        releaseTime: t.matchDate || new Date().toISOString(),
        isPublished: false,
      });
    }
    setShowQuickRoomModal(true);
  };

  // Save Quick Room Modal
  const handleSaveQuickRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await saveRoomCredentials(quickRoomData);
      setShowQuickRoomModal(false);
      await loadAllAdminData();
      alert('রুম আইডি ও পাসওয়ার্ড সফলভাবে সংরক্ষিত হয়েছে! (Room credentials saved successfully!)');
    } catch (err: unknown) {
      if (err instanceof Error) alert(err.message);
    }
  };

  // Delete Tournament with Confirmation
  const handleDeleteTournament = async (id: string, title: string) => {
    if (
      window.confirm(
        `আপনি কি নিশ্চিত যে "${title}" টুর্নামেন্টটি মুছে ফেলতে চান? (Are you sure you want to delete this tournament?)`
      )
    ) {
      try {
        await deleteTournament(id);
        await loadAllAdminData();
        alert('টুর্নামেন্ট মুছে ফেলা হয়েছে! (Tournament deleted successfully!)');
      } catch (err: unknown) {
        if (err instanceof Error) alert(err.message);
      }
    }
  };

  // Wipe All Tournaments
  const handleWipeAllTournaments = async () => {
    if (
      window.confirm(
        'সতর্কতা: আপনি কি নিশ্চিত যে সমস্ত টুর্নামেন্ট মুছে ফেলতে চান? (Delete ALL tournaments?)'
      )
    ) {
      try {
        for (const t of tournaments) {
          await deleteTournament(t.id);
        }
        await loadAllAdminData();
        alert('সমস্ত টুর্নামেন্ট মুছে ফেলা হয়েছে! (All tournaments cleared!)');
      } catch (err: unknown) {
        if (err instanceof Error) alert(err.message);
      }
    }
  };

  // Handle Save Room Credentials (from rooms tab)
  const handleSaveRoom = async () => {
    try {
      await saveRoomCredentials(roomData);
      await loadAllAdminData();
      alert('রুম ক্রেডেনশিয়ালস সফলভাবে সংরক্ষিত হয়েছে! (Room credentials saved successfully!)');
    } catch (err: unknown) {
      if (err instanceof Error) alert(err.message);
    }
  };

  // Handle Approve Deposit
  const handleApproveDeposit = async (id: string) => {
    const res = await adminApproveDeposit(id);
    alert(res.message);
    loadAllAdminData();
  };

  // Handle Reject Deposit
  const handleRejectDeposit = async (id: string) => {
    const reason = window.prompt('Enter rejection reason (e.g. Invalid TrxID):') || 'TrxID not found';
    const res = await adminRejectDeposit(id, reason);
    alert(res.message);
    loadAllAdminData();
  };

  // Handle Approve Withdrawal
  const handleApproveWithdrawal = async (id: string) => {
    const note = window.prompt('Confirmation note (optional):') || 'Paid via merchant/personal account';
    const res = await adminApproveWithdrawal(id, note);
    alert(res.message);
    loadAllAdminData();
  };

  // Handle Reject Withdrawal
  const handleRejectWithdrawal = async (id: string) => {
    const note = window.prompt('Rejection reason:') || 'Incorrect phone number or declined';
    const res = await adminRejectWithdrawal(id, note);
    alert(res.message);
    loadAllAdminData();
  };

  // Handle Save and Publish Scores
  const handlePublishResults = async () => {
    const tour = tournaments.find((t) => t.id === selectedTourForScoring);
    if (!tour) return;

    if (!window.confirm('Are you sure? This will finalize standings and distribute cash prizes to player wallets!')) {
      return;
    }

    setScoringStatusMessage('Calculating scores and distributing prizes...');

    const standings: TeamPlacementResult[] = scoringRegistrations.map((reg) => {
      const input = standingsInput[reg.id] || { placement: 99, kills: 0 };
      const { placementPoints, killPoints, totalPoints } = calculatePoints(
        input.placement,
        input.kills,
        tour.scoringRules?.killPoints || 1
      );

      // Prize won
      let prizeWon = 0;
      if (input.placement === 1) prizeWon += tour.firstPrize || 0;
      else if (input.placement === 2) prizeWon += tour.secondPrize || 0;
      else if (input.placement === 3) prizeWon += tour.thirdPrize || 0;
      prizeWon += input.kills * (tour.perKillPrize || 0);

      return {
        placement: input.placement,
        teamId: reg.teamId || '',
        teamName: reg.teamName || `Squad #${reg.slotNumber}`,
        playerUids: reg.playerUids || [],
        players: reg.players || [],
        kills: input.kills,
        placementPoints,
        killPoints,
        totalPoints,
        prizeWon,
      };
    });

    standings.sort((a, b) => b.totalPoints - a.totalPoints);

    try {
      await saveMatchResult(tour, standings);
      const res = await publishResultAndDistributePrizes(tour.id);
      setScoringStatusMessage(res.message);
      loadAllAdminData();
    } catch (err: unknown) {
      if (err instanceof Error) setScoringStatusMessage(err.message);
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'settings', 'global'), {
        ...settings,
        bkashNumber: bkashNum,
        nagadNumber: nagadNum,
        rocketNumber: rocketNum,
        updatedAt: new Date().toISOString(),
      });
      alert('Platform settings updated successfully!');
    } catch (err: unknown) {
      if (err instanceof Error) alert(err.message);
    }
  };

  // Handle Ticket Reply
  const handleSendTicketReply = async (ticketId: string) => {
    const text = replyText[ticketId];
    if (!text || !text.trim()) return;

    await replyToTicket(
      ticketId,
      {
        senderId: userProfile?.uid || 'admin',
        senderName: userProfile?.displayName || 'Support Team',
        senderRole: 'ADMIN',
        message: text.trim(),
      },
      'RESOLVED'
    );

    setReplyText((prev) => ({ ...prev, [ticketId]: '' }));
    loadAllAdminData();
    alert('Reply sent and ticket resolved!');
  };

  const pendingDeposits = depositRequests.filter((d) => d.status === 'PENDING');
  const pendingWithdrawals = withdrawalRequests.filter((w) => w.status === 'PENDING');

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold font-gaming uppercase tracking-widest">
            <Shield className="w-4 h-4" />
            <span>Master Administration Room</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black font-gaming text-white mt-1">
            TX TOUR BD Admin Control Center
          </h1>
        </div>

        <button
          onClick={() => setShowCreateTourModal(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming text-xs flex items-center gap-1.5 shadow-lg shadow-sky-500/20 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Create Tournament
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 pb-2 text-xs font-gaming tracking-wider no-scrollbar">
        {[
          { id: 'overview', label: 'Analytics' },
          { id: 'tournaments', label: `Tournaments (${tournaments.length})` },
          { id: 'rooms', label: 'Room ID & Password' },
          { id: 'deposits', label: `Deposits (${pendingDeposits.length} Pending)` },
          { id: 'withdrawals', label: `Withdrawals (${pendingWithdrawals.length} Pending)` },
          { id: 'results', label: 'Scoring & Prizes' },
          { id: 'tickets', label: `Tickets (${tickets.length})` },
          { id: 'users', label: `Players (${usersList.length})` },
          { id: 'settings', label: 'Payment Settings' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                : 'bg-[#0D1428] text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 1. OVERVIEW & ANALYTICS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-[#0D1428] border border-sky-500/20">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Users</span>
              <span className="text-2xl font-black font-gaming text-white">{usersList.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0D1428] border border-sky-500/20">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Tournaments</span>
              <span className="text-2xl font-black font-gaming text-sky-400">{tournaments.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0D1428] border border-amber-500/30">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Pending Deposits</span>
              <span className="text-2xl font-black font-gaming text-amber-400">{pendingDeposits.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0D1428] border border-emerald-500/30">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Pending Withdrawals</span>
              <span className="text-2xl font-black font-gaming text-emerald-400">{pendingWithdrawals.length}</span>
            </div>
          </div>

          {/* Quick Action Alerts */}
          {pendingDeposits.length > 0 && (
            <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 flex items-center justify-between">
              <div className="text-xs text-amber-200">
                <span className="font-bold block">
                  {pendingDeposits.length} deposit requests waiting for admin approval.
                </span>
                <span className="text-[11px] text-amber-300/80">Verify TrxIDs to credit player balances.</span>
              </div>
              <button
                onClick={() => setActiveTab('deposits')}
                className="px-3 py-1.5 rounded-lg bg-amber-500 text-black font-bold text-xs"
              >
                Review Deposits
              </button>
            </div>
          )}
        </div>
      )}

      {/* 2. TOURNAMENTS MANAGEMENT */}
      {activeTab === 'tournaments' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-2 border-b border-slate-800">
            <div>
              <h3 className="text-sm sm:text-base font-bold font-gaming uppercase tracking-wider text-sky-400">
                Free Fire টুর্নামেন্ট ম্যানেজমেন্ট ({tournaments.length})
              </h3>
              <p className="text-xs text-slate-400">
                নতুন টুর্নামেন্ট তৈরি করুন, রুম আইডি/পাসওয়ার্ড দিন এবং টুর্নামেন্ট নিয়ন্ত্রণ করুন।
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowCreateTourModal(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-sky-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming text-xs shadow-lg shadow-sky-500/20 cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>নতুন টুর্নামেন্ট তৈরি করুন</span>
              </button>
              {tournaments.length > 0 && (
                <button
                  onClick={handleWipeAllTournaments}
                  title="সব টুর্নামেন্ট মুছে ফেলুন"
                  className="px-3 py-2 rounded-xl bg-red-950/40 hover:bg-red-950 text-red-400 border border-red-500/30 text-xs font-semibold cursor-pointer"
                >
                  সব মুছুন
                </button>
              )}
            </div>
          </div>

          {tournaments.length === 0 ? (
            <div className="text-center py-16 px-4 bg-[#0D1428] rounded-3xl border border-sky-500/20 shadow-2xl max-w-xl mx-auto space-y-4 my-6">
              <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-sky-400 mx-auto shadow-inner">
                <Trophy className="w-8 h-8" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black font-gaming tracking-wide text-white">
                No tournaments yet
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
                বর্তমানে কোনো টুর্নামেন্ট তৈরি করা হয়নি। নতুন ম্যাচ আয়োজন করতে উপরের বা নিচের বাটনে ক্লিক করে টুর্নামেন্ট তৈরি করুন।
              </p>
              <button
                onClick={() => setShowCreateTourModal(true)}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming text-xs shadow-lg shadow-sky-500/25 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>নতুন টুর্নামেন্ট তৈরি করুন</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {tournaments.map((t) => {
                const room = roomsMap[t.id];
                return (
                  <div
                    key={t.id}
                    className="p-5 rounded-2xl bg-[#0D1428] border border-slate-800 hover:border-sky-500/40 transition-all flex flex-col gap-4 text-xs"
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold font-gaming bg-blue-600 text-white">
                          {t.type}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold font-gaming bg-slate-800 text-sky-300">
                          {t.gameMode}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold font-gaming bg-cyan-950 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {t.map || 'Bermuda'}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold font-gaming ${
                            t.status === 'REGISTRATION_OPEN'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                              : t.status === 'ONGOING'
                              ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                              : t.status === 'COMPLETED'
                              ? 'bg-blue-950 text-blue-400 border border-blue-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-400 font-medium">Status:</span>
                        <select
                          value={t.status}
                          onChange={async (e) => {
                            await updateTournament(t.id, { status: e.target.value as any });
                            loadAllAdminData();
                          }}
                          className="px-2 py-1 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-semibold"
                        >
                          <option value="REGISTRATION_OPEN">REGISTRATION_OPEN</option>
                          <option value="REGISTRATION_FULL">REGISTRATION_FULL</option>
                          <option value="ONGOING">ONGOING</option>
                          <option value="COMPLETED">COMPLETED</option>
                          <option value="CANCELLED">CANCELLED</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <h4 className="text-base sm:text-lg font-black text-white tracking-wide">
                          {t.title}
                        </h4>
                        {t.titleBn && (
                          <p className="text-xs text-sky-300/80 font-medium">{t.titleBn}</p>
                        )}
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-slate-400 text-[11px] mt-2">
                          <span className="flex items-center gap-1 text-slate-300">
                            <Calendar className="w-3.5 h-3.5 text-sky-400" />
                            {t.matchDate}
                          </span>
                          <span className="flex items-center gap-1 text-slate-300">
                            <Clock className="w-3.5 h-3.5 text-sky-400" />
                            {t.matchTime}
                          </span>
                          <span className="text-slate-400">
                            ফি: <b className="text-white">{formatBDT(t.entryFee)}</b>
                          </span>
                          <span className="text-slate-400">
                            প্রাইজপুল: <b className="text-emerald-400">{formatBDT(t.prizePool)}</b>
                          </span>
                          <span className="text-slate-400">
                            স্লট: <b className="text-sky-300">{t.registeredCount} / {t.maxSlots}</b>
                          </span>
                        </div>
                      </div>

                      {/* Room Credentials status badge & details */}
                      <div className="w-full md:w-auto p-2.5 rounded-xl bg-[#111D35] border border-slate-700/80 text-xs shrink-0 min-w-[220px]">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                            <KeyRound className="w-3 h-3 text-sky-400" />
                            রুম ক্রেডেনশিয়ালস
                          </span>
                          {room?.isPublished ? (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                              ✓ প্রকাশিত (লাইভ)
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-950/60 text-amber-400 border border-amber-500/30">
                              অপ্রকাশিত
                            </span>
                          )}
                        </div>
                        {room?.roomId ? (
                          <div className="font-mono text-[11px] text-white">
                            <span>ID: <b className="text-sky-300">{room.roomId}</b></span>
                            <span className="mx-1.5 text-slate-600">|</span>
                            <span>Pass: <b className="text-sky-300">{room.roomPassword || 'None'}</b></span>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-500 italic">রুম আইডি দেওয়া হয়নি</span>
                        )}
                      </div>
                    </div>

                    {/* Action buttons bar */}
                    <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-slate-800/80">
                      <button
                        onClick={() => handleOpenQuickRoom(t)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-950/60 hover:bg-sky-900/60 text-sky-300 border border-sky-500/30 font-semibold text-xs cursor-pointer"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>রুম আইডি ও পাসওয়ার্ড</span>
                      </button>

                      <button
                        onClick={() => handleOpenEditTour(t)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-950/60 hover:bg-blue-900/60 text-blue-300 border border-blue-500/30 font-semibold text-xs cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>এডিট টুর্নামেন্ট</span>
                      </button>

                      <button
                        onClick={() => handleDeleteTournament(t.id, t.title)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-950/50 hover:bg-red-950 text-red-400 border border-red-500/30 font-semibold text-xs cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>ডিলিট</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 3. ROOM ID & PASSWORD MANAGEMENT */}
      {activeTab === 'rooms' && (
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 space-y-5">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Publish Match Room ID & Password
          </h3>

          <div className="space-y-4 max-w-lg">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Select Tournament *
              </label>
              <select
                value={selectedTourForRoom}
                onChange={(e) => setSelectedTourForRoom(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs"
              >
                {tournaments.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({t.matchDate} {t.matchTime})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-sky-400 mb-1">
                  Custom Room ID *
                </label>
                <input
                  type="text"
                  value={roomData.roomId}
                  onChange={(e) => setRoomData({ ...roomData, roomId: e.target.value })}
                  placeholder="e.g. 5839201"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-sky-400 mb-1">
                  Room Password *
                </label>
                <input
                  type="text"
                  value={roomData.roomPassword}
                  onChange={(e) => setRoomData({ ...roomData, roomPassword: e.target.value })}
                  placeholder="e.g. 1234"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-mono font-bold"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="checkbox"
                id="publishToggle"
                checked={roomData.isPublished}
                onChange={(e) => setRoomData({ ...roomData, isPublished: e.target.checked })}
                className="rounded border-slate-700 text-sky-500"
              />
              <label htmlFor="publishToggle" className="text-xs text-white font-semibold cursor-pointer">
                Release and make credentials visible to confirmed players now
              </label>
            </div>

            <button
              onClick={handleSaveRoom}
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-sky-500 text-white font-bold font-gaming text-xs rounded-xl shadow-md cursor-pointer"
            >
              Save & Update Room Credentials
            </button>
          </div>
        </div>
      )}

      {/* 4. DEPOSIT REQUESTS APPROVAL */}
      {activeTab === 'deposits' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Player Deposit Verification Queue ({depositRequests.length})
          </h3>

          {depositRequests.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8">No deposit requests.</p>
          ) : (
            <div className="space-y-3">
              {depositRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 rounded-2xl bg-[#0D1428] border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-pink-950 text-pink-400 border border-pink-500/30">
                        {req.method}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-950 text-emerald-400'
                            : req.status === 'REJECTED'
                            ? 'bg-red-950 text-red-400'
                            : 'bg-amber-950 text-amber-400'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <div className="space-y-0.5">
                      <span className="font-bold text-white text-sm block">
                        Amount: {formatBDT(req.amount)} • Sender: {req.senderNumber}
                      </span>
                      <span className="text-sky-300 font-mono tracking-widest block">
                        TrxID: {req.transactionId}
                      </span>
                      <p className="text-[10px] text-slate-400">
                        Player: {req.userName} ({req.userEmail}) • {new Date(req.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {req.status === 'PENDING' ? (
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => handleApproveDeposit(req.id)}
                        className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs"
                      >
                        Approve & Add ৳{req.amount}
                      </button>
                      <button
                        onClick={() => handleRejectDeposit(req.id)}
                        className="flex-1 sm:flex-initial px-3 py-2 bg-red-950 hover:bg-red-900 text-red-400 border border-red-500/30 font-bold rounded-lg text-xs"
                      >
                        Reject
                      </button>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 font-medium">
                      Processed on {new Date(req.processedAt || req.createdAt).toLocaleDateString()}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 5. WITHDRAWALS MANAGEMENT */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Player Withdrawal Payout Queue ({withdrawalRequests.length})
          </h3>

          {withdrawalRequests.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8">No withdrawal requests.</p>
          ) : (
            <div className="space-y-3">
              {withdrawalRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 rounded-2xl bg-[#0D1428] border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-400 border border-purple-500/30">
                        {req.method}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          req.status === 'PAID'
                            ? 'bg-emerald-950 text-emerald-400'
                            : req.status === 'REJECTED'
                            ? 'bg-red-950 text-red-400'
                            : 'bg-amber-950 text-amber-400'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <div className="space-y-0.5">
                      <span className="font-bold text-white text-sm block">
                        Payout: {formatBDT(req.amount)} • To Account: {req.accountNumber}
                      </span>
                      <p className="text-[10px] text-slate-400">
                        Player: {req.userName} ({req.userEmail}) • {new Date(req.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {req.status === 'PENDING' ? (
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => handleApproveWithdrawal(req.id)}
                        className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs"
                      >
                        Mark as Paid (৳{req.amount})
                      </button>
                      <button
                        onClick={() => handleRejectWithdrawal(req.id)}
                        className="flex-1 sm:flex-initial px-3 py-2 bg-red-950 hover:bg-red-900 text-red-400 border border-red-500/30 font-bold rounded-lg text-xs"
                      >
                        Reject & Refund
                      </button>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 font-medium">
                      Status: {req.status}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6. SCORING & PRIZE DISTRIBUTION */}
      {activeTab === 'results' && (
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 space-y-6">
          <div>
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
              Match Result Entry & Atomic Prize Distribution
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select tournament, enter placement rank and kills for each slot. Points will automatically calculate and prizes will be deposited to winner wallets.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Select Tournament
            </label>
            <select
              value={selectedTourForScoring}
              onChange={(e) => setSelectedTourForScoring(e.target.value)}
              className="w-full sm:w-96 px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs"
            >
              {tournaments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.status})
                </option>
              ))}
            </select>
          </div>

          {scoringStatusMessage && (
            <div className="p-3.5 rounded-xl bg-blue-950/60 border border-sky-500/40 text-xs text-sky-300">
              {scoringStatusMessage}
            </div>
          )}

          {scoringRegistrations.length === 0 ? (
            <p className="text-xs text-slate-400 py-4">No registered slots for this match yet.</p>
          ) : (
            <div className="space-y-3">
              <div className="space-y-2">
                {scoringRegistrations.map((reg) => {
                  const input = standingsInput[reg.id] || { placement: 1, kills: 0 };
                  return (
                    <div
                      key={reg.id}
                      className="p-3 rounded-xl bg-[#111D35] border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded bg-sky-950 text-sky-400 font-bold font-gaming flex items-center justify-center">
                          #{reg.slotNumber}
                        </span>
                        <div>
                          <span className="font-bold text-white block">{reg.teamName}</span>
                          <span className="text-[10px] text-slate-400">Leader: {reg.userName}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 w-full sm:w-auto">
                        <div>
                          <label className="block text-[10px] text-slate-400">Placement Rank</label>
                          <input
                            type="number"
                            min="1"
                            value={input.placement}
                            onChange={(e) =>
                              setStandingsInput({
                                ...standingsInput,
                                [reg.id]: { ...input, placement: Number(e.target.value) },
                              })
                            }
                            className="w-20 px-2 py-1 bg-[#070B18] border border-slate-700 rounded text-white text-center font-bold font-gaming"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-slate-400">Total Kills</label>
                          <input
                            type="number"
                            min="0"
                            value={input.kills}
                            onChange={(e) =>
                              setStandingsInput({
                                ...standingsInput,
                                [reg.id]: { ...input, kills: Number(e.target.value) },
                              })
                            }
                            className="w-20 px-2 py-1 bg-[#070B18] border border-slate-700 rounded text-red-400 text-center font-bold font-gaming"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                onClick={handlePublishResults}
                className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold font-gaming text-xs rounded-xl shadow-xl shadow-emerald-500/20 cursor-pointer"
              >
                Publish Official Scores & Distribute Prizes Now
              </button>
            </div>
          )}
        </div>
      )}

      {/* 7. SUPPORT TICKETS */}
      {activeTab === 'tickets' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Player Support Inquiries ({tickets.length})
          </h3>

          <div className="space-y-3">
            {tickets.map((tkt) => (
              <div
                key={tkt.id}
                className="p-5 rounded-2xl bg-[#0D1428] border border-slate-800 space-y-3 text-xs"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-bold text-white text-sm block">{tkt.subject}</span>
                    <span className="text-[10px] text-slate-400">
                      From: {tkt.userName} ({tkt.userEmail}) • Category: {tkt.category}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-400">
                    {tkt.status}
                  </span>
                </div>

                <p className="p-3 rounded-xl bg-[#111D35] text-slate-300 border border-slate-800">
                  {tkt.message}
                </p>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={replyText[tkt.id] || ''}
                    onChange={(e) => setReplyText({ ...replyText, [tkt.id]: e.target.value })}
                    placeholder="Type official admin reply..."
                    className="flex-1 px-3 py-1.5 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs"
                  />
                  <button
                    onClick={() => handleSendTicketReply(tkt.id)}
                    className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg text-xs"
                  >
                    Reply & Resolve
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 8. USERS LIST */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Registered Gamers Directory ({usersList.length})
          </h3>

          <div className="space-y-2">
            {usersList.map((u) => (
              <div
                key={u.uid}
                className="p-3.5 rounded-xl bg-[#0D1428] border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-white block">
                    {u.inGameName || u.displayName} ({u.role})
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {u.email} • FF UID: {u.freeFireUid || 'N/A'} • Phone: {u.phoneNumber || 'N/A'}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-emerald-400 font-bold font-gaming block">
                    {formatBDT(u.walletBalance || 0)}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Tournaments: {u.totalTournaments || 0}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 9. SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 max-w-xl space-y-4">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
            Official Payment Numbers Configuration
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-pink-400 mb-1">
                bKash Number (Send Money)
              </label>
              <input
                type="text"
                value={bkashNum}
                onChange={(e) => setBkashNum(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-orange-400 mb-1">
                Nagad Number (Send Money)
              </label>
              <input
                type="text"
                value={nagadNum}
                onChange={(e) => setNagadNum(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-purple-400 mb-1">
                Rocket Number (Send Money)
              </label>
              <input
                type="text"
                value={rocketNum}
                onChange={(e) => setRocketNum(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs font-mono"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-sky-500 text-white font-bold font-gaming text-xs rounded-xl shadow-md cursor-pointer"
            >
              Save Payment Numbers
            </button>
          </form>
        </div>
      )}

      {/* CREATE TOURNAMENT MODAL */}
      {showCreateTourModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-xl bg-[#0D1428] border border-sky-500/30 rounded-2xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold font-gaming text-white">
                  নতুন টুর্নামেন্ট তৈরি করুন (Create Tournament)
                </h3>
                <p className="text-xs text-slate-400">
                  ম্যাপ, তারিখ, প্রাইজপুল, স্লট এবং রুম আইডি প্রদান করুন
                </p>
              </div>
              <button
                onClick={() => setShowCreateTourModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTournament} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">টুর্নামেন্টের নাম (English) *</label>
                <input
                  type="text"
                  required
                  value={newTour.title}
                  onChange={(e) => setNewTour({ ...newTour, title: e.target.value })}
                  placeholder="e.g. TX BATTLE ROYALE SQUAD #101"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white placeholder-slate-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">টুর্নামেন্টের নাম (বাংলা) *</label>
                <input
                  type="text"
                  required
                  value={newTour.titleBn}
                  onChange={(e) => setNewTour({ ...newTour, titleBn: e.target.value })}
                  placeholder="e.g. টিএক্স ব্যাটেল রয়্যাল স্কোয়াড #১০১"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white placeholder-slate-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ফরম্যাট (Format)</label>
                  <select
                    value={newTour.type}
                    onChange={(e) => setNewTour({ ...newTour, type: e.target.value as any })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  >
                    <option value="SQUAD">SQUAD (স্কোয়াড)</option>
                    <option value="DUO">DUO (ডুও)</option>
                    <option value="SOLO">SOLO (সোলো)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">মোড (Mode)</label>
                  <select
                    value={newTour.gameMode}
                    onChange={(e) => setNewTour({ ...newTour, gameMode: e.target.value as any })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  >
                    <option value="BATTLE_ROYALE">BATTLE ROYALE</option>
                    <option value="CLASH_SQUAD">CLASH SQUAD</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sky-400 font-bold mb-1">ম্যাপ (Map) *</label>
                  <select
                    value={newTour.map || 'Bermuda'}
                    onChange={(e) => setNewTour({ ...newTour, map: e.target.value })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-sky-500/50 rounded-lg text-white font-bold"
                  >
                    <option value="Bermuda">Bermuda (বারমুডা - Default)</option>
                    <option value="Purgatory">Purgatory (পার্গেটোরি)</option>
                    <option value="Kalahari">Kalahari (কালাহারি)</option>
                    <option value="Alpine">Alpine (আলপাইন)</option>
                    <option value="Nextra">Nextra (নেক্সট্রা)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">এন্ট্রি ফি (৳ BDT) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={newTour.entryFee}
                    onChange={(e) => setNewTour({ ...newTour, entryFee: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">মোট প্রাইজপুল (৳ BDT) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={newTour.prizePool}
                    onChange={(e) => setNewTour({ ...newTour, prizePool: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold text-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">টোটাল স্লট (Max Slots) *</label>
                  <input
                    type="number"
                    min="2"
                    required
                    value={newTour.maxSlots}
                    onChange={(e) => setNewTour({ ...newTour, maxSlots: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              {/* Prize breakdown */}
              <div className="p-3 rounded-xl bg-[#111D35] border border-slate-800 space-y-2">
                <span className="text-[11px] font-bold text-slate-300 block">
                  প্রাইজ বন্টন (Prize Breakdown ৳)
                </span>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">১ম প্রাইজ</label>
                    <input
                      type="number"
                      value={newTour.firstPrize || 0}
                      onChange={(e) => setNewTour({ ...newTour, firstPrize: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">২য় প্রাইজ</label>
                    <input
                      type="number"
                      value={newTour.secondPrize || 0}
                      onChange={(e) => setNewTour({ ...newTour, secondPrize: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">৩য় প্রাইজ</label>
                    <input
                      type="number"
                      value={newTour.thirdPrize || 0}
                      onChange={(e) => setNewTour({ ...newTour, thirdPrize: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">প্রতি কিল প্রাইজ</label>
                    <input
                      type="number"
                      value={newTour.perKillPrize || 0}
                      onChange={(e) => setNewTour({ ...newTour, perKillPrize: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ম্যাচ তারিখ (Match Date) *</label>
                  <input
                    type="date"
                    required
                    value={newTour.matchDate}
                    onChange={(e) => setNewTour({ ...newTour, matchDate: e.target.value })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ম্যাচ সময় (Match Time) *</label>
                  <input
                    type="text"
                    required
                    value={newTour.matchTime}
                    onChange={(e) => setNewTour({ ...newTour, matchTime: e.target.value })}
                    placeholder="e.g. 08:30 PM"
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              {/* Room ID and Password Section */}
              <div className="p-3.5 rounded-xl bg-gradient-to-br from-blue-950/60 to-sky-950/40 border border-sky-500/30 space-y-2.5">
                <div className="flex items-center gap-1.5 text-sky-400 font-bold">
                  <KeyRound className="w-4 h-4" />
                  <span>রুম আইডি ও পাসওয়ার্ড (ঐচ্ছিক - এখনই বা পরে দিতে পারেন)</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">রুম ID (Room ID)</label>
                    <input
                      type="text"
                      value={newTourRoom.roomId}
                      onChange={(e) => setNewTourRoom({ ...newTourRoom, roomId: e.target.value })}
                      placeholder="e.g. 6829104"
                      className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-300 mb-1">রুম পাসওয়ার্ড (Password)</label>
                    <input
                      type="text"
                      value={newTourRoom.roomPassword}
                      onChange={(e) => setNewTourRoom({ ...newTourRoom, roomPassword: e.target.value })}
                      placeholder="e.g. 1234"
                      className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="newTourPublish"
                    checked={newTourRoom.isPublished}
                    onChange={(e) => setNewTourRoom({ ...newTourRoom, isPublished: e.target.checked })}
                    className="w-4 h-4 accent-sky-500 cursor-pointer"
                  />
                  <label htmlFor="newTourPublish" className="text-slate-300 text-[11px] cursor-pointer">
                    প্লেয়ারদের জন্য রুম আইডি এখনই লাইভ/পাবলিশ করুন (Publish to players immediately)
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">ব্যানার ইমেজ লিংক (Banner Image URL)</label>
                <input
                  type="url"
                  value={newTour.bannerUrl}
                  onChange={(e) => setNewTour({ ...newTour, bannerUrl: e.target.value })}
                  className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTourModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-semibold cursor-pointer"
                >
                  বাতিল (Cancel)
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming shadow-lg shadow-sky-500/25 cursor-pointer"
                >
                  টুর্নামেন্ট তৈরি করুন (Create Tournament)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT TOURNAMENT MODAL */}
      {showEditTourModal && editingTour && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-xl bg-[#0D1428] border border-blue-500/40 rounded-2xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold font-gaming text-white">
                  টুর্নামেন্ট সম্পাদনা / এডিট (Edit Tournament)
                </h3>
                <p className="text-xs text-sky-400">ID: {editingTour.id}</p>
              </div>
              <button
                onClick={() => setShowEditTourModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdateTournament} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">টুর্নামেন্টের নাম (English) *</label>
                <input
                  type="text"
                  required
                  value={editingTour.title}
                  onChange={(e) => setEditingTour({ ...editingTour, title: e.target.value })}
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">টুর্নামেন্টের নাম (বাংলা) *</label>
                <input
                  type="text"
                  required
                  value={editingTour.titleBn || ''}
                  onChange={(e) => setEditingTour({ ...editingTour, titleBn: e.target.value })}
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ফরম্যাট</label>
                  <select
                    value={editingTour.type}
                    onChange={(e) => setEditingTour({ ...editingTour, type: e.target.value as any })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  >
                    <option value="SQUAD">SQUAD (স্কোয়াড)</option>
                    <option value="DUO">DUO (ডুও)</option>
                    <option value="SOLO">SOLO (সোলো)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">মোড</label>
                  <select
                    value={editingTour.gameMode}
                    onChange={(e) => setEditingTour({ ...editingTour, gameMode: e.target.value as any })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  >
                    <option value="BATTLE_ROYALE">BATTLE ROYALE</option>
                    <option value="CLASH_SQUAD">CLASH SQUAD</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sky-400 font-bold mb-1">ম্যাপ (Map) *</label>
                  <select
                    value={editingTour.map || 'Bermuda'}
                    onChange={(e) => setEditingTour({ ...editingTour, map: e.target.value })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-sky-500/50 rounded-lg text-white font-bold"
                  >
                    <option value="Bermuda">Bermuda (বারমুডা)</option>
                    <option value="Purgatory">Purgatory (পার্গেটোরি)</option>
                    <option value="Kalahari">Kalahari (কালাহারি)</option>
                    <option value="Alpine">Alpine (আলপাইন)</option>
                    <option value="Nextra">Nextra (নেক্সট্রা)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">এন্ট্রি ফি (৳) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={editingTour.entryFee}
                    onChange={(e) => setEditingTour({ ...editingTour, entryFee: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">মোট প্রাইজপুল (৳) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={editingTour.prizePool}
                    onChange={(e) => setEditingTour({ ...editingTour, prizePool: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold text-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">টোটাল স্লট *</label>
                  <input
                    type="number"
                    min="2"
                    required
                    value={editingTour.maxSlots}
                    onChange={(e) => setEditingTour({ ...editingTour, maxSlots: Number(e.target.value) })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 p-3 rounded-xl bg-[#111D35] border border-slate-800">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-0.5">১ম প্রাইজ</label>
                  <input
                    type="number"
                    value={editingTour.firstPrize || 0}
                    onChange={(e) => setEditingTour({ ...editingTour, firstPrize: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-0.5">২য় প্রাইজ</label>
                  <input
                    type="number"
                    value={editingTour.secondPrize || 0}
                    onChange={(e) => setEditingTour({ ...editingTour, secondPrize: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-0.5">৩য় প্রাইজ</label>
                  <input
                    type="number"
                    value={editingTour.thirdPrize || 0}
                    onChange={(e) => setEditingTour({ ...editingTour, thirdPrize: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-0.5">কিল প্রাইজ</label>
                  <input
                    type="number"
                    value={editingTour.perKillPrize || 0}
                    onChange={(e) => setEditingTour({ ...editingTour, perKillPrize: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 bg-[#0D1428] border border-slate-700 rounded text-white text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ম্যাচ তারিখ *</label>
                  <input
                    type="date"
                    required
                    value={editingTour.matchDate}
                    onChange={(e) => setEditingTour({ ...editingTour, matchDate: e.target.value })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ম্যাচ সময় *</label>
                  <input
                    type="text"
                    required
                    value={editingTour.matchTime}
                    onChange={(e) => setEditingTour({ ...editingTour, matchTime: e.target.value })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-amber-400 font-semibold mb-1">স্ট্যাটাস (Status)</label>
                  <select
                    value={editingTour.status}
                    onChange={(e) => setEditingTour({ ...editingTour, status: e.target.value as any })}
                    className="w-full px-2.5 py-2 bg-[#111D35] border border-amber-500/40 rounded-lg text-white font-bold"
                  >
                    <option value="REGISTRATION_OPEN">REGISTRATION_OPEN</option>
                    <option value="REGISTRATION_FULL">REGISTRATION_FULL</option>
                    <option value="ONGOING">ONGOING</option>
                    <option value="COMPLETED">COMPLETED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>
              </div>

              {/* Room ID and Password */}
              {editingTourRoom && (
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-blue-950/60 to-sky-950/40 border border-sky-500/30 space-y-2.5">
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold">
                    <KeyRound className="w-4 h-4" />
                    <span>রুম আইডি ও পাসওয়ার্ড (Room Credentials)</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">রুম ID</label>
                      <input
                        type="text"
                        value={editingTourRoom.roomId}
                        onChange={(e) => setEditingTourRoom({ ...editingTourRoom, roomId: e.target.value })}
                        className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">রুম পাসওয়ার্ড</label>
                      <input
                        type="text"
                        value={editingTourRoom.roomPassword}
                        onChange={(e) => setEditingTourRoom({ ...editingTourRoom, roomPassword: e.target.value })}
                        className="w-full px-2.5 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white font-mono font-bold"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="editTourPublish"
                      checked={editingTourRoom.isPublished}
                      onChange={(e) => setEditingTourRoom({ ...editingTourRoom, isPublished: e.target.checked })}
                      className="w-4 h-4 accent-sky-500 cursor-pointer"
                    />
                    <label htmlFor="editTourPublish" className="text-slate-300 text-[11px] cursor-pointer">
                      প্লেয়ারদের জন্য রুম আইডি পাবলিশ করুন (Published to players)
                    </label>
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditTourModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-semibold cursor-pointer"
                >
                  বাতিল (Cancel)
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming shadow-lg shadow-sky-500/25 cursor-pointer"
                >
                  আপডেট সংরক্ষণ করুন (Save Changes)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK ROOM ID & PASSWORD MODAL */}
      {showQuickRoomModal && quickRoomTour && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-[#0D1428] border border-sky-500/40 rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold font-gaming text-white">রুম আইডি ও পাসওয়ার্ড</h3>
                  <p className="text-[11px] text-slate-400 truncate max-w-[240px]">
                    {quickRoomTour.title}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowQuickRoomModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuickRoom} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  কাস্টম রুম ID (Custom Room ID) *
                </label>
                <input
                  type="text"
                  required
                  value={quickRoomData.roomId}
                  onChange={(e) => setQuickRoomData({ ...quickRoomData, roomId: e.target.value })}
                  placeholder="e.g. 5839201"
                  className="w-full px-3 py-2.5 bg-[#111D35] border border-slate-700 focus:border-sky-400 rounded-xl text-white font-mono font-black text-sm tracking-widest placeholder-slate-600"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  রুম পাসওয়ার্ড (Room Password) *
                </label>
                <input
                  type="text"
                  required
                  value={quickRoomData.roomPassword}
                  onChange={(e) => setQuickRoomData({ ...quickRoomData, roomPassword: e.target.value })}
                  placeholder="e.g. 1234"
                  className="w-full px-3 py-2.5 bg-[#111D35] border border-slate-700 focus:border-sky-400 rounded-xl text-white font-mono font-black text-sm tracking-widest placeholder-slate-600"
                />
              </div>

              <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-500/20 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="quickPublishToggle"
                    checked={quickRoomData.isPublished}
                    onChange={(e) => setQuickRoomData({ ...quickRoomData, isPublished: e.target.checked })}
                    className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
                  />
                  <label htmlFor="quickPublishToggle" className="text-white font-bold text-xs cursor-pointer">
                    প্লেয়ারদের জন্য লাইভ পাবলিশ করুন (Publish to Players)
                  </label>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  পাবলিশ অন করলে রেজিস্টার্ড প্লেয়াররা টুর্নামেন্ট বিস্তারিত পেইজে এবং তাদের ড্যাশবোর্ডে সরাসরি রুম আইডি ও পাসওয়ার্ড দেখতে পাবে।
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowQuickRoomModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-semibold cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming shadow-lg shadow-sky-500/25 cursor-pointer"
                >
                  রুম আইডি সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
