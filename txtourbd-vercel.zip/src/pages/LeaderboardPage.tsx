import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { fetchTopPlayers, DEFAULT_PLACEMENT_POINTS } from '../services/matchResultService';
import { Trophy, Medal, Search, Flame, Target, Award, Crown } from 'lucide-react';

export const LeaderboardPage: React.FC = () => {
  const { language, t, formatBDT } = useLanguage();

  const [players, setPlayers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'ALL_TIME' | 'MONTHLY' | 'WEEKLY'>('ALL_TIME');
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadLeaderboard();
  }, [activeTab]);

  const loadLeaderboard = async () => {
    setLoading(true);
    try {
      const list = await fetchTopPlayers();
      setPlayers(list);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredPlayers = players.filter((p) => {
    const q = search.toLowerCase();
    return (
      (p.inGameName && p.inGameName.toLowerCase().includes(q)) ||
      (p.displayName && p.displayName.toLowerCase().includes(q)) ||
      (p.freeFireUid && p.freeFireUid.toLowerCase().includes(q)) ||
      (p.teamName && p.teamName.toLowerCase().includes(q))
    );
  });

  const top3 = filteredPlayers.slice(0, 3);
  const restPlayers = filteredPlayers.slice(3);

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center max-w-xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold font-gaming uppercase tracking-widest mb-2">
          <Trophy className="w-3.5 h-3.5" />
          <span>Esports Hall of Fame</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black font-gaming tracking-wide text-white">
          {language === 'bn' ? 'প্লেয়ার লিডারবোর্ড ও র‍্যাঙ্কিং' : 'Tournament Leaderboard'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          {language === 'bn'
            ? 'সবচেয়ে বেশি কিল, জয় এবং প্রাইজমানি জিতে নেওয়া শীর্ষ ফ্রি ফায়ার যোদ্ধারা।'
            : 'Top performing Free Fire competitors ranked by total earnings, wins, and kills.'}
        </p>
      </div>

      {/* Categories & Search */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 p-3 rounded-2xl bg-[#0D1428] border border-sky-500/20">
        <div className="flex gap-2 w-full sm:w-auto">
          {(['ALL_TIME', 'MONTHLY', 'WEEKLY'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-bold font-gaming tracking-wider transition-all cursor-pointer ${
                activeTab === tab
                  ? 'bg-sky-500 text-white shadow-md shadow-sky-500/30'
                  : 'bg-[#111D35] text-slate-400 hover:text-white'
              }`}
            >
              {tab === 'ALL_TIME'
                ? language === 'bn' ? 'সর্বকালের সেরা' : 'All-Time'
                : tab === 'MONTHLY'
                ? language === 'bn' ? 'মাসিক' : 'Monthly'
                : language === 'bn' ? 'সাপ্তাহিক' : 'Weekly'}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={language === 'bn' ? 'খেলোয়াড় বা UID খুঁজুন...' : 'Search player or UID...'}
            className="w-full pl-9 pr-3 py-1.5 bg-[#111D35] border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-400 placeholder-slate-500"
          />
        </div>
      </div>

      {/* TOP 3 PODIUM */}
      {top3.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
          {/* 2nd Place */}
          {top3[1] && (
            <div className="order-2 sm:order-1 p-5 rounded-2xl bg-gradient-to-b from-[#111D35] to-[#0D1428] border border-slate-600 shadow-xl text-center space-y-3 relative">
              <span className="w-8 h-8 rounded-full bg-slate-300 text-black font-black font-gaming text-sm flex items-center justify-center mx-auto shadow-md">
                #2
              </span>
              <div>
                <h3 className="text-base font-bold text-white truncate">
                  {top3[1].inGameName || top3[1].displayName}
                </h3>
                <span className="text-[11px] text-sky-400 font-medium">
                  {top3[1].teamName || 'Solo'}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-around text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Kills</span>
                  <span className="font-bold text-red-400">{top3[1].totalKills || 0}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Earnings</span>
                  <span className="font-bold font-gaming text-emerald-400">
                    {formatBDT(top3[1].totalEarnings || 0)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 1st Place Champion */}
          {top3[0] && (
            <div className="order-1 sm:order-2 p-6 rounded-2xl bg-gradient-to-b from-amber-950/40 via-[#111D35] to-[#0D1428] border-2 border-amber-400 shadow-2xl shadow-amber-500/20 text-center space-y-3 relative sm:-translate-y-3">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-300 text-black text-[10px] font-black font-gaming tracking-widest uppercase flex items-center gap-1 shadow-md">
                <Crown className="w-3.5 h-3.5" /> Champion
              </div>
              <span className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-yellow-200 text-black font-black font-gaming text-base flex items-center justify-center mx-auto shadow-lg shadow-amber-400/40">
                #1
              </span>
              <div>
                <h3 className="text-lg font-black font-gaming text-white truncate">
                  {top3[0].inGameName || top3[0].displayName}
                </h3>
                <span className="text-xs text-amber-400 font-semibold">
                  {top3[0].teamName || 'Solo Master'}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-around text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Wins</span>
                  <span className="font-bold text-amber-400">{top3[0].totalWins || 0}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Kills</span>
                  <span className="font-bold text-red-400">{top3[0].totalKills || 0}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Earnings</span>
                  <span className="font-bold font-gaming text-emerald-400">
                    {formatBDT(top3[0].totalEarnings || 0)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 3rd Place */}
          {top3[2] && (
            <div className="order-3 p-5 rounded-2xl bg-gradient-to-b from-[#111D35] to-[#0D1428] border border-amber-700/60 shadow-xl text-center space-y-3 relative">
              <span className="w-8 h-8 rounded-full bg-amber-700 text-white font-black font-gaming text-sm flex items-center justify-center mx-auto shadow-md">
                #3
              </span>
              <div>
                <h3 className="text-base font-bold text-white truncate">
                  {top3[2].inGameName || top3[2].displayName}
                </h3>
                <span className="text-[11px] text-sky-400 font-medium">
                  {top3[2].teamName || 'Solo'}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-around text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Kills</span>
                  <span className="font-bold text-red-400">{top3[2].totalKills || 0}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Earnings</span>
                  <span className="font-bold font-gaming text-emerald-400">
                    {formatBDT(top3[2].totalEarnings || 0)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FULL LEADERBOARD TABLE */}
      <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
        <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
          {language === 'bn' ? 'র‍্যাঙ্কিং তালিকা' : 'Rankings Table'}
        </h3>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-14 rounded-xl bg-slate-900 animate-pulse"></div>
            ))}
          </div>
        ) : restPlayers.length === 0 && top3.length === 0 ? (
          <p className="text-center py-8 text-xs text-slate-400">
            {language === 'bn' ? 'কোনো প্লেয়ার পাওয়া যায়নি।' : 'No players found.'}
          </p>
        ) : (
          <div className="space-y-2">
            {filteredPlayers.map((player, index) => (
              <div
                key={player.uid}
                className="p-3.5 rounded-xl bg-[#111D35] hover:bg-slate-800/80 border border-slate-800 transition-colors flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-lg font-black font-gaming flex items-center justify-center ${
                      index === 0
                        ? 'bg-amber-400 text-black'
                        : index === 1
                        ? 'bg-slate-300 text-black'
                        : index === 2
                        ? 'bg-amber-700 text-white'
                        : 'bg-[#070B18] text-slate-400'
                    }`}
                  >
                    #{index + 1}
                  </span>

                  <div>
                    <span className="font-bold text-white block">
                      {player.inGameName || player.displayName}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      UID: {player.freeFireUid || 'N/A'} • {player.teamName || 'Solo'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-6 text-right">
                  <div className="hidden sm:block">
                    <span className="text-[10px] text-slate-400 block">Kills</span>
                    <span className="font-bold text-red-400">{player.totalKills || 0}</span>
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-[10px] text-slate-400 block">Wins</span>
                    <span className="font-bold text-amber-400">{player.totalWins || 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Earnings</span>
                    <span className="font-bold font-gaming text-emerald-400 text-sm">
                      {formatBDT(player.totalEarnings || 0)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Point Scoring Reference Box */}
      <div className="p-5 rounded-2xl bg-[#0D1428] border border-slate-800 space-y-2 text-xs">
        <span className="text-[10px] uppercase font-bold font-gaming text-sky-400 tracking-wider">
          Scoring Rules Formula (Battle Royale)
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-slate-300">
          <span className="p-2 rounded bg-[#111D35]">1st Place: 12 pts</span>
          <span className="p-2 rounded bg-[#111D35]">2nd Place: 9 pts</span>
          <span className="p-2 rounded bg-[#111D35]">3rd Place: 8 pts</span>
          <span className="p-2 rounded bg-[#111D35]">4th-10th: 7-1 pts</span>
          <span className="p-2 rounded bg-[#111D35] text-red-400 font-bold">Each Kill: +1 pt</span>
        </div>
      </div>
    </div>
  );
};
