import React, { useState, useEffect } from 'react';
import { Tournament, TournamentRegistration, RoomCredential } from '../types';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  fetchTournamentById,
  fetchRegistrationsForTournament,
  fetchRoomCredentials,
} from '../services/tournamentService';
import {
  Calendar,
  Clock,
  Trophy,
  Users,
  ShieldAlert,
  Award,
  KeyRound,
  Copy,
  Check,
  MapPin,
  ArrowLeft,
  Swords,
  AlertTriangle,
  Lock,
} from 'lucide-react';

interface TournamentDetailsProps {
  tournamentId: string;
  onBack: () => void;
  onJoinClick: (tournament: Tournament) => void;
}

export const TournamentDetails: React.FC<TournamentDetailsProps> = ({
  tournamentId,
  onBack,
  onJoinClick,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [registrations, setRegistrations] = useState<TournamentRegistration[]>([]);
  const [roomData, setRoomData] = useState<RoomCredential | null>(null);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);

  useEffect(() => {
    loadDetails();
  }, [tournamentId]);

  const loadDetails = async () => {
    try {
      const [tour, regs, room] = await Promise.all([
        fetchTournamentById(tournamentId),
        fetchRegistrationsForTournament(tournamentId),
        fetchRoomCredentials(tournamentId),
      ]);
      setTournament(tour);
      setRegistrations(regs);
      setRoomData(room);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#070B18] flex items-center justify-center p-8">
        <div className="w-10 h-10 border-4 border-sky-400 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="min-h-screen bg-[#070B18] py-16 px-4 text-center">
        <p className="text-white text-lg font-bold">টুর্নামেন্ট পাওয়া যায়নি!</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 bg-slate-800 text-sky-400 rounded-lg text-sm"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  const isUserRegistered =
    currentUser &&
    registrations.some(
      (r) =>
        r.userId === currentUser.uid ||
        (r.playerUids && r.playerUids.includes(currentUser.uid))
    );

  const isFull = tournament.registeredCount >= tournament.maxSlots;
  const isAvailable =
    tournament.status === 'REGISTRATION_OPEN' && !isFull && !isUserRegistered;

  const copyToClipboard = (text: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } else {
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
  };

  const isRoomTimeReached =
    roomData &&
    roomData.isPublished &&
    (!roomData.releaseTime || new Date() >= new Date(roomData.releaseTime));

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        {language === 'bn' ? 'সব টুর্নামেন্টে ফিরে যান' : 'Back to Tournaments'}
      </button>

      {/* Hero Banner Card */}
      <div className="relative rounded-3xl overflow-hidden border border-sky-500/25 bg-[#0D1428] shadow-2xl mb-8">
        <div className="h-64 sm:h-80 w-full relative">
          <img
            src={
              tournament.bannerUrl ||
              'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80'
            }
            alt=""
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D1428] via-[#0D1428]/60 to-transparent"></div>

          {/* Badges on banner */}
          <div className="absolute top-4 left-4 flex gap-2">
            <span className="px-3 py-1 rounded-md bg-blue-600 text-white font-black font-gaming text-sm tracking-wider shadow-md">
              {tournament.type}
            </span>
            <span className="px-3 py-1 rounded-md bg-slate-900/80 text-sky-400 font-bold text-sm border border-sky-500/30 backdrop-blur-md">
              {tournament.gameMode === 'BATTLE_ROYALE' ? 'Battle Royale' : 'Clash Squad'}
            </span>
          </div>

          {/* Map tag */}
          {tournament.map && (
            <div className="absolute bottom-4 left-4 flex items-center gap-1.5 text-xs text-white font-semibold bg-black/60 px-3 py-1 rounded-lg backdrop-blur-sm border border-slate-700">
              <MapPin className="w-3.5 h-3.5 text-sky-400" />
              <span>Map: {tournament.map}</span>
            </div>
          )}
        </div>

        {/* Tournament Info Header */}
        <div className="p-6 sm:p-8 -mt-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-black font-gaming tracking-wide text-white">
                {language === 'bn' && tournament.titleBn ? tournament.titleBn : tournament.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 mt-2">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4 text-sky-400" />
                  {tournament.matchDate}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-sky-400" />
                  {tournament.matchTime} (Asia/Dhaka)
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4 text-sky-400" />
                  {tournament.registeredCount} / {tournament.maxSlots} Slots
                </span>
              </div>
            </div>

            {/* Quick Action */}
            {isUserRegistered ? (
              <span className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-xs flex items-center gap-2">
                <Check className="w-4 h-4" />
                {language === 'bn' ? 'স্লট নিশ্চিত হয়েছে' : 'Slot Confirmed'}
              </span>
            ) : isAvailable ? (
              <button
                onClick={() => onJoinClick(tournament)}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white font-bold font-gaming tracking-wider text-sm shadow-xl shadow-sky-500/25 transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                {t('tournaments.joinNow')}
              </button>
            ) : isFull ? (
              <span className="px-4 py-2 rounded-xl bg-red-500/20 text-red-400 border border-red-500/40 font-bold text-xs">
                {t('tournaments.full')}
              </span>
            ) : (
              <span className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400 font-bold text-xs">
                {tournament.status}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: Details & Room Credentials */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 Cols): Prize Breakdown & Rules */}
        <div className="lg:col-span-2 space-y-6">
          {/* Prize Distribution Box */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-lg">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 mb-4 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              {language === 'bn' ? 'প্রাইজ ডিস্ট্রিবিউশন' : 'Prize Pool Distribution'}
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl bg-[#111D35] border border-amber-500/30 text-center">
                <span className="text-[10px] uppercase font-bold text-amber-400 block">
                  🥇 1st Place
                </span>
                <span className="text-base font-black font-gaming text-white">
                  {formatBDT(tournament.firstPrize || 0)}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-700 text-center">
                <span className="text-[10px] uppercase font-bold text-slate-300 block">
                  🥈 2nd Place
                </span>
                <span className="text-base font-black font-gaming text-white">
                  {formatBDT(tournament.secondPrize || 0)}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-700 text-center">
                <span className="text-[10px] uppercase font-bold text-amber-700 block">
                  🥉 3rd Place
                </span>
                <span className="text-base font-black font-gaming text-white">
                  {formatBDT(tournament.thirdPrize || 0)}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#111D35] border border-sky-500/30 text-center">
                <span className="text-[10px] uppercase font-bold text-sky-400 block">
                  🎯 Per Kill
                </span>
                <span className="text-base font-black font-gaming text-white">
                  {formatBDT(tournament.perKillPrize || 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Tournament Rules & Fair Play */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-lg">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 mb-3 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4" />
              {language === 'bn' ? 'টুর্নামেন্টের নিয়মাবলী' : 'Rules & Guidelines'}
            </h3>

            <div className="p-4 rounded-xl bg-[#111D35]/60 text-xs text-slate-300 leading-relaxed whitespace-pre-line border border-slate-800">
              {language === 'bn' && tournament.rulesBn ? tournament.rulesBn : tournament.rules}
            </div>

            <div className="mt-4 p-3 rounded-xl bg-amber-950/30 border border-amber-500/25 flex items-start gap-2.5 text-xs text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? 'নো হ্যাক, নো স্ক্রিপ্ট, নো এমুলেটর। কোনো খেলোয়াড় বা স্কোয়াড অসদুপায় অবলম্বন করলে তৎক্ষণাৎ আজীবনের জন্য ব্যান ও প্রাইজ বাতিল করা হবে।'
                  : 'Zero tolerance for emulators, third-party scripts, or modified APKs. Violations result in permanent hardware ban and forfeiture of all prizes.'}
              </span>
            </div>
          </div>

          {/* Registered Teams / Slots Table */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-lg">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 mb-3 flex items-center gap-2">
              <Users className="w-4 h-4" />
              {language === 'bn' ? 'নিবন্ধিত স্লট ও স্কোয়াড তালিকা' : 'Registered Slots & Rosters'} (
              {registrations.length})
            </h3>

            {registrations.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">
                {language === 'bn'
                  ? 'এখনও কোনো স্লট বুক করা হয়নি। প্রথম স্লটটি বুক করুন!'
                  : 'No slots booked yet. Be the first to secure your slot!'}
              </p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {registrations.map((reg) => (
                  <div
                    key={reg.id}
                    className="p-3 rounded-xl bg-[#111D35] border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-md bg-sky-950 text-sky-400 font-bold font-gaming flex items-center justify-center border border-sky-500/30">
                        #{reg.slotNumber}
                      </span>
                      <div>
                        <span className="font-bold text-white block">{reg.teamName}</span>
                        <span className="text-[11px] text-slate-400">
                          Leader: {reg.userName}
                        </span>
                      </div>
                    </div>

                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Confirmed
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Secure Match Room Credentials Box */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#0D1428] border-2 border-sky-500/40 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-center gap-2 text-sky-400 font-gaming uppercase tracking-wider text-xs font-bold mb-3">
              <KeyRound className="w-4 h-4" />
              <span>{t('room.title')}</span>
            </div>

            {/* Check Authorization */}
            {isUserRegistered || isAdmin ? (
              roomData && roomData.isPublished && roomData.roomId ? (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-xl bg-[#111D35] border border-sky-500/30 space-y-3">
                    {/* Room ID */}
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                        {t('room.id')}
                      </span>
                      <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070B18] border border-slate-700">
                        <span className="text-base font-black font-gaming tracking-widest text-sky-300">
                          {roomData.roomId}
                        </span>
                        <button
                          onClick={() => copyToClipboard(roomData.roomId, 'id')}
                          className="px-2 py-1 text-xs rounded bg-sky-600/30 text-sky-400 hover:bg-sky-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          {copiedId ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          {copiedId ? t('room.copied') : t('room.copy')}
                        </button>
                      </div>
                    </div>

                    {/* Room Password */}
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                        {t('room.password')}
                      </span>
                      <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070B18] border border-slate-700">
                        <span className="text-base font-black font-gaming tracking-widest text-sky-300">
                          {roomData.roomPassword}
                        </span>
                        <button
                          onClick={() => copyToClipboard(roomData.roomPassword, 'pass')}
                          className="px-2 py-1 text-xs rounded bg-sky-600/30 text-sky-400 hover:bg-sky-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          {copiedPass ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          {copiedPass ? t('room.copied') : t('room.copy')}
                        </button>
                      </div>
                    </div>
                  </div>

                  <p className="text-[11px] text-emerald-400 flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5" />
                    {language === 'bn'
                      ? 'রুম আইডি কপি করে ফ্রি ফায়ার গেমে কাস্টম রুমে প্রবেশ করুন।'
                      : 'Copy Room credentials and enter custom lobby in Free Fire.'}
                  </p>
                </div>
              ) : (
                /* Room Waiting State */
                <div className="p-4 rounded-xl bg-[#111D35]/80 border border-slate-800 text-center space-y-3">
                  <Clock className="w-8 h-8 text-sky-400 mx-auto animate-pulse" />
                  <h4 className="text-xs font-bold text-white">
                    {language === 'bn' ? 'রুম তথ্য প্রকাশের অপেক্ষায়' : 'Room Release Pending'}
                  </h4>
                  <p className="text-[11px] text-slate-400">{t('room.waiting')}</p>
                </div>
              )
            ) : (
              /* Unauthorized view */
              <div className="p-4 rounded-xl bg-[#111D35]/80 border border-slate-800 text-center space-y-3">
                <Lock className="w-8 h-8 text-slate-500 mx-auto" />
                <h4 className="text-xs font-bold text-white">
                  {language === 'bn' ? 'রুম আইডি লক করা আছে' : 'Room Credentials Protected'}
                </h4>
                <p className="text-[11px] text-slate-400">{t('room.warning')}</p>
                {isAvailable && (
                  <button
                    onClick={() => onJoinClick(tournament)}
                    className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-lg font-gaming tracking-wider cursor-pointer"
                  >
                    {t('tournaments.joinNow')}
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Quick Organizer Contact Box */}
          <div className="p-5 rounded-2xl bg-[#0D1428] border border-slate-800 text-xs text-slate-300 space-y-2">
            <span className="text-[10px] text-sky-400 font-bold font-gaming uppercase tracking-wider block">
              Organizer Support
            </span>
            <p className="font-semibold text-white">TX TOUR BD Official Moderator</p>
            <p className="text-slate-400">
              যেকোনো রুম সংক্রান্ত সমস্যা বা বিরোধের ক্ষেত্রে আমাদের হোয়াটসঅ্যাপ হেল্পলাইনে মেসেজ দিন।
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
