import React, { useState, useEffect } from 'react';
import { Tournament, UserProfile } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { TournamentCard } from '../components/tournament/TournamentCard';
import { fetchTournaments } from '../services/tournamentService';
import { fetchTopPlayers } from '../services/matchResultService';
import {
  Trophy,
  Swords,
  Users,
  ShieldCheck,
  Zap,
  Flame,
  ArrowRight,
  Clock,
  CheckCircle,
  HelpCircle,
  Smartphone,
  ChevronRight,
  ExternalLink,
  Plus,
} from 'lucide-react';
import { TXLogo } from '../components/common/TXLogo';

interface HomeProps {
  onNavigate: (page: string, params?: any) => void;
  onJoinClick: (tournament: Tournament) => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate, onJoinClick }) => {
  const { language, t, formatBDT } = useLanguage();
  const { currentUser, isAdmin } = useAuth();

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [topPlayers, setTopPlayers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [tList, pList] = await Promise.all([
        fetchTournaments(),
        fetchTopPlayers(),
      ]);
      setTournaments(tList);
      setTopPlayers(pList.slice(0, 5));
    } catch (err) {
      console.error('Error loading home data', err);
    } finally {
      setLoading(false);
    }
  };

  const featuredTournaments = tournaments.slice(0, 3);

  const stats = [
    {
      label: t('hero.activeTournaments'),
      value: tournaments.filter((t) => t.status === 'REGISTRATION_OPEN').length || '12',
      icon: Swords,
      color: 'from-blue-600 to-sky-400',
    },
    {
      label: t('hero.totalPrizes'),
      value: '৳৪,৫০,০০০+',
      icon: Trophy,
      color: 'from-amber-500 to-yellow-300',
    },
    {
      label: t('hero.registeredPlayers'),
      value: '১২,৫০০+',
      icon: Users,
      color: 'from-emerald-500 to-teal-300',
    },
    {
      label: t('hero.dailyMatches'),
      value: '২০+ ম্যাচ',
      icon: Flame,
      color: 'from-red-500 to-rose-400',
    },
  ];

  const steps = [
    {
      step: '০১',
      title: language === 'bn' ? 'ফ্রি একাউন্ট খুলুন' : 'Create Account',
      desc:
        language === 'bn'
          ? 'নাম, ফোন ও Free Fire UID দিয়ে কয়েক সেকেন্ডে আপনার প্লেয়ার প্রোফাইল তৈরি করুন।'
          : 'Set up your player profile in seconds with your name, phone & Free Fire UID.',
    },
    {
      step: '০২',
      title: language === 'bn' ? 'ওয়ালেট রিচার্জ করুন' : 'Add Funds to Wallet',
      desc:
        language === 'bn'
          ? 'বিকাশ, নগদ বা রকেটের মাধ্যমে নিরাপদে ওয়ালেটে টাকা ডিপোজিট করুন।'
          : 'Quick and safe deposits using bKash, Nagad, or Rocket mobile wallets.',
    },
    {
      step: '০৩',
      title: language === 'bn' ? 'স্লট বুক করুন' : 'Book Match Slot',
      desc:
        language === 'bn'
          ? 'সোলো, ডুও অথবা স্কোয়াড টুর্নামেন্ট বেছে নিয়ে আপনার পছন্দের স্লট নিশ্চিত করুন।'
          : 'Choose your preferred Solo, Duo, or Squad match and confirm your slot.',
    },
    {
      step: '০৪',
      title: language === 'bn' ? 'রুম আইডি পেয়ে প্রাইজ জিতুন' : 'Get Room ID & Win Cash',
      desc:
        language === 'bn'
          ? 'ম্যাচ শুরুর আগে রুম ক্রেডেনশিয়ালস নিন, যুদ্ধ জয় করে জিতে নিন নগদ টাকা।'
          : 'Receive match room details on time, dominate the match, and collect real cash prizes.',
    },
  ];

  const features = [
    {
      icon: Zap,
      title: language === 'bn' ? 'তাৎক্ষণিক রুম আইডি' : 'Instant Room Credentials',
      desc:
        language === 'bn'
          ? 'ম্যাচ শুরুর ঠিক ১০-১৫ মিনিট পূর্বে প্ল্যাটফর্মে অটোমেটিক সঠিক রুম আইডি ও পাসওয়ার্ড প্রকাশ পায়।'
          : 'Accurate Room ID & Password published automatically 10-15 minutes prior to match schedule.',
    },
    {
      icon: Trophy,
      title: language === 'bn' ? 'গ্যারান্টিড প্রাইজ পেআউট' : 'Guaranteed Prize Payouts',
      desc:
        language === 'bn'
          ? 'ম্যাচ সমাপ্তির পর ফলাফল যাচাই করে তাৎক্ষণিকভাবে ওয়ালেটে উইনিং ব্যালেন্স যোগ হয়।'
          : 'Winnings credited swiftly to player wallets and withdrawable directly to bKash or Nagad.',
    },
    {
      icon: ShieldCheck,
      title: language === 'bn' ? '১০০% ফেয়ার প্লে ও নো হ্যাক' : '100% Anti-Cheat & Fair Play',
      desc:
        language === 'bn'
          ? 'এমুলেটর নিষিদ্ধ ও সার্বক্ষণিক অ্যাডমিন পর্যবেক্ষণ। কোনো হ্যাকারকে প্রশ্রয় দেওয়া হয় না।'
          : 'Strict anti-cheat policy, emulator bans, and dedicated esports moderators overseeing matches.',
    },
    {
      icon: Smartphone,
      title: language === 'bn' ? 'মোবাইল ফ্রেন্ডলি প্ল্যাটফর্ম' : 'Mobile First Experience',
      desc:
        language === 'bn'
          ? 'স্মার্টফোনে অত্যন্ত মসৃণ এবং দ্রুতগতির ইন্টারফেস, যাতে গেমাররা নির্বিঘ্নে খেলতে পারেন।'
          : 'Engineered specifically for low-latency smartphone navigation and quick slot reservation.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#070B18] text-white">
      {/* HERO SECTION */}
      <section className="relative pt-12 pb-20 overflow-hidden bg-gaming-gradient">
        {/* Glow Spheres */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-20 right-10 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          {/* Top Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-500/10 border border-sky-400/30 text-sky-300 text-xs font-semibold mb-6 animate-pulse">
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>{t('hero.badge')}</span>
          </div>

          {/* Main Esports Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black font-gaming tracking-wide uppercase leading-tight mb-4">
            <span className="block text-white filter drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">
              {t('hero.title1')}
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-blue-500 to-indigo-400 filter drop-shadow-[0_0_25px_rgba(56,189,248,0.4)]">
              {t('hero.title2')}
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300 mb-8 leading-relaxed">
            {t('hero.subtitle')}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 mb-14">
            <button
              onClick={() => onNavigate('tournaments')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-sky-500 to-blue-600 hover:from-blue-500 hover:to-sky-400 text-white font-bold font-gaming tracking-wider text-sm shadow-xl shadow-sky-500/25 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Swords className="w-4 h-4" />
              {t('hero.joinBtn')}
            </button>

            <button
              onClick={() => onNavigate('tournaments')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#111D35]/80 hover:bg-[#111D35] border border-sky-500/30 text-sky-300 hover:text-white font-bold font-gaming tracking-wider text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {t('hero.browseBtn')}
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Live Platform Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto">
            {stats.map((s, idx) => {
              const Icon = s.icon;
              return (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-[#0D1428]/90 border border-sky-500/15 backdrop-blur-md shadow-lg flex flex-col items-center justify-center group hover:border-sky-400/40 transition-colors"
                >
                  <div
                    className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.color} p-2 flex items-center justify-center text-white mb-2 shadow-md`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xl sm:text-2xl font-black font-gaming tracking-wide text-white">
                    {s.value}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium text-center mt-0.5">
                    {s.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FEATURED TOURNAMENTS SECTION */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-2 mb-8 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
              <Trophy className="w-4 h-4" />
              <span>{language === 'bn' ? 'চলমান টুর্নামেন্ট' : 'Featured Esports Matches'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-gaming tracking-wide text-white mt-1">
              {t('tournaments.title')}
            </h2>
          </div>

          <button
            onClick={() => onNavigate('tournaments')}
            className="flex items-center gap-1.5 text-xs font-bold text-sky-400 hover:text-sky-300 font-gaming tracking-wider cursor-pointer"
          >
            <span>{language === 'bn' ? 'সব দেখুন' : 'View All Tournaments'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-80 rounded-2xl bg-slate-900/60 animate-pulse border border-slate-800"></div>
            ))}
          </div>
        ) : featuredTournaments.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-3xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4 max-w-2xl mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-sky-400 mx-auto">
              <Trophy className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold font-gaming text-white">
              No tournaments yet
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              {language === 'bn'
                ? 'বর্তমানে কোনো টুর্নামেন্ট নেই। এডমিন প্যানেল থেকে খুব শীঘ্রই নতুন টুর্নামেন্ট যোগ করা হবে।'
                : 'There are currently no tournaments available. Check back soon for new match announcements!'}
            </p>
            {isAdmin && (
              <button
                onClick={() => onNavigate('admin')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming text-xs shadow-lg shadow-sky-500/25 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                {language === 'bn' ? 'নতুন টুর্নামেন্ট যোগ করুন' : 'Create Tournament in Admin Panel'}
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredTournaments.map((tournament) => (
              <TournamentCard
                key={tournament.id}
                tournament={tournament}
                onSelect={(tour) => onNavigate('tournamentDetails', { id: tour.id })}
                onJoin={(tour) => onJoinClick(tour)}
              />
            ))}
          </div>
        )}
      </section>

      {/* HOW TO PARTICIPATE */}
      <section className="py-16 bg-[#0D1428]/60 border-y border-sky-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
              {language === 'bn' ? 'সহজ চার ধাপ' : 'Easy 4 Steps'}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black font-gaming tracking-wide text-white mt-1">
              {language === 'bn' ? 'কিভাবে টুর্নামেন্টে অংশ নেবেন?' : 'How To Participate & Win'}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {steps.map((st, i) => (
              <div
                key={i}
                className="relative p-5 rounded-2xl bg-[#111D35]/70 border border-slate-800 hover:border-sky-500/40 transition-all group"
              >
                <div className="text-3xl font-black font-gaming text-sky-500/30 group-hover:text-sky-400 transition-colors mb-2">
                  {st.step}
                </div>
                <h3 className="text-base font-bold text-white mb-2">{st.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{st.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE TX TOUR BD */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
            {language === 'bn' ? 'সেরা অভিজ্ঞতা' : 'Esports Standard'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-black font-gaming tracking-wide text-white mt-1">
            {language === 'bn' ? 'কেন TX TOUR BD বেছে নেবেন?' : 'Why Choose TX TOUR BD'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 hover:border-sky-400/50 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-sky-400 mb-4">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-2">{f.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{f.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* TOP PLAYERS LEADERBOARD PREVIEW */}
      {topPlayers.length > 0 && (
        <section className="py-12 bg-[#090E1F] border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <span className="text-amber-400 text-xs font-bold font-gaming uppercase tracking-widest">
                  {language === 'bn' ? 'শীর্ষ চ্যাম্পিয়ন' : 'Hall of Fame'}
                </span>
                <h2 className="text-2xl font-black font-gaming text-white">
                  {language === 'bn' ? 'টপ প্লেয়ার লিডারবোর্ড' : 'Top Performing Players'}
                </h2>
              </div>
              <button
                onClick={() => onNavigate('leaderboard')}
                className="text-xs font-bold text-sky-400 hover:text-sky-300 font-gaming tracking-wider flex items-center gap-1 cursor-pointer"
              >
                {language === 'bn' ? 'সম্পূর্ণ লিডারবোর্ড' : 'Full Leaderboard'}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {topPlayers.slice(0, 3).map((p, idx) => (
                <div
                  key={p.uid}
                  className="p-4 rounded-xl bg-[#111D35] border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center font-black font-gaming text-sm ${
                        idx === 0
                          ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/30'
                          : idx === 1
                          ? 'bg-slate-300 text-black'
                          : 'bg-amber-700 text-white'
                      }`}
                    >
                      #{idx + 1}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white truncate max-w-[130px]">
                        {p.inGameName || p.displayName}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {p.totalWins || 0} Wins • {p.totalKills || 0} Kills
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-medium">Earnings</span>
                    <span className="text-xs font-extrabold font-gaming text-sky-400">
                      {formatBDT(p.totalEarnings || 0)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* FOOTER */}
      <footer className="bg-[#050811] border-t border-slate-800/80 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <TXLogo size="md" />
            <p className="text-xs text-slate-400 leading-relaxed">
              {language === 'bn'
                ? 'বাংলাদেশের সেরা ফ্রি ফায়ার টুর্নামেন্ট ম্যানেজমেন্ট প্ল্যাটফর্ম। প্রতিদিন কাস্টম রুম খেলুন এবং জিতে নিন আসল প্রাইজমানি।'
                : "Bangladesh's leading competitive Free Fire tournament platform. Compete daily in custom rooms and win authentic cash payouts."}
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold font-gaming tracking-wider uppercase text-sky-400 mb-3">
              {language === 'bn' ? 'দ্রুত লিংক' : 'Quick Links'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavigate('tournaments')} className="hover:text-white cursor-pointer">
                  {t('nav.tournaments')}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('leaderboard')} className="hover:text-white cursor-pointer">
                  {t('nav.leaderboard')}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('rules')} className="hover:text-white cursor-pointer">
                  {t('nav.rules')}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('support')} className="hover:text-white cursor-pointer">
                  {t('nav.support')}
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold font-gaming tracking-wider uppercase text-sky-400 mb-3">
              {language === 'bn' ? 'পেমেন্ট মেথড' : 'Payment Methods'}
            </h4>
            <div className="flex gap-2">
              <span className="px-2.5 py-1 rounded bg-[#111D35] text-pink-400 font-bold text-xs border border-pink-500/20">
                bKash
              </span>
              <span className="px-2.5 py-1 rounded bg-[#111D35] text-orange-400 font-bold text-xs border border-orange-500/20">
                Nagad
              </span>
              <span className="px-2.5 py-1 rounded bg-[#111D35] text-purple-400 font-bold text-xs border border-purple-500/20">
                Rocket
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              {language === 'bn'
                ? 'দ্রুততম উইথড্র ও ডিপোজিট প্রসেসিং।'
                : 'Fastest deposit & withdrawal processing guaranteed.'}
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold font-gaming tracking-wider uppercase text-sky-400 mb-3">
              {language === 'bn' ? 'যোগাযোগ' : 'Official Support'}
            </h4>
            <p className="text-xs text-slate-400">WhatsApp: +880 1602-570739</p>
            <p className="text-xs text-slate-400 mt-1">Email: support@txtourbd.com</p>
            <p className="text-xs text-slate-500 mt-3">
              © {new Date().getFullYear()} TX TOUR BD. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
