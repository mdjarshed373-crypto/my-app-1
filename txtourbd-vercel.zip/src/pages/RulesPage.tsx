import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ShieldAlert, Trophy, Award, AlertTriangle, CheckCircle, Smartphone } from 'lucide-react';

export const RulesPage: React.FC = () => {
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
          <ShieldAlert className="w-4 h-4" />
          <span>Esports Code of Conduct</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-gaming text-white mt-1">
          {language === 'bn' ? 'টুর্নামেন্ট নিয়মাবলী ও নীতি' : 'Official Tournament Rules & Policies'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          {language === 'bn'
            ? 'TX TOUR BD-এর সকল প্রতিযোগিতা শতভাগ নিরপেক্ষ, সুরক্ষিত ও পেশাদার রাখতে নিচের নিয়মাবলী বাধ্যতামূলক।'
            : 'Standard tournament guidelines ensuring fair play, integrity, and safety for all Bangladeshi gamers.'}
        </p>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Anti-Cheat & Fair Play */}
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-3">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-red-400 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            ১. নো হ্যাক ও এমুলেটর নিষেধাজ্ঞা
          </h3>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li>শুধুমাত্র মোবাইল ডিভাইস (Android / iOS) দিয়ে খেলা যাবে। পিসি বা ব্লুস্ট্যাক্স এমুলেটর সম্পূর্ণ নিষিদ্ধ।</li>
            <li>কোনো প্রকার অটো-এম, ওয়ালহ্যাক, স্ক্রিপ্ট বা কনফিগ ফাইল ব্যবহার করলে তাৎক্ষণিক ডিভাইস ব্যান।</li>
            <li>সোলো টুর্নামেন্টে টিমিং (Teaming) করা গুরুতর অপরাধ। টিমিং ধরা পড়লে উভয়েরই প্রাইজ বাজেয়াপ্ত হবে।</li>
          </ul>
        </div>

        {/* Room & Match Schedule */}
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-3">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            ২. রুম আইডি ও ম্যাচ উপস্থিতি
          </h3>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li>ম্যাচ শুরুর ঠিক ১০-১৫ মিনিট পূর্বে প্ল্যাটফর্মে রুম আইডি ও পাসওয়ার্ড প্রকাশ করা হবে।</li>
            <li>স্লট নিশ্চিতকারী প্লেয়ারকে নির্ধারিত সময়ের কমপক্ষে ৫ মিনিট পূর্বে কাস্টম রুমে প্রবেশ করতে হবে।</li>
            <li>নির্ধারিত সময়ের পর ম্যাচ শুরু হয়ে গেলে কোনো প্লেয়ার না ঢুকতে পারলে এন্ট্রি ফি রিফান্ড হবে না।</li>
          </ul>
        </div>

        {/* Prize Distribution & Verification */}
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-3">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-amber-400 flex items-center gap-2">
            <Trophy className="w-4 h-4" />
            ৩. ফলাফল প্রকাশ ও প্রাইজমানি
          </h3>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li>ম্যাচ শেষে এডমিন ম্যাচ রেজাল্ট ও কিল সংখ্যা যাচাই করে অফিসিয়াল স্কোরকার্ড প্রকাশ করবেন।</li>
            <li>স্কোরকার্ড প্রকাশের পর বিজয়ীদের ওয়ালেটে সরাসরি প্রাইজমানি যোগ করে দেওয়া হবে।</li>
            <li>ওয়ালেটের টাকা বিকাশ, নগদ বা রকেটের মাধ্যমে যেকোনো সময় উইথড্র করা যাবে।</li>
          </ul>
        </div>

        {/* Refund Policy */}
        <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-3">
          <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            ৪. বাতিল ও রিফান্ড নীতি
          </h3>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li>যদি কোনো অনিবার্য কারণে বা সার্ভার সমস্যার জন্য টুর্নামেন্ট বাতিল হয়, তবে সকল প্লেয়ারের এন্ট্রি ফি ওয়ালেটে ১০০% রিফান্ড করা হবে।</li>
            <li>পর্যাপ্ত স্লট পূর্ণ না হলেও টুর্নামেন্ট বাতিল করে পূর্ণ রিফান্ড নিশ্চিত করা হবে।</li>
          </ul>
        </div>
      </div>

      {/* Scoring System Reference */}
      <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
        <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
          Official Battle Royale Point System
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-[#111D35] text-center border border-amber-500/30">
            <span className="text-[10px] text-amber-400 uppercase font-bold block">1st Place (Booyah)</span>
            <span className="text-base font-black font-gaming text-white">12 Points</span>
          </div>
          <div className="p-3 rounded-xl bg-[#111D35] text-center border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">2nd Place</span>
            <span className="text-base font-black font-gaming text-white">9 Points</span>
          </div>
          <div className="p-3 rounded-xl bg-[#111D35] text-center border border-slate-700">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">3rd Place</span>
            <span className="text-base font-black font-gaming text-white">8 Points</span>
          </div>
          <div className="p-3 rounded-xl bg-[#111D35] text-center border border-red-500/30">
            <span className="text-[10px] text-red-400 uppercase font-bold block">Every Kill</span>
            <span className="text-base font-black font-gaming text-white">+1 Point</span>
          </div>
        </div>
      </div>
    </div>
  );
};
