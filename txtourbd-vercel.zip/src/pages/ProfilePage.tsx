import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  User,
  Gamepad2,
  Mail,
  Phone,
  Shield,
  Trophy,
  Flame,
  Wallet,
  Calendar,
  Edit3,
  CheckCircle,
  AlertCircle,
  Award,
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { userProfile, updatePlayerProfile } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [inGameName, setInGameName] = useState(userProfile?.inGameName || '');
  const [freeFireUid, setFreeFireUid] = useState(userProfile?.freeFireUid || '');
  const [phone, setPhone] = useState(userProfile?.phoneNumber || '');
  const [avatarUrl, setAvatarUrl] = useState(userProfile?.avatarUrl || '');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!userProfile) return null;

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      await updatePlayerProfile({
        displayName,
        inGameName,
        freeFireUid,
        phoneNumber: phone,
        avatarUrl,
      });
      setMessage({
        type: 'success',
        text: language === 'bn' ? 'প্রোফাইল সফলভাবে আপডেট করা হয়েছে!' : 'Profile updated successfully!',
      });
      setIsEditing(false);
    } catch (err: unknown) {
      if (err instanceof Error) setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  const badges = [
    {
      title: 'Verified Gamer',
      desc: 'Free Fire UID Linked',
      earned: !!userProfile.freeFireUid,
      color: 'from-blue-600 to-sky-400',
    },
    {
      title: 'Tournament Veteran',
      desc: 'Joined 5+ Tournaments',
      earned: (userProfile.totalTournaments || 0) >= 5,
      color: 'from-purple-600 to-indigo-400',
    },
    {
      title: 'Top Gunner',
      desc: '20+ Lifetime Kills',
      earned: (userProfile.totalKills || 0) >= 20,
      color: 'from-red-600 to-rose-400',
    },
    {
      title: 'Cash Winner',
      desc: 'Earned ৳500+ in Prizes',
      earned: (userProfile.totalEarnings || 0) >= 500,
      color: 'from-amber-500 to-yellow-300',
    },
  ];

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
          <User className="w-4 h-4" />
          <span>{language === 'bn' ? 'প্লেয়ার প্রোফাইল' : 'Player Card & Dossier'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-gaming text-white mt-1">
          {t('nav.profile')}
        </h1>
      </div>

      {message && (
        <div
          className={`p-3.5 rounded-xl border flex items-start gap-2 text-xs ${
            message.type === 'success'
              ? 'bg-green-950/60 border-green-500/40 text-green-200'
              : 'bg-red-950/60 border-red-500/40 text-red-200'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Main Profile Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0D1428] border border-sky-500/25 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-600 to-sky-400 p-0.5 shadow-xl shrink-0 overflow-hidden">
              {userProfile.avatarUrl ? (
                <img src={userProfile.avatarUrl} alt="" className="w-full h-full object-cover rounded-2xl" />
              ) : (
                <div className="w-full h-full bg-[#070B18] rounded-2xl flex items-center justify-center font-black font-gaming text-2xl text-sky-400 uppercase">
                  {userProfile.displayName?.substring(0, 2) || 'TX'}
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black font-gaming tracking-wide text-white">
                  {userProfile.inGameName || userProfile.displayName}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold font-gaming bg-blue-600 text-white">
                  {userProfile.role}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                @{userProfile.username} • Joined {new Date(userProfile.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="px-4 py-2 rounded-xl bg-[#111D35] hover:bg-slate-800 border border-slate-700 text-sky-400 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{isEditing ? t('common.cancel') : language === 'bn' ? 'প্রোফাইল এডিট' : 'Edit Profile'}</span>
          </button>
        </div>

        {/* Edit Form */}
        {isEditing ? (
          <form onSubmit={handleUpdate} className="py-6 space-y-4 max-w-lg">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'bn' ? 'পুরো নাম' : 'Display Name'}
              </label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-sky-400 mb-1">
                  In-Game Name (IGN) *
                </label>
                <input
                  type="text"
                  required
                  value={inGameName}
                  onChange={(e) => setInGameName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-sky-400 mb-1">
                  Free Fire UID *
                </label>
                <input
                  type="text"
                  required
                  value={freeFireUid}
                  onChange={(e) => setFreeFireUid(e.target.value)}
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-400 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {language === 'bn' ? 'ফোন নম্বর' : 'Phone'}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Avatar Image URL
                </label>
                <input
                  type="url"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming tracking-wider text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
            >
              {loading ? t('common.loading') : t('common.save')}
            </button>
          </form>
        ) : (
          /* Profile Details View */
          <div className="py-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-800 flex items-center gap-3">
              <Gamepad2 className="w-4 h-4 text-sky-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">Free Fire UID</span>
                <span className="font-bold text-white font-mono">
                  {userProfile.freeFireUid || 'Not linked'}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-800 flex items-center gap-3">
              <Shield className="w-4 h-4 text-sky-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">In-Game Name</span>
                <span className="font-bold text-white">
                  {userProfile.inGameName || userProfile.displayName}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-800 flex items-center gap-3">
              <Mail className="w-4 h-4 text-sky-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">Email Address</span>
                <span className="font-bold text-white truncate max-w-[200px] block">
                  {userProfile.email}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111D35] border border-slate-800 flex items-center gap-3">
              <Phone className="w-4 h-4 text-sky-400" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">Phone Number</span>
                <span className="font-bold text-white">{userProfile.phoneNumber || 'N/A'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Lifetime Esports Stats */}
        <div className="pt-6 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3 rounded-xl bg-[#070B18]">
            <span className="text-[10px] text-slate-400 uppercase block">Total Tournaments</span>
            <span className="text-lg font-black font-gaming text-white">
              {userProfile.totalTournaments || 0}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#070B18]">
            <span className="text-[10px] text-slate-400 uppercase block">Total Wins</span>
            <span className="text-lg font-black font-gaming text-amber-400">
              {userProfile.totalWins || 0}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#070B18]">
            <span className="text-[10px] text-slate-400 uppercase block">Total Kills</span>
            <span className="text-lg font-black font-gaming text-red-400">
              {userProfile.totalKills || 0}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#070B18]">
            <span className="text-[10px] text-slate-400 uppercase block">Total Earnings</span>
            <span className="text-lg font-black font-gaming text-emerald-400">
              {formatBDT(userProfile.totalEarnings || 0)}
            </span>
          </div>
        </div>
      </div>

      {/* Achievement Badges */}
      <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
        <h3 className="text-xs font-bold font-gaming uppercase tracking-wider text-sky-400 flex items-center gap-2">
          <Award className="w-4 h-4" />
          {language === 'bn' ? 'অর্জিত ব্যাজ ও মেডেল' : 'Career Achievement Badges'}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {badges.map((b, i) => (
            <div
              key={i}
              className={`p-3.5 rounded-xl border transition-all ${
                b.earned
                  ? 'bg-[#111D35] border-sky-500/40 text-white'
                  : 'bg-[#090E1F]/50 border-slate-800 text-slate-500 opacity-60'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg bg-gradient-to-br ${
                  b.earned ? b.color : 'from-slate-700 to-slate-800'
                } text-white flex items-center justify-center font-bold text-xs mb-2 shadow`}
              >
                ★
              </div>
              <h4 className="font-bold text-xs">{b.title}</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
