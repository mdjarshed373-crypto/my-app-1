import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  TournamentRegistration,
  Tournament,
  RoomCredential,
  MatchResult,
} from '../types';
import {
  fetchUserRegistrations,
  fetchTournamentById,
  fetchRoomCredentials,
} from '../services/tournamentService';
import { fetchMatchResult } from '../services/matchResultService';
import {
  Swords,
  KeyRound,
  Copy,
  Check,
  Calendar,
  Clock,
  Trophy,
  Users,
  Target,
  Award,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';

interface MyMatchesProps {
  onNavigate: (page: string, params?: any) => void;
}

export const MyMatches: React.FC<MyMatchesProps> = ({ onNavigate }) => {
  const { currentUser, userProfile } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [registrations, setRegistrations] = useState<TournamentRegistration[]>([]);
  const [tournamentsMap, setTournamentsMap] = useState<Record<string, Tournament>>({});
  const [roomsMap, setRoomsMap] = useState<Record<string, RoomCredential>>({});
  const [resultsMap, setResultsMap] = useState<Record<string, MatchResult>>({});
  const [activeTab, setActiveTab] = useState<'UPCOMING' | 'ONGOING' | 'COMPLETED'>('UPCOMING');
  const [loading, setLoading] = useState(true);

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedPass, setCopiedPass] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser) {
      loadMyMatches();
    }
  }, [currentUser]);

  const loadMyMatches = async () => {
    if (!currentUser) return;
    try {
      const regs = await fetchUserRegistrations(currentUser.uid);
      setRegistrations(regs);

      // Load tournament, room, and results data for each registration
      const tMap: Record<string, Tournament> = {};
      const rMap: Record<string, RoomCredential> = {};
      const resMap: Record<string, MatchResult> = {};

      for (const reg of regs) {
        const [tour, room, res] = await Promise.all([
          fetchTournamentById(reg.tournamentId),
          fetchRoomCredentials(reg.tournamentId),
          fetchMatchResult(reg.tournamentId),
        ]);
        if (tour) tMap[reg.tournamentId] = tour;
        if (room) rMap[reg.tournamentId] = room;
        if (res) resMap[reg.tournamentId] = res;
      }

      setTournamentsMap(tMap);
      setRoomsMap(rMap);
      setResultsMap(resMap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, id: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      setCopiedPass(id);
      setTimeout(() => setCopiedPass(null), 2000);
    }
  };

  // Filter registrations by tournament status
  const filteredRegs = registrations.filter((reg) => {
    const tour = tournamentsMap[reg.tournamentId];
    if (!tour) return true;
    if (activeTab === 'COMPLETED') return tour.status === 'COMPLETED';
    if (activeTab === 'ONGOING') return tour.status === 'ONGOING';
    return tour.status !== 'COMPLETED' && tour.status !== 'ONGOING';
  });

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
          <Swords className="w-4 h-4" />
          <span>{language === 'bn' ? 'আমার ম্যাচ ও কাস্টম রুম' : 'Player Match Headquarters'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-gaming text-white mt-1">
          {t('nav.myMatches')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          {language === 'bn'
            ? 'আপনার সকল নিবন্ধিত টুর্নামেন্ট, ম্যাচ শিডিউল, রুম আইডি এবং স্কোরকার্ড দেখুন।'
            : 'View all your registered matches, match schedules, live room IDs, and post-game scorecards.'}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 gap-4 text-xs font-gaming tracking-wider">
        <button
          onClick={() => setActiveTab('UPCOMING')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'UPCOMING'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {language === 'bn' ? 'আসন্ন টুর্নামেন্ট (Upcoming)' : 'Upcoming Matches'}
        </button>
        <button
          onClick={() => setActiveTab('ONGOING')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'ONGOING'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {language === 'bn' ? 'চলমান (Ongoing)' : 'Ongoing'}
        </button>
        <button
          onClick={() => setActiveTab('COMPLETED')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'COMPLETED'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {language === 'bn' ? 'সমাপ্ত ও ফলাফল (Completed)' : 'Completed & Results'}
        </button>
      </div>

      {/* Matches List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 rounded-2xl bg-[#0D1428] animate-pulse border border-slate-800"></div>
          ))}
        </div>
      ) : filteredRegs.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-[#0D1428] border border-slate-800 space-y-3">
          <Swords className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white font-gaming">
            {language === 'bn' ? 'এই ক্যাটাগরিতে কোনো ম্যাচ নেই' : 'No matches in this category'}
          </h3>
          <p className="text-xs text-slate-400">
            {language === 'bn'
              ? 'নতুন টুর্নামেন্টে যোগ দিন এবং আপনার পছন্দের স্লট বুক করুন।'
              : 'Join a new tournament and book your match slot now.'}
          </p>
          <button
            onClick={() => onNavigate('tournaments')}
            className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs font-gaming tracking-wider cursor-pointer"
          >
            {t('hero.browseBtn')}
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredRegs.map((reg) => {
            const tour = tournamentsMap[reg.tournamentId];
            const room = roomsMap[reg.tournamentId];
            const result = resultsMap[reg.tournamentId];

            // Find player result if completed
            const myStanding = result?.standings?.find(
              (s) =>
                s.playerUids?.includes(currentUser?.uid || '') ||
                s.teamName === reg.teamName
            );

            return (
              <div
                key={reg.id}
                className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4"
              >
                {/* Match Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-gaming bg-blue-600 text-white">
                        {reg.type}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-gaming bg-sky-950 text-sky-400 border border-sky-500/30">
                        Slot #{reg.slotNumber}
                      </span>
                    </div>
                    <h3 className="text-lg font-black font-gaming text-white">
                      {tour ? (language === 'bn' && tour.titleBn ? tour.titleBn : tour.title) : 'Tournament Match'}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-sky-400" />
                      {tour?.matchDate}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-sky-400" />
                      {tour?.matchTime}
                    </span>
                  </div>
                </div>

                {/* Team Roster In Match */}
                <div>
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                    {reg.type === 'SOLO' ? 'Registered Player' : `Squad: ${reg.teamName}`}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {reg.players.map((p, pIdx) => (
                      <span
                        key={pIdx}
                        className="px-2.5 py-1 rounded-lg bg-[#111D35] text-xs text-slate-300 border border-slate-700 flex items-center gap-1.5"
                      >
                        <span className="font-bold text-white">{p.inGameName || p.name}</span>
                        <span className="text-[10px] text-sky-400 font-mono">({p.freeFireUid})</span>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Room ID and Password Box */}
                <div className="p-4 rounded-xl bg-[#111D35] border border-sky-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold font-gaming uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                      <KeyRound className="w-4 h-4" />
                      {t('room.title')}
                    </span>
                    <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Verified Player Access
                    </span>
                  </div>

                  {room && room.isPublished && room.roomId ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                      <div className="p-3 rounded-lg bg-[#070B18] border border-slate-700 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                            {t('room.id')}
                          </span>
                          <span className="text-base font-black font-gaming tracking-widest text-sky-300">
                            {room.roomId}
                          </span>
                        </div>
                        <button
                          onClick={() => handleCopy(room.roomId, reg.id, 'id')}
                          className="px-2.5 py-1 text-xs rounded bg-sky-600/30 text-sky-400 hover:bg-sky-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          {copiedId === reg.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedId === reg.id ? t('room.copied') : t('room.copy')}
                        </button>
                      </div>

                      <div className="p-3 rounded-lg bg-[#070B18] border border-slate-700 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                            {t('room.password')}
                          </span>
                          <span className="text-base font-black font-gaming tracking-widest text-sky-300">
                            {room.roomPassword}
                          </span>
                        </div>
                        <button
                          onClick={() => handleCopy(room.roomPassword, reg.id, 'pass')}
                          className="px-2.5 py-1 text-xs rounded bg-sky-600/30 text-sky-400 hover:bg-sky-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          {copiedPass === reg.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedPass === reg.id ? t('room.copied') : t('room.copy')}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 rounded-lg bg-[#070B18] text-xs text-slate-400 text-center">
                      <Clock className="w-4 h-4 text-sky-400 inline mr-1" />
                      {t('room.waiting')}
                    </div>
                  )}
                </div>

                {/* Match Result / Scorecard if completed */}
                {myStanding && (
                  <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                    <span className="text-xs font-bold font-gaming uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                      <Trophy className="w-4 h-4 text-amber-400" />
                      Official Match Scorecard
                    </span>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
                      <div className="p-2 rounded-lg bg-[#070B18]">
                        <span className="text-[10px] text-slate-400 uppercase block">Placement</span>
                        <span className="text-sm font-black font-gaming text-white">
                          #{myStanding.placement}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#070B18]">
                        <span className="text-[10px] text-slate-400 uppercase block">Kills</span>
                        <span className="text-sm font-black font-gaming text-red-400">
                          {myStanding.kills} Kills
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#070B18]">
                        <span className="text-[10px] text-slate-400 uppercase block">Total Points</span>
                        <span className="text-sm font-black font-gaming text-sky-400">
                          {myStanding.totalPoints} Pts
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#070B18]">
                        <span className="text-[10px] text-slate-400 uppercase block">Prize Won</span>
                        <span className="text-sm font-black font-gaming text-emerald-400">
                          {formatBDT(myStanding.prizeWon || 0)}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
