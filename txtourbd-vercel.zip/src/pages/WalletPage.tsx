import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  WalletTransaction,
  DepositRequest,
  WithdrawalRequest,
  PaymentMethod,
  AppSettings,
} from '../types';
import {
  submitDepositRequest,
  submitWithdrawalRequest,
  fetchUserTransactions,
  fetchDepositRequests,
  fetchWithdrawalRequests,
} from '../services/walletService';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  Check,
  ShieldCheck,
  History,
  Info,
} from 'lucide-react';

interface WalletPageProps {
  initialTab?: 'overview' | 'deposit' | 'withdraw';
}

export const WalletPage: React.FC<WalletPageProps> = ({ initialTab = 'overview' }) => {
  const { currentUser, userProfile, refreshProfile } = useAuth();
  const { language, t, formatBDT } = useLanguage();

  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw'>(initialTab);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Deposit Form State
  const [depMethod, setDepMethod] = useState<PaymentMethod>('bKash');
  const [depAmount, setDepAmount] = useState<string>('100');
  const [depSender, setDepSender] = useState('');
  const [depTrxId, setDepTrxId] = useState('');
  const [depScreenshot, setDepScreenshot] = useState('');
  const [depLoading, setDepLoading] = useState(false);
  const [depMessage, setDepMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Withdrawal Form State
  const [withMethod, setWithMethod] = useState<PaymentMethod>('bKash');
  const [withAmount, setWithAmount] = useState<string>('100');
  const [withAccount, setWithAccount] = useState('');
  const [withLoading, setWithLoading] = useState(false);
  const [withMessage, setWithMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [copiedNumber, setCopiedNumber] = useState(false);

  useEffect(() => {
    if (currentUser) {
      loadWalletData();
    }
  }, [currentUser]);

  const loadWalletData = async () => {
    if (!currentUser) return;
    try {
      const [txs, deps, withs, settDoc] = await Promise.all([
        fetchUserTransactions(currentUser.uid),
        fetchDepositRequests(currentUser.uid),
        fetchWithdrawalRequests(currentUser.uid),
        getDoc(doc(db, 'settings', 'global')),
      ]);
      setTransactions(txs);
      setDepositRequests(deps);
      setWithdrawalRequests(withs);
      if (settDoc.exists()) {
        setSettings(settDoc.data() as AppSettings);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getAdminNumberForMethod = (method: PaymentMethod) => {
    if (method === 'bKash') return settings?.bkashNumber || '01602570739';
    if (method === 'Nagad') return settings?.nagadNumber || '01602570739';
    return settings?.rocketNumber || '01602570739';
  };

  const getAdminAccountType = (method: PaymentMethod) => {
    if (method === 'bKash') return settings?.bkashType || 'Personal (Send Money)';
    if (method === 'Nagad') return settings?.nagadType || 'Personal (Send Money)';
    return settings?.rocketType || 'Personal (Send Money)';
  };

  const handleCopyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !userProfile) return;

    const amount = Number(depAmount);
    if (!amount || amount < 10) {
      setDepMessage({
        type: 'error',
        text: 'মিনিমাম ১০ টাকা',
      });
      return;
    }
    if (amount > 20000) {
      setDepMessage({
        type: 'error',
        text: language === 'bn' ? 'সর্বোচ্চ ডিপোজিট ২০,০০০ টাকা।' : 'Maximum deposit is ৳20,000.',
      });
      return;
    }
    if (!depTrxId.trim() || !depSender.trim()) {
      setDepMessage({
        type: 'error',
        text: language === 'bn' ? 'প্রেরক নম্বর এবং TrxID প্রদান করুন।' : 'Please enter sender number and TrxID.',
      });
      return;
    }

    setDepLoading(true);
    setDepMessage(null);

    const res = await submitDepositRequest(
      currentUser.uid,
      userProfile.displayName,
      currentUser.email || '',
      depMethod,
      amount,
      depSender,
      depTrxId,
      depScreenshot
    );

    setDepLoading(false);
    if (res.success) {
      setDepMessage({ type: 'success', text: res.message });
      setDepTrxId('');
      setDepSender('');
      setDepScreenshot('');
      await refreshProfile();
      loadWalletData();
    } else {
      setDepMessage({ type: 'error', text: res.message });
    }
  };

  const handleWithdrawalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !userProfile) return;

    const amount = Number(withAmount);
    if (!amount || amount < 50) {
      setWithMessage({
        type: 'error',
        text: language === 'bn' ? 'সর্বনিম্ন উইথড্র ৫০ টাকা।' : 'Minimum withdrawal is ৳50.',
      });
      return;
    }
    if (amount > (userProfile.walletBalance || 0)) {
      setWithMessage({
        type: 'error',
        text: language === 'bn' ? 'ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।' : 'Insufficient balance.',
      });
      return;
    }
    if (!withAccount.trim()) {
      setWithMessage({
        type: 'error',
        text: language === 'bn' ? 'একাউন্ট নম্বর প্রদান করুন।' : 'Please enter account number.',
      });
      return;
    }

    setWithLoading(true);
    setWithMessage(null);

    const res = await submitWithdrawalRequest(
      currentUser.uid,
      userProfile.displayName,
      currentUser.email || '',
      withMethod,
      withAccount,
      amount
    );

    setWithLoading(false);
    if (res.success) {
      setWithMessage({ type: 'success', text: res.message });
      setWithAccount('');
      await refreshProfile();
      loadWalletData();
    } else {
      setWithMessage({ type: 'error', text: res.message });
    }
  };

  if (!userProfile) return null;

  return (
    <div className="min-h-screen bg-[#070B18] py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sky-400 text-xs font-bold font-gaming uppercase tracking-widest">
          <Wallet className="w-4 h-4" />
          <span>{language === 'bn' ? 'ওয়ালেট ও পেমেন্ট সেন্টার' : 'Player Esports Wallet'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-gaming text-white mt-1">
          {t('wallet.title')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          {language === 'bn'
            ? 'বিকাশ, নগদ বা রকেটের মাধ্যমে টাকা জমা ও উত্তোলন করুন। ১০০% নিরাপদ ও বিশ্বস্ত।'
            : 'Add and withdraw tournament funds via bKash, Nagad, and Rocket.'}
        </p>
      </div>

      {/* Balance Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950/80 to-[#0D1428] border border-sky-500/40 shadow-lg">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
            {t('wallet.available')}
          </span>
          <span className="text-xl sm:text-2xl font-black font-gaming text-sky-300">
            {formatBDT(userProfile.walletBalance || 0)}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0D1428] border border-amber-500/30 shadow-lg">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
            {t('wallet.pending')}
          </span>
          <span className="text-xl sm:text-2xl font-black font-gaming text-amber-400">
            {formatBDT(userProfile.pendingBalance || 0)}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0D1428] border border-emerald-500/30 shadow-lg">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
            {t('wallet.winnings')}
          </span>
          <span className="text-xl sm:text-2xl font-black font-gaming text-emerald-400">
            {formatBDT(userProfile.totalEarnings || 0)}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0D1428] border border-purple-500/30 shadow-lg">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
            {t('wallet.withdrawn')}
          </span>
          <span className="text-xl sm:text-2xl font-black font-gaming text-purple-400">
            {formatBDT(userProfile.totalWithdrawn || 0)}
          </span>
        </div>
      </div>

      {/* Wallet Navigation Tabs */}
      <div className="flex border-b border-slate-800 gap-4 text-xs font-gaming tracking-wider">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'overview'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {t('wallet.transactions')}
        </button>
        <button
          onClick={() => setActiveTab('deposit')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'deposit'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {t('wallet.deposit')} (Add Money)
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`py-3 font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'withdraw'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {t('wallet.withdraw')} (Cash Out)
        </button>
      </div>

      {/* TAB 1: TRANSACTIONS & PENDING REQUESTS OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Pending Requests Notice */}
          {depositRequests.some((d) => d.status === 'PENDING') && (
            <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-3">
              <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">
                  {language === 'bn' ? 'পেন্ডিং ডিপোজিট রিকোয়েস্ট রয়েছে' : 'Pending Deposit Verification'}
                </span>
                <p className="text-[11px] text-amber-300/80 mt-0.5">
                  {language === 'bn'
                    ? 'আপনার ডিপোজিট আবেদনটি এডমিন ভেরিফাই করছেন। অল্প সময়ের মধ্যে ব্যালেন্স যোগ হবে।'
                    : 'Admin is currently reviewing your deposit. It will reflect in your balance shortly.'}
                </p>
              </div>
            </div>
          )}

          {/* Transactions Ledger */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 flex items-center gap-2">
              <History className="w-4 h-4" />
              {t('wallet.transactions')}
            </h3>

            {transactions.length === 0 ? (
              <p className="text-center py-10 text-xs text-slate-400">
                {language === 'bn' ? 'এখনও কোনো লেনদেনের রেকর্ড নেই।' : 'No transaction records found.'}
              </p>
            ) : (
              <div className="space-y-2.5">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3.5 rounded-xl bg-[#111D35] border border-slate-800 flex items-center justify-between text-xs hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                          tx.type === 'DEPOSIT' || tx.type === 'PRIZE' || tx.type === 'REFUND'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-950 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {tx.type === 'DEPOSIT' || tx.type === 'PRIZE' || tx.type === 'REFUND' ? (
                          <ArrowDownLeft className="w-4 h-4" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <span className="font-bold text-white block">
                          {language === 'bn' ? tx.descriptionBn || tx.description : tx.description}
                        </span>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                          <span>{new Date(tx.createdAt).toLocaleString()}</span>
                          <span>•</span>
                          <span
                            className={`px-1.5 py-0.2 rounded font-semibold ${
                              tx.status === 'COMPLETED'
                                ? 'text-emerald-400 bg-emerald-950/40'
                                : tx.status === 'PENDING'
                                ? 'text-amber-400 bg-amber-950/40'
                                : 'text-red-400 bg-red-950/40'
                            }`}
                          >
                            {tx.status}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span
                        className={`text-sm font-black font-gaming block ${
                          tx.type === 'DEPOSIT' || tx.type === 'PRIZE' || tx.type === 'REFUND'
                            ? 'text-emerald-400'
                            : 'text-red-400'
                        }`}
                      >
                        {tx.type === 'DEPOSIT' || tx.type === 'PRIZE' || tx.type === 'REFUND'
                          ? '+'
                          : '-'}
                        {formatBDT(tx.amount)}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Balance: {formatBDT(tx.balanceAfter)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: DEPOSIT FUNDS */}
      {activeTab === 'deposit' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Instructions Box */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400 flex items-center gap-2">
              <Info className="w-4 h-4" />
              {language === 'bn' ? 'টাকা পাঠানোর নিয়মাবলী' : 'Payment Instructions'}
            </h3>

            {/* Method Select Buttons */}
            <div className="grid grid-cols-3 gap-2">
              {(['bKash', 'Nagad', 'Rocket'] as PaymentMethod[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setDepMethod(m)}
                  className={`py-2 rounded-xl text-xs font-bold font-gaming transition-all cursor-pointer ${
                    depMethod === m
                      ? m === 'bKash'
                        ? 'bg-pink-600 text-white shadow-md'
                        : m === 'Nagad'
                        ? 'bg-orange-600 text-white shadow-md'
                        : 'bg-purple-600 text-white shadow-md'
                      : 'bg-[#111D35] text-slate-400 hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            {/* Official Number Box */}
            <div className="p-4 rounded-xl bg-[#111D35] border border-sky-500/30 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">
                  {depMethod} Official Number ({getAdminAccountType(depMethod)})
                </span>
                <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-400 text-[10px] font-bold">
                  Send Money
                </span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070B18] border border-slate-700">
                <span className="text-base font-black font-gaming tracking-wider text-sky-300">
                  {getAdminNumberForMethod(depMethod)}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyNumber(getAdminNumberForMethod(depMethod))}
                  className="px-2.5 py-1 text-xs rounded bg-sky-600/30 text-sky-400 hover:bg-sky-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                >
                  {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedNumber ? t('room.copied') : t('room.copy')}
                </button>
              </div>
            </div>

            <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed bg-[#111D35]/50 p-4 rounded-xl border border-slate-800">
              <li>আপনার {depMethod} একাউন্ট থেকে উপরের নাম্বারে 'Send Money' করুন।</li>
              <li>টাকা পাঠানোর পর ট্রানজেকশন আইডি (TrxID) কপি করুন।</li>
              <li>পাশে থাকা ফর্মে টাকার পরিমাণ, আপনার মোবাইল নম্বর ও TrxID লিখে সাবমিট করুন।</li>
              <li>এডমিন ভেরিফাই করে ৫ থেকে ১৫ মিনিটের মধ্যে ওয়ালেট ব্যালেন্স যোগ করবেন।</li>
            </ol>
          </div>

          {/* Deposit Form */}
          <div className="p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
            <h3 className="text-sm font-bold font-gaming uppercase tracking-wider text-sky-400">
              {t('wallet.submitDeposit')}
            </h3>

            {depMessage && (
              <div
                className={`p-3 rounded-xl border flex items-start gap-2 text-xs ${
                  depMessage.type === 'success'
                    ? 'bg-green-950/60 border-green-500/40 text-green-200'
                    : 'bg-red-950/60 border-red-500/40 text-red-200'
                }`}
              >
                {depMessage.type === 'success' ? (
                  <CheckCircle className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <span>{depMessage.text}</span>
              </div>
            )}

            <form onSubmit={handleDepositSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.amount')} *
                </label>
                <div className="grid grid-cols-5 gap-1.5 mb-2">
                  {['10', '50', '100', '200', '500'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setDepAmount(preset);
                        if (depMessage?.text === 'মিনিমাম ১০ টাকা') {
                          setDepMessage(null);
                        }
                      }}
                      className={`py-1.5 rounded-lg text-xs font-bold font-gaming transition-all cursor-pointer ${
                        depAmount === preset
                          ? 'bg-sky-500 text-white shadow-md shadow-sky-500/30'
                          : 'bg-[#111D35] text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      ৳{preset}
                    </button>
                  ))}
                </div>
                <div className="relative">
                  <input
                    type="number"
                    min="10"
                    max="20000"
                    step="1"
                    required
                    value={depAmount}
                    onChange={(e) => {
                      setDepAmount(e.target.value);
                      const val = Number(e.target.value);
                      if (e.target.value !== '' && val < 10) {
                        setDepMessage({ type: 'error', text: 'মিনিমাম ১০ টাকা' });
                      } else {
                        if (depMessage?.text === 'মিনিমাম ১০ টাকা') {
                          setDepMessage(null);
                        }
                      }
                    }}
                    placeholder="যেমন: 10, 15, 27, 500, 1000, 5000"
                    className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-[10px] text-slate-400">
                    মিনিমাম ১০ টাকা (সর্বোচ্চ ২০,০০০ টাকা)
                  </span>
                  {depAmount !== '' && Number(depAmount) < 10 && (
                    <span className="text-[11px] text-red-400 font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      মিনিমাম ১০ টাকা
                    </span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.senderNumber')} *
                </label>
                <input
                  type="tel"
                  required
                  value={depSender}
                  onChange={(e) => setDepSender(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.trxId')} *
                </label>
                <input
                  type="text"
                  required
                  value={depTrxId}
                  onChange={(e) => setDepTrxId(e.target.value)}
                  placeholder="e.g. 9J4K8L2M1P"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400 uppercase tracking-widest font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.screenshot')}
                </label>
                <input
                  type="url"
                  value={depScreenshot}
                  onChange={(e) => setDepScreenshot(e.target.value)}
                  placeholder="https://imgur.com/... (optional)"
                  className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <button
                type="submit"
                disabled={depLoading || !Number(depAmount) || Number(depAmount) < 10}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 text-white font-bold font-gaming tracking-wider text-xs rounded-xl shadow-lg shadow-sky-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {depLoading
                  ? t('common.loading')
                  : Number(depAmount) < 10 && depAmount !== ''
                  ? 'মিনিমাম ১০ টাকা প্রয়োজন'
                  : t('wallet.submitDeposit')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: WITHDRAWAL REQUEST */}
      {activeTab === 'withdraw' && (
        <div className="max-w-xl mx-auto p-6 rounded-2xl bg-[#0D1428] border border-sky-500/20 shadow-xl space-y-4">
          <div>
            <h3 className="text-base font-bold font-gaming uppercase tracking-wider text-sky-400">
              {t('wallet.submitWithdraw')}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              টুর্নামেন্ট জয়ের টাকা বিকাশ, নগদ বা রকেট একাউন্টে তুলে নিন।
            </p>
          </div>

          {withMessage && (
            <div
              className={`p-3 rounded-xl border flex items-start gap-2 text-xs ${
                withMessage.type === 'success'
                  ? 'bg-green-950/60 border-green-500/40 text-green-200'
                  : 'bg-red-950/60 border-red-500/40 text-red-200'
              }`}
            >
              {withMessage.type === 'success' ? (
                <CheckCircle className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              )}
              <span>{withMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleWithdrawalSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t('wallet.selectMethod')}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['bKash', 'Nagad', 'Rocket'] as PaymentMethod[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setWithMethod(m)}
                    className={`py-2 rounded-xl text-xs font-bold font-gaming transition-all cursor-pointer ${
                      withMethod === m
                        ? m === 'bKash'
                          ? 'bg-pink-600 text-white shadow-md'
                          : m === 'Nagad'
                          ? 'bg-orange-600 text-white shadow-md'
                          : 'bg-purple-600 text-white shadow-md'
                        : 'bg-[#111D35] text-slate-400 hover:text-white'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t('wallet.amount')} (Available: {formatBDT(userProfile.walletBalance || 0)}) *
              </label>
              <input
                type="number"
                min="50"
                max={userProfile.walletBalance || 0}
                required
                value={withAmount}
                onChange={(e) => setWithAmount(e.target.value)}
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {withMethod} {t('wallet.accountNumber')} (Personal) *
              </label>
              <input
                type="tel"
                required
                value={withAccount}
                onChange={(e) => setWithAccount(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="w-full px-3 py-2 bg-[#111D35] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-400"
              />
            </div>

            <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/20 text-xs text-slate-300 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <span>
                উইথড্র রিকোয়েস্ট সাবমিট করার পর ব্যালেন্স থেকে সমপরিমাণ অর্থ লক হয়ে যাবে এবং ১ থেকে ১২ ঘণ্টার মধ্যে অনুমোদিত একাউন্টে টাকা পাঠানো হবে।
              </span>
            </div>

            <button
              type="submit"
              disabled={withLoading || (userProfile.walletBalance || 0) < 50}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold font-gaming tracking-wider text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {withLoading ? t('common.loading') : t('wallet.submitWithdraw')}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
