import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  runTransaction,
} from 'firebase/firestore';
import { db } from './firebase';
import {
  DepositRequest,
  WithdrawalRequest,
  WalletTransaction,
  PaymentMethod,
  AppNotification,
} from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export async function submitDepositRequest(
  userId: string,
  userName: string,
  userEmail: string,
  method: PaymentMethod,
  amount: number,
  senderNumber: string,
  transactionId: string,
  screenshotUrl?: string
): Promise<{ success: boolean; message: string }> {
  if (amount < 10) {
    return { success: false, message: 'মিনিমাম ১০ টাকা' };
  }
  if (amount > 20000) {
    return { success: false, message: 'সর্বোচ্চ ডিপোজিট ২০,০০০ টাকা।' };
  }
  try {
    const cleanTrx = transactionId.trim().toUpperCase();
    const requestId = 'dep_' + Math.random().toString(36).substring(2, 9);
    const reqDocRef = doc(db, 'depositRequests', requestId);
    const userDocRef = doc(db, 'users', userId);

    await runTransaction(db, async (txn) => {
      const userSnap = await txn.get(userDocRef);
      if (!userSnap.exists()) {
        throw new Error('ব্যবহারকারী পাওয়া যায়নি!');
      }

      const userData = userSnap.data();
      const currentPending = Number(userData.pendingBalance || 0);

      // Create deposit request
      const depositData: DepositRequest = {
        id: requestId,
        userId,
        userName,
        userEmail,
        method,
        amount,
        senderNumber: senderNumber.trim(),
        transactionId: cleanTrx,
        screenshotUrl: screenshotUrl || '',
        status: 'PENDING',
        createdAt: new Date().toISOString(),
      };
      txn.set(reqDocRef, depositData);

      // Update user pending balance
      txn.update(userDocRef, {
        pendingBalance: currentPending + amount,
        updatedAt: new Date().toISOString(),
      });
    });

    return {
      success: true,
      message: 'ডিপোজিট রিকোয়েস্ট সফলভাবে সাবমিট হয়েছে! এডমিন যাচাই করে ৫-১৫ মিনিটের মধ্যে ব্যালেন্স যোগ করবেন।',
    };
  } catch (err: unknown) {
    if (err instanceof Error) {
      return { success: false, message: err.message };
    }
    return { success: false, message: 'ডিপোজিট সাবমিট করতে সমস্যা হয়েছে।' };
  }
}

export async function submitWithdrawalRequest(
  userId: string,
  userName: string,
  userEmail: string,
  method: PaymentMethod,
  accountNumber: string,
  amount: number
): Promise<{ success: boolean; message: string }> {
  if (amount < 50) {
    return { success: false, message: 'সর্বনিম্ন উইথড্র পরিমাণ ৫০ টাকা।' };
  }

  const requestId = 'with_' + Math.random().toString(36).substring(2, 9);
  const reqDocRef = doc(db, 'withdrawalRequests', requestId);
  const userDocRef = doc(db, 'users', userId);

  try {
    return await runTransaction(db, async (txn) => {
      const userSnap = await txn.get(userDocRef);
      if (!userSnap.exists()) {
        throw new Error('ব্যবহারকারী পাওয়া যায়নি!');
      }

      const userData = userSnap.data();
      const availableBalance = Number(userData.walletBalance || 0);

      if (availableBalance < amount) {
        throw new Error(`পর্যাপ্ত ব্যালেন্স নেই! আপনার বর্তমান ব্যালেন্স ৳${availableBalance}`);
      }

      const newBalance = availableBalance - amount;

      // Deduct from available balance immediately so user cannot double-spend
      txn.update(userDocRef, {
        walletBalance: newBalance,
        updatedAt: new Date().toISOString(),
      });

      // Create withdrawal request
      const withdrawalData: WithdrawalRequest = {
        id: requestId,
        userId,
        userName,
        userEmail,
        method,
        accountNumber: accountNumber.trim(),
        amount,
        status: 'PENDING',
        createdAt: new Date().toISOString(),
      };
      txn.set(reqDocRef, withdrawalData);

      // Create pending transaction record
      const trxId = 'trx_w_' + requestId;
      const trxDocRef = doc(db, 'transactions', trxId);
      const trxData: WalletTransaction = {
        id: trxId,
        userId,
        type: 'WITHDRAWAL',
        amount,
        status: 'PENDING',
        referenceId: requestId,
        description: `Withdrawal request to ${method} (${accountNumber})`,
        descriptionBn: `${method}-এ ৳${amount} টাকা উত্তোলনের আবেদন (${accountNumber})`,
        balanceAfter: newBalance,
        createdAt: new Date().toISOString(),
      };
      txn.set(trxDocRef, trxData);

      return {
        success: true,
        message: 'উইথড্র রিকোয়েস্ট সফলভাবে সাবমিট হয়েছে! অল্প সময়ের মধ্যে আপনার নাম্বারে টাকা পাঠিয়ে দেওয়া হবে।',
      };
    });
  } catch (err: unknown) {
    if (err instanceof Error) {
      return { success: false, message: err.message };
    }
    return { success: false, message: 'উইথড্র করতে সমস্যা হয়েছে।' };
  }
}

export async function adminApproveDeposit(
  requestId: string,
  adminNote?: string
): Promise<{ success: boolean; message: string }> {
  const reqDocRef = doc(db, 'depositRequests', requestId);

  try {
    return await runTransaction(db, async (txn) => {
      const reqSnap = await txn.get(reqDocRef);
      if (!reqSnap.exists()) {
        throw new Error('ডিপোজিট রিকোয়েস্ট পাওয়া যায়নি!');
      }
      const req = reqSnap.data() as DepositRequest;
      if (req.status !== 'PENDING') {
        throw new Error(`এই রিকোয়েস্টটি ইতিমধ্যে ${req.status} হয়েছে!`);
      }

      const userDocRef = doc(db, 'users', req.userId);
      const userSnap = await txn.get(userDocRef);
      if (!userSnap.exists()) {
        throw new Error('খেলোয়াড় একাউন্ট পাওয়া যায়নি!');
      }

      const userData = userSnap.data();
      const currentBalance = Number(userData.walletBalance || 0);
      const currentPending = Math.max(0, Number(userData.pendingBalance || 0) - req.amount);
      const newBalance = currentBalance + req.amount;
      const totalDeposited = Number(userData.totalDeposited || 0) + req.amount;

      // Update user
      txn.update(userDocRef, {
        walletBalance: newBalance,
        pendingBalance: currentPending,
        totalDeposited,
        updatedAt: new Date().toISOString(),
      });

      // Update deposit request
      txn.update(reqDocRef, {
        status: 'APPROVED',
        adminNote: adminNote || 'Approved by Admin',
        processedAt: new Date().toISOString(),
      });

      // Create transaction log
      const trxId = 'trx_d_' + requestId;
      const trxDocRef = doc(db, 'transactions', trxId);
      const trxData: WalletTransaction = {
        id: trxId,
        userId: req.userId,
        type: 'DEPOSIT',
        amount: req.amount,
        status: 'COMPLETED',
        referenceId: req.transactionId,
        description: `Approved deposit via ${req.method} (TrxID: ${req.transactionId})`,
        descriptionBn: `${req.method}-এর মাধ্যমে ৳${req.amount} ডিপোজিট অনুমোদিত (TrxID: ${req.transactionId})`,
        balanceAfter: newBalance,
        createdAt: new Date().toISOString(),
      };
      txn.set(trxDocRef, trxData);

      // Create notification
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 9);
      const notifRef = doc(db, 'notifications', notifId);
      const notif: AppNotification = {
        id: notifId,
        userId: req.userId,
        title: 'Deposit Approved! 🎉',
        titleBn: 'ডিপোজিট অনুমোদিত হয়েছে! 🎉',
        message: `৳${req.amount} has been added to your wallet balance.`,
        messageBn: `আপনার ওয়ালেটে ৳${req.amount} সফলভাবে যুক্ত হয়েছে।`,
        type: 'SUCCESS',
        read: false,
        createdAt: new Date().toISOString(),
      };
      txn.set(notifRef, notif);

      return { success: true, message: 'ডিপোজিট সফলভাবে অনুমোদন করা হয়েছে এবং ব্যালেন্স যোগ হয়েছে।' };
    });
  } catch (err: unknown) {
    if (err instanceof Error) return { success: false, message: err.message };
    return { success: false, message: 'অনুমোদন করতে ব্যর্থ হয়েছে।' };
  }
}

export async function adminRejectDeposit(
  requestId: string,
  adminNote: string
): Promise<{ success: boolean; message: string }> {
  const reqDocRef = doc(db, 'depositRequests', requestId);

  try {
    return await runTransaction(db, async (txn) => {
      const reqSnap = await txn.get(reqDocRef);
      if (!reqSnap.exists()) throw new Error('রিকোয়েস্ট পাওয়া যায়নি!');
      const req = reqSnap.data() as DepositRequest;
      if (req.status !== 'PENDING') throw new Error('রিকোয়েস্টটি আর পেন্ডিং নেই!');

      const userDocRef = doc(db, 'users', req.userId);
      const userSnap = await txn.get(userDocRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        const currentPending = Math.max(0, Number(userData.pendingBalance || 0) - req.amount);
        txn.update(userDocRef, { pendingBalance: currentPending, updatedAt: new Date().toISOString() });
      }

      txn.update(reqDocRef, {
        status: 'REJECTED',
        adminNote: adminNote || 'Invalid Transaction ID or payment not received',
        processedAt: new Date().toISOString(),
      });

      // Notify player
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 9);
      const notifRef = doc(db, 'notifications', notifId);
      const notif: AppNotification = {
        id: notifId,
        userId: req.userId,
        title: 'Deposit Rejected',
        titleBn: 'ডিপোজিট বাতিল হয়েছে',
        message: `Your deposit request of ৳${req.amount} was rejected: ${adminNote || 'TrxID not matched'}`,
        messageBn: `আপনার ৳${req.amount} ডিপোজিট আবেদন বাতিল করা হয়েছে। কারণ: ${adminNote || 'সঠিক TrxID পাওয়া যায়নি'}`,
        type: 'ALERT',
        read: false,
        createdAt: new Date().toISOString(),
      };
      txn.set(notifRef, notif);

      return { success: true, message: 'ডিপোজিট বাতিল করা হয়েছে।' };
    });
  } catch (err: unknown) {
    if (err instanceof Error) return { success: false, message: err.message };
    return { success: false, message: 'বাতিল করতে সমস্যা হয়েছে।' };
  }
}

export async function adminApproveWithdrawal(
  requestId: string,
  adminNote?: string
): Promise<{ success: boolean; message: string }> {
  const reqDocRef = doc(db, 'withdrawalRequests', requestId);

  try {
    return await runTransaction(db, async (txn) => {
      const reqSnap = await txn.get(reqDocRef);
      if (!reqSnap.exists()) throw new Error('উইথড্র রিকোয়েস্ট পাওয়া যায়নি!');
      const req = reqSnap.data() as WithdrawalRequest;
      if (req.status !== 'PENDING') throw new Error('রিকোয়েস্টটি আর পেন্ডিং নেই!');

      const userDocRef = doc(db, 'users', req.userId);
      const userSnap = await txn.get(userDocRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        txn.update(userDocRef, {
          totalWithdrawn: Number(userData.totalWithdrawn || 0) + req.amount,
          updatedAt: new Date().toISOString(),
        });
      }

      txn.update(reqDocRef, {
        status: 'PAID',
        adminNote: adminNote || 'Paid to phone account',
        processedAt: new Date().toISOString(),
      });

      // Update transaction status
      const trxDocRef = doc(db, 'transactions', 'trx_w_' + requestId);
      txn.update(trxDocRef, { status: 'COMPLETED' });

      // Notify player
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 9);
      const notifRef = doc(db, 'notifications', notifId);
      const notif: AppNotification = {
        id: notifId,
        userId: req.userId,
        title: 'Withdrawal Completed! 💸',
        titleBn: 'উইথড্র সম্পন্ন হয়েছে! 💸',
        message: `৳${req.amount} has been sent to your ${req.method} account (${req.accountNumber}).`,
        messageBn: `আপনার ${req.method} নম্বরে (${req.accountNumber}) ৳${req.amount} সফলভাবে পাঠিয়ে দেওয়া হয়েছে।`,
        type: 'SUCCESS',
        read: false,
        createdAt: new Date().toISOString(),
      };
      txn.set(notifRef, notif);

      return { success: true, message: 'উইথড্র সফলভাবে পেইড হিসেবে চিহ্নিত করা হয়েছে।' };
    });
  } catch (err: unknown) {
    if (err instanceof Error) return { success: false, message: err.message };
    return { success: false, message: 'উইথড্র প্রক্রিয়াকরণে সমস্যা হয়েছে।' };
  }
}

export async function adminRejectWithdrawal(
  requestId: string,
  adminNote: string
): Promise<{ success: boolean; message: string }> {
  const reqDocRef = doc(db, 'withdrawalRequests', requestId);

  try {
    return await runTransaction(db, async (txn) => {
      const reqSnap = await txn.get(reqDocRef);
      if (!reqSnap.exists()) throw new Error('রিকোয়েস্ট পাওয়া যায়নি!');
      const req = reqSnap.data() as WithdrawalRequest;
      if (req.status !== 'PENDING') throw new Error('রিকোয়েস্টটি আর পেন্ডিং নেই!');

      const userDocRef = doc(db, 'users', req.userId);
      const userSnap = await txn.get(userDocRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        const currentBalance = Number(userData.walletBalance || 0);
        // Refund amount back to balance
        txn.update(userDocRef, {
          walletBalance: currentBalance + req.amount,
          updatedAt: new Date().toISOString(),
        });
      }

      txn.update(reqDocRef, {
        status: 'REJECTED',
        adminNote: adminNote || 'Incorrect account number or declined',
        processedAt: new Date().toISOString(),
      });

      const trxDocRef = doc(db, 'transactions', 'trx_w_' + requestId);
      txn.update(trxDocRef, { status: 'REJECTED' });

      // Notify player
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 9);
      const notifRef = doc(db, 'notifications', notifId);
      const notif: AppNotification = {
        id: notifId,
        userId: req.userId,
        title: 'Withdrawal Declined',
        titleBn: 'উইথড্র বাতিল ও রিফান্ড হয়েছে',
        message: `Your withdrawal of ৳${req.amount} was rejected and refunded to your wallet. Reason: ${adminNote}`,
        messageBn: `আপনার ৳${req.amount} উইথড্র বাতিল করা হয়েছে এবং টাকা ওয়ালেটে ফেরত দেওয়া হয়েছে। কারণ: ${adminNote}`,
        type: 'WARNING',
        read: false,
        createdAt: new Date().toISOString(),
      };
      txn.set(notifRef, notif);

      return { success: true, message: 'উইথড্র বাতিল এবং ব্যালেন্স রিফান্ড করা হয়েছে।' };
    });
  } catch (err: unknown) {
    if (err instanceof Error) return { success: false, message: err.message };
    return { success: false, message: 'বাতিল করতে সমস্যা হয়েছে।' };
  }
}

export async function fetchUserTransactions(userId: string): Promise<WalletTransaction[]> {
  try {
    const q = query(collection(db, 'transactions'), where('userId', '==', userId));
    const snap = await getDocs(q);
    const list: WalletTransaction[] = [];
    snap.forEach((d) => list.push(d.data() as WalletTransaction));
    return list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'transactions');
  }
}

export async function fetchDepositRequests(userId?: string): Promise<DepositRequest[]> {
  try {
    let q = query(collection(db, 'depositRequests'));
    if (userId) {
      q = query(collection(db, 'depositRequests'), where('userId', '==', userId));
    }
    const snap = await getDocs(q);
    const list: DepositRequest[] = [];
    snap.forEach((d) => list.push(d.data() as DepositRequest));
    return list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'depositRequests');
  }
}

export async function fetchWithdrawalRequests(userId?: string): Promise<WithdrawalRequest[]> {
  try {
    let q = query(collection(db, 'withdrawalRequests'));
    if (userId) {
      q = query(collection(db, 'withdrawalRequests'), where('userId', '==', userId));
    }
    const snap = await getDocs(q);
    const list: WithdrawalRequest[] = [];
    snap.forEach((d) => list.push(d.data() as WithdrawalRequest));
    return list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'withdrawalRequests');
  }
}
