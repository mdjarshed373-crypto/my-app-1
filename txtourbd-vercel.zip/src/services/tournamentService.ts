import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  runTransaction,
} from 'firebase/firestore';
import { db } from './firebase';
import {
  Tournament,
  TournamentRegistration,
  RoomCredential,
  PlayerSlotInfo,
  WalletTransaction,
} from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export async function fetchTournaments(): Promise<Tournament[]> {
  try {
    const snap = await getDocs(collection(db, 'tournaments'));
    const list: Tournament[] = [];
    snap.forEach((d) => {
      list.push({ ...(d.data() as Tournament), id: d.id });
    });
    // Sort by createdAt desc
    return list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'tournaments');
  }
}

export async function fetchTournamentById(id: string): Promise<Tournament | null> {
  try {
    const snap = await getDoc(doc(db, 'tournaments', id));
    if (snap.exists()) {
      return { ...(snap.data() as Tournament), id: snap.id };
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `tournaments/${id}`);
  }
}

export async function joinTournament(
  tournament: Tournament,
  userId: string,
  userName: string,
  players: PlayerSlotInfo[],
  teamName?: string,
  teamId?: string
): Promise<{ success: boolean; message: string; registrationId?: string }> {
  const regId = `${userId}_${tournament.id}`;
  const regDocRef = doc(db, 'registrations', regId);
  const userDocRef = doc(db, 'users', userId);
  const tournamentDocRef = doc(db, 'tournaments', tournament.id);

  try {
    return await runTransaction(db, async (txn) => {
      // 1. Check existing registration
      const regSnap = await txn.get(regDocRef);
      if (regSnap.exists()) {
        throw new Error('আপনি ইতিমধ্যে এই টুর্নামেন্টে রেজিস্টার করেছেন! (Already registered)');
      }

      // 2. Fetch latest tournament doc
      const tourSnap = await txn.get(tournamentDocRef);
      if (!tourSnap.exists()) {
        throw new Error('টুর্নামেন্টটি খুঁজে পাওয়া যায়নি!');
      }
      const currentTour = tourSnap.data() as Tournament;

      if (currentTour.status === 'COMPLETED' || currentTour.status === 'CANCELLED') {
        throw new Error('এই টুর্নামেন্টটি বন্ধ হয়ে গেছে!');
      }

      if (currentTour.registeredCount >= currentTour.maxSlots) {
        throw new Error('দুঃখিত, টুর্নামেন্টের সমস্ত স্লট বুক হয়ে গেছে! (Slots Full)');
      }

      // 3. Check wallet balance
      const userSnap = await txn.get(userDocRef);
      if (!userSnap.exists()) {
        throw new Error('ব্যবহারকারীর প্রোফাইল পাওয়া যায়নি!');
      }
      const userProfile = userSnap.data();
      const currentBalance = Number(userProfile.walletBalance || 0);

      if (currentTour.entryFee > 0 && currentBalance < currentTour.entryFee) {
        throw new Error(
          `পর্যাপ্ত ওয়ালেট ব্যালেন্স নেই! প্রয়োজন ৳${currentTour.entryFee}, আপনার ব্যালেন্স ৳${currentBalance}। দয়া করে ওয়ালেটে টাকা ডিপোজিট করুন।`
        );
      }

      // 4. Deduct fee if applicable
      const newBalance = currentBalance - currentTour.entryFee;
      txn.update(userDocRef, {
        walletBalance: newBalance,
        totalTournaments: (userProfile.totalTournaments || 0) + 1,
        updatedAt: new Date().toISOString(),
      });

      // 5. Update tournament registered count
      const newRegisteredCount = (currentTour.registeredCount || 0) + 1;
      const newStatus =
        newRegisteredCount >= currentTour.maxSlots
          ? 'REGISTRATION_FULL'
          : currentTour.status;

      txn.update(tournamentDocRef, {
        registeredCount: newRegisteredCount,
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });

      // 6. Create registration record
      const slotNumber = newRegisteredCount;
      const playerUids = players.map((p) => p.uid || '').filter(Boolean);
      if (!playerUids.includes(userId)) playerUids.push(userId);

      const registrationData: TournamentRegistration = {
        id: regId,
        tournamentId: tournament.id,
        userId,
        userName,
        teamId: teamId || '',
        teamName: teamName || (tournament.type === 'SOLO' ? players[0]?.inGameName : 'Squad ' + slotNumber),
        type: tournament.type,
        status: 'CONFIRMED',
        slotNumber,
        playerUids,
        players,
        entryFeePaid: tournament.entryFee,
        createdAt: new Date().toISOString(),
      };
      txn.set(regDocRef, registrationData);

      // 7. Create wallet transaction record if fee > 0
      if (tournament.entryFee > 0) {
        const trxId = 'trx_fee_' + Math.random().toString(36).substring(2, 9);
        const trxDocRef = doc(db, 'transactions', trxId);
        const trxData: WalletTransaction = {
          id: trxId,
          userId,
          type: 'ENTRY_FEE',
          amount: tournament.entryFee,
          status: 'COMPLETED',
          referenceId: tournament.id,
          description: `Entry fee for ${tournament.title} (Slot #${slotNumber})`,
          descriptionBn: `${tournament.titleBn || tournament.title}-এ যোগদানের এন্ট্রি ফি (স্লট #${slotNumber})`,
          balanceAfter: newBalance,
          createdAt: new Date().toISOString(),
        };
        txn.set(trxDocRef, trxData);
      }

      return {
        success: true,
        message: 'টুর্নামেন্টে সফলভাবে স্লট বুক করা হয়েছে!',
        registrationId: regId,
      };
    });
  } catch (err: unknown) {
    if (err instanceof Error) {
      return { success: false, message: err.message };
    }
    return { success: false, message: 'রেজিস্ট্রেশন করতে সমস্যা হয়েছে।' };
  }
}

export async function fetchUserRegistrations(userId: string): Promise<TournamentRegistration[]> {
  try {
    const q = query(
      collection(db, 'registrations'),
      where('userId', '==', userId)
    );
    const snap = await getDocs(q);
    const list: TournamentRegistration[] = [];
    snap.forEach((d) => list.push(d.data() as TournamentRegistration));
    return list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'registrations');
  }
}

export async function fetchRoomCredentials(tournamentId: string): Promise<RoomCredential | null> {
  try {
    const snap = await getDoc(doc(db, 'rooms', tournamentId));
    if (snap.exists()) {
      return snap.data() as RoomCredential;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `rooms/${tournamentId}`);
  }
}

export async function saveRoomCredentials(data: RoomCredential): Promise<void> {
  try {
    await setDoc(doc(db, 'rooms', data.tournamentId), {
      ...data,
      id: data.tournamentId,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `rooms/${data.tournamentId}`);
  }
}

export async function createTournament(
  tournament: Omit<Tournament, 'id'>,
  initialRoom?: { roomId?: string; roomPassword?: string; isPublished?: boolean }
): Promise<string> {
  try {
    const id = 'tour_' + Math.random().toString(36).substring(2, 9);
    await setDoc(doc(db, 'tournaments', id), {
      ...tournament,
      id,
      registeredCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    // Create room document
    await setDoc(doc(db, 'rooms', id), {
      id,
      tournamentId: id,
      roomId: initialRoom?.roomId || '',
      roomPassword: initialRoom?.roomPassword || '',
      releaseTime: tournament.matchDate || new Date().toISOString(),
      isPublished: initialRoom?.isPublished || false,
      updatedAt: new Date().toISOString(),
    });

    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'tournaments');
  }
}

export async function updateTournament(id: string, data: Partial<Tournament>): Promise<void> {
  try {
    await updateDoc(doc(db, 'tournaments', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `tournaments/${id}`);
  }
}

export async function deleteTournament(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'tournaments', id));
    await deleteDoc(doc(db, 'rooms', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `tournaments/${id}`);
  }
}

export async function fetchRegistrationsForTournament(tournamentId: string): Promise<TournamentRegistration[]> {
  try {
    const q = query(
      collection(db, 'registrations'),
      where('tournamentId', '==', tournamentId)
    );
    const snap = await getDocs(q);
    const list: TournamentRegistration[] = [];
    snap.forEach((d) => list.push(d.data() as TournamentRegistration));
    return list.sort((a, b) => a.slotNumber - b.slotNumber);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'registrations');
  }
}
