import {
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  collection,
  runTransaction,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from './firebase';
import { MatchResult, TeamPlacementResult, Tournament, UserProfile, WalletTransaction, AppNotification } from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export const DEFAULT_PLACEMENT_POINTS: Record<number, number> = {
  1: 12,
  2: 9,
  3: 8,
  4: 7,
  5: 6,
  6: 5,
  7: 4,
  8: 3,
  9: 2,
  10: 1,
};

export function calculatePoints(
  placement: number,
  kills: number,
  killPointsMultiplier = 1,
  customPlacementPoints?: Record<number, number>
) {
  const pMap = customPlacementPoints || DEFAULT_PLACEMENT_POINTS;
  const placementPoints = pMap[placement] || 0;
  const killPoints = kills * killPointsMultiplier;
  const totalPoints = placementPoints + killPoints;
  return { placementPoints, killPoints, totalPoints };
}

export async function fetchMatchResult(tournamentId: string): Promise<MatchResult | null> {
  try {
    const snap = await getDoc(doc(db, 'matchResults', tournamentId));
    if (snap.exists()) {
      return snap.data() as MatchResult;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `matchResults/${tournamentId}`);
  }
}

export async function saveMatchResult(
  tournament: Tournament,
  standings: TeamPlacementResult[]
): Promise<void> {
  try {
    const resultDocRef = doc(db, 'matchResults', tournament.id);
    const resultData: MatchResult = {
      id: tournament.id,
      tournamentId: tournament.id,
      tournamentTitle: tournament.title,
      standings,
      isVerified: false,
      isPrizeDistributed: false,
      createdAt: new Date().toISOString(),
    };
    await setDoc(resultDocRef, resultData);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `matchResults/${tournament.id}`);
  }
}

export async function publishResultAndDistributePrizes(
  tournamentId: string
): Promise<{ success: boolean; message: string }> {
  const resultDocRef = doc(db, 'matchResults', tournamentId);
  const tourDocRef = doc(db, 'tournaments', tournamentId);

  try {
    return await runTransaction(db, async (txn) => {
      const resultSnap = await txn.get(resultDocRef);
      if (!resultSnap.exists()) throw new Error('ম্যাচ ফলাফল পাওয়া যায়নি!');
      const result = resultSnap.data() as MatchResult;

      if (result.isPrizeDistributed) {
        throw new Error('এই টুর্নামেন্টের প্রাইজ ইতিমধ্যে বিতরণ করা হয়েছে!');
      }

      const tourSnap = await txn.get(tourDocRef);
      if (!tourSnap.exists()) throw new Error('টুর্নামেন্ট পাওয়া যায়নি!');
      const tour = tourSnap.data() as Tournament;

      // Distribute prizes to players
      for (const standing of result.standings) {
        const prizeAmount = Number(standing.prizeWon || 0);
        const kills = Number(standing.kills || 0);
        const isWinner = standing.placement === 1;

        // Collect player IDs to credit
        const uidsToCredit: string[] = [];
        if (standing.playerUids && standing.playerUids.length > 0) {
          standing.playerUids.forEach((uid) => {
            if (uid && !uidsToCredit.includes(uid)) uidsToCredit.push(uid);
          });
        }

        // If squad/duo, split prize equally among members
        const perPlayerPrize = uidsToCredit.length > 0 ? Math.floor(prizeAmount / uidsToCredit.length) : 0;
        const perPlayerKills = uidsToCredit.length > 0 ? Math.round(kills / uidsToCredit.length) : kills;

        for (const uid of uidsToCredit) {
          const userRef = doc(db, 'users', uid);
          const userSnap = await txn.get(userRef);

          if (userSnap.exists()) {
            const userData = userSnap.data() as UserProfile;
            const currentBalance = Number(userData.walletBalance || 0);
            const newBalance = currentBalance + perPlayerPrize;

            txn.update(userRef, {
              walletBalance: newBalance,
              totalEarnings: Number(userData.totalEarnings || 0) + perPlayerPrize,
              totalKills: Number(userData.totalKills || 0) + perPlayerKills,
              totalWins: Number(userData.totalWins || 0) + (isWinner ? 1 : 0),
              totalMatches: Number(userData.totalMatches || 0) + 1,
              updatedAt: new Date().toISOString(),
            });

            // Create prize transaction if prize > 0
            if (perPlayerPrize > 0) {
              const trxId = 'trx_pz_' + tournamentId + '_' + uid.substring(0, 5);
              const trxRef = doc(db, 'transactions', trxId);
              const trxData: WalletTransaction = {
                id: trxId,
                userId: uid,
                type: 'PRIZE',
                amount: perPlayerPrize,
                status: 'COMPLETED',
                referenceId: tournamentId,
                description: `Prize for #${standing.placement} in ${tour.title}`,
                descriptionBn: `${tour.titleBn || tour.title}-এ #${standing.placement} স্থান অর্জনের প্রাইজ`,
                balanceAfter: newBalance,
                createdAt: new Date().toISOString(),
              };
              txn.set(trxRef, trxData);

              // Notify player
              const notifId = 'notif_pz_' + tournamentId + '_' + uid.substring(0, 5);
              const notifRef = doc(db, 'notifications', notifId);
              const notif: AppNotification = {
                id: notifId,
                userId: uid,
                title: 'Congratulations! Prize Won! 🏆',
                titleBn: 'অভিনন্দন! টুর্নামেন্ট প্রাইজ জিতেছেন! 🏆',
                message: `You won ৳${perPlayerPrize} for placement #${standing.placement} in ${tour.title}.`,
                messageBn: `আপনি ${tour.titleBn || tour.title}-এ #${standing.placement} স্থান অর্জন করে ৳${perPlayerPrize} জিতেছেন!`,
                type: 'SUCCESS',
                read: false,
                createdAt: new Date().toISOString(),
              };
              txn.set(notifRef, notif);
            }
          }
        }
      }

      // Mark result as verified and distributed
      txn.update(resultDocRef, {
        isVerified: true,
        isPrizeDistributed: true,
        publishedAt: new Date().toISOString(),
      });

      // Mark tournament as COMPLETED
      txn.update(tourDocRef, {
        status: 'COMPLETED',
        updatedAt: new Date().toISOString(),
      });

      return {
        success: true,
        message: 'ফলাফল সফলভাবে প্রকাশিত হয়েছে এবং বিজয়ীদের ওয়ালেটে প্রাইজ মানি যোগ হয়েছে!',
      };
    });
  } catch (err: unknown) {
    if (err instanceof Error) return { success: false, message: err.message };
    return { success: false, message: 'প্রাইজ বিতরণে সমস্যা হয়েছে।' };
  }
}

export async function fetchTopPlayers(): Promise<UserProfile[]> {
  try {
    const q = query(collection(db, 'users'), orderBy('totalEarnings', 'desc'), limit(50));
    const snap = await getDocs(q);
    const list: UserProfile[] = [];
    snap.forEach((d) => list.push(d.data() as UserProfile));
    return list;
  } catch {
    // If composite index is pending, fallback to fetching users and sorting
    try {
      const snap = await getDocs(collection(db, 'users'));
      const list: UserProfile[] = [];
      snap.forEach((d) => list.push(d.data() as UserProfile));
      return list.sort((a, b) => (b.totalEarnings || 0) - (a.totalEarnings || 0));
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, 'users');
    }
  }
}
